import type { EventData } from "../../features/relay/events";
import { type ConversationWake } from "../../features/agent-harness/plugin-wake";
export type Scope = "thread" | "channel";
/** Messages of thread context shown with a turn, newest kept. */
export declare const CONTEXT_LIMIT = 12;
export declare function systemPrompt(input: Readonly<{
    scope: Scope;
    cwd: string;
    /** Who the agent is, so it can name itself and the session viewer can too. */
    agent?: Readonly<{
        name: string;
        pubkey: string;
    }>;
    instructions?: string;
    /** Device-local repository location, supplied by the owning runtime. */
    repositories?: string;
    /** A section for each team the agent is on, from the host. */
    team?: string;
    /** The agent's `core` memory; `null` when it has none yet. */
    memory?: string | null;
    /** Its recent notes, as `recentNotesSection` gives them. */
    notes?: string;
}>): string;
export type Channel = Readonly<{
    id: string;
    name?: string;
    dm?: boolean;
}>;
export type TurnInput = Readonly<{
    /** The agent's membership key, which finds its sessions among others' in a
     * shared workspace. */
    agent: string;
    event: EventData;
    channel: Channel;
    scope: Scope;
    /** One channel conversation, with a channel-level posting default. */
    topLevel?: boolean;
    /** Channel delivery permits explicit replies; Solo chats do not. */
    channelLevel?: boolean;
    /** The thread the event belongs to, absent for a top-level message. */
    thread?: Readonly<{
        rootId: string;
        parentId: string;
    }>;
    /** Messages of the conversation the session has not been shown: earlier
     * ones, and for a resumed turn also those after it. */
    context: readonly EventData[];
    /** Messages the conversation has in all, for `total=`. */
    total: number;
    /** What started the turn, such as "@mention". */
    label: string;
    /** A display name for a pubkey, if known. */
    name(pubkey: string): string | undefined;
    /** The chat's workspace Canvas section, for a Solo chat with one. */
    project?: string;
    /** A plugin's wake, whose turn has its section in place of the event's. */
    wake?: ConversationWake;
}>;
/** One turn: routing context, unseen thread context, then the event. */
export declare function turnPrompt(input: TurnInput): string;
/** A turn for a session that is still working on an earlier one. */
export declare const steerPrompt: (turn: string) => string;
