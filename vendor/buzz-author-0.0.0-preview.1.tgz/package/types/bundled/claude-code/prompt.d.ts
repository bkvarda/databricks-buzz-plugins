import type { EventData } from "../../features/relay/events";
import { type ConversationWake } from "../../features/agent-harness/plugin-wake";
import { type AuthorNames } from "../../features/agent-harness/turn-records";
export type Scope = "thread" | "channel";
/** Messages of thread context shown with a turn, newest kept. */
export declare const CONTEXT_LIMIT = 12;
export declare function systemPrompt(input: Readonly<{
    scope: Scope;
    cwd: string;
    /** Who the agent is, so it can name itself and the session viewer can too. */
    agent?: Readonly<{
        name: string;
        pubkey: string;
    }>;
    instructions?: string;
    /** Device-local repository location, supplied by the owning runtime. */
    repositories?: string;
    /** A section for each team the agent is on, from the host. */
    team?: string;
    /** The agent's `core` memory; `null` when it has none yet. */
    memory?: string | null;
    /** Its recent notes, as `recentNotesSection` gives them. */
    notes?: string;
}>): string;
export type Channel = Readonly<{
    id: string;
    name?: string;
    dm?: boolean;
}>;
export type TurnInput = Readonly<{
    /** The agent's membership key, which finds its sessions among others' in a
     * shared workspace. */
    agent: string;
    event: EventData;
    channel: Channel;
    scope: Scope;
    /** One channel conversation, with a channel-level posting default. */
    topLevel?: boolean;
    /** Channel delivery permits explicit replies; Solo chats do not. */
    channelLevel?: boolean;
    /** The thread the event belongs to, absent for a top-level message. */
    thread?: Readonly<{
        rootId: string;
        parentId: string;
    }>;
    /** Messages of the conversation the session has not been shown: earlier
     * ones, and for a resumed turn also those after it. */
    context: readonly EventData[];
    /** Messages the conversation has in all. */
    total: number;
    /** The chat's workspace Canvas section, for a Solo chat with one. */
    project?: string;
    /** A plugin's wake, whose turn has its section in place of the event's. */
    wake?: ConversationWake;
    /** The names each message's record shows beside its author's pubkey, when
     * known. */
    names?: (pubkey: string) => AuthorNames | undefined;
    /** The relay key that posts messages for others, whose context records show
     * the person they are for, as Codex history does. */
    signingAuthority?: string;
}>;
/** One turn: unseen thread context, routing context, then the event. Each
 * message is an exact record, the same record shape Codex sends, so a
 * protection plugin can check each one on its own. */
export declare function turnPrompt(input: TurnInput): string;
/** A turn for a session that is still working on an earlier one. Its event's
 * section becomes the steer's, so the event stays a record of its own; a
 * turn without exactly one, such as a wake's, is wrapped whole. */
export declare function steerPrompt(turn: string): string;
