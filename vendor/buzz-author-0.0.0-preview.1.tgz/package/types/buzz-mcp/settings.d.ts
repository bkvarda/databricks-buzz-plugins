import type { BuzzClient } from "./client";
import type { Tool } from "./tools";
export declare const SETTINGS_TOOLS: readonly Tool[];
export declare const isSettingsTool: (name: string) => boolean;
/** Runs settings tool `name` as `client`. A throw is a tool error. */
export declare function callSettingsTool(client: BuzzClient, name: string, args: Readonly<Record<string, unknown>>): string;
