import type { BuzzClient, Context } from "./client";
import { type AddedTool, type SessionTool } from "./session-tools";
import type { Reply } from "./tools";
/** How a harness has the server list its tools. By default each is listed
 * without its `load`, and the server says nothing up front. */
export type Listing = Readonly<{
    instructions?: string;
    tool?: (tool: SessionTool) => object;
}>;
/** Answers `input`, listing the session's Buzz tools and the `added` ones
 * plugins add. Without a client, tools are listed but cannot be called. */
export declare function respond(client: BuzzClient | undefined, context: Context, input: unknown, added?: readonly AddedTool[], listing?: Listing): Promise<{
    jsonrpc: string;
    id: string | number;
    result: unknown;
} | {
    jsonrpc: string;
    id: string | number;
    error: {
        code: number;
        message: string;
    };
}>;
/** A tool's answer as MCP content. */
export declare const content: (reply: Reply) => ({
    type: "image";
    data: string;
    mimeType: string;
    text?: never;
} | {
    data?: never;
    mimeType?: never;
    type: "text";
    text: string;
})[];
export declare const errorText: (error: unknown) => string;
