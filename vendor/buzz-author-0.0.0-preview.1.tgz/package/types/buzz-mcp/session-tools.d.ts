import type { BuzzClient, Context } from "./client";
import { type Reply, type Tool } from "./tools";
/** A tool a plugin adds to every agent session in the app, listed after
 * the Buzz tools under the same server and loaded on search. Its name should
 * start with its plugin's, as `notes_get` does; no two tools share one. */
export type AddedTool = Readonly<{
    name: string;
    description: string;
    inputSchema: Readonly<Record<string, unknown>>;
    /** Runs it as the agent working in `context`. A throw is a tool error for
     * the agent to correct. */
    call(client: BuzzClient, context: Context, args: Record<string, unknown>): Promise<Reply>;
}>;
type Listed = Pick<AddedTool, "name" | "description" | "inputSchema">;
/** The Buzz tools that post a message, and so take `final`. Each harness
 * strips its own prefix from a tool's name before asking. */
export declare const MESSAGE_TOOLS: readonly ["send", "reply_in_subthread"];
export declare const isMessageTool: (name: unknown) => boolean;
/** Whether a call posts a message marked final, which can end the turn. */
export declare const isFinalMessage: (name: unknown, args: unknown) => boolean;
export type BuzzSession = Readonly<{
    tools: readonly Tool[];
}>;
/** What every session of an agent in the app gets. It never changes with
 * the owner's attention setting, so a session (and its cached prompt prefix)
 * never needs replacing when attention is turned on or off: the attention
 * tools refuse calls while it is off, and `turnNote` says which it is. */
export declare const BUZZ_SESSION: BuzzSession;
/** A tool as a session lists it. `search` means a harness that can load
 * tools on demand lists it by name only, and the model loads it when it
 * needs it; `always` means it is listed in full up front. Only the Buzz tools
 * choose: those plugins add always load on search, so installing plugins
 * never grows what every turn carries. */
export type SessionTool = Listed & Readonly<{
    load: "always" | "search";
}>;
/** The tools a session lists: the Buzz tools, then those plugins add. */
export declare const sessionTools: (added?: readonly AddedTool[]) => readonly SessionTool[];
/** What the server (Claude) or namespace (Codex) with the tools says up
 * front, so the model knows what it can search for. */
export declare function sessionHint(added?: readonly AddedTool[]): string;
/** Changes when the added tools change, so a session that keeps the list it
 * started with can be replaced; empty while plugins add none. A short hash,
 * since Codex saves it with each binding. Sorted by name, so the order
 * plugins start in does not change it. */
export declare function addedKey(added: readonly AddedTool[]): string;
/** Text for the end of a turn's prompt, as the agent's attention is now.
 * An agent with no Interests has nothing to review, so it need not load the
 * attention tools to find that out. */
export declare function turnNote(client?: Pick<BuzzClient, "attention">): string | undefined;
/** Answers one tool call. Throws when the tool cannot run now; the message
 * is for the agent. Without a client, no tool can be called yet. `added`
 * are the tools plugins add now. */
export declare function callSessionTool(client: BuzzClient | undefined, context: Context, name: string, args: Record<string, unknown>, added?: readonly AddedTool[]): Promise<Reply>;
export {};
