import type { BuzzClient } from "./client";
import { type Tool } from "./tools";
export declare const OWNER_TOOLS: readonly Tool[];
export declare const isOwnerTool: (name: string) => boolean;
/** Runs owner tool `name`. Throws, before reading anything, when this
 * client has no owner access, as a plugin's or another host's has not. */
export declare function callOwnerTool(client: BuzzClient, name: string, args: Readonly<Record<string, unknown>>): Promise<Readonly<{
    text: string;
    held(): void;
}>>;
