import type { BuzzClient } from "./client";
import type { AddedTool } from "./session-tools";
import { type ExternalScope } from "../features/agents/external-connection";
/** An approved external app acts as the selected agent: it lists and calls
 * the tools that agent's sessions get, plugins' included, through the same
 * dispatcher, without an implicit conversation. Only full-agent approval
 * calls them; an older, narrower approval must be approved again. */
export declare function respondExternal(client: BuzzClient, input: unknown, connected: () => void, scopes: readonly ExternalScope[], added: () => readonly AddedTool[]): Promise<{
    jsonrpc: string;
    id: string | number;
    result: unknown;
} | {
    jsonrpc: string;
    id: {};
    error: {
        code: number;
        message: string;
    };
} | {
    jsonrpc: string;
    id: {};
    result: {
        isError: boolean;
        content: {
            type: string;
            text: string;
        }[];
        _meta: {
            "buzz/error": {
                code: string;
                required_scopes: string[];
            };
        };
    };
} | undefined>;
