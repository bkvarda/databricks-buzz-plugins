import type { BuzzClient } from "./client";
import type { ExternalScope } from "../features/agents/external-connection";
/** The external grant has no implicit conversation and cannot call plugin tools. */
export declare function respondExternal(client: BuzzClient, input: unknown, connected: () => void, scopes?: readonly ExternalScope[]): Promise<{
    jsonrpc: string;
    id: {};
    result: unknown;
} | {
    jsonrpc: string;
    id: {};
    error: {
        code: number;
        message: string;
    };
} | undefined>;
