import type { BuzzClient, Context } from "./client";
import type { Tool } from "./tools";
export declare const PLUGIN_TOOLS: readonly Tool[];
export declare const isPluginTool: (name: string) => boolean;
export declare function callPluginTool(client: BuzzClient, context: Context, name: string, args: Record<string, unknown>): Promise<string>;
