import type { BuzzClient } from "./client";
export type Clock = Readonly<{
    /** Seconds since the epoch. */
    now(): number;
    wait(ms: number): Promise<void>;
}>;
export declare const SOLO_WORKER_TOOLS: readonly [{
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}, {
    name: string;
    description: string;
    inputSchema: {
        type: string;
        properties: {
            owner: {
                type: "string";
                description: string;
            };
        };
        required?: readonly string[];
        additionalProperties: boolean;
    };
    annotations: {
        destructiveHint?: boolean;
        readOnlyHint: boolean;
    };
}];
export declare const isSoloWorkerTool: (name: string) => boolean;
/** Runs Solo worker tool `name` as `client`. A throw is a tool error for the
 * agent to correct; anything the owner's Buzz says is an answer. */
export declare function callSoloWorkerTool(client: BuzzClient, name: string, args: Readonly<Record<string, unknown>>, clock?: Clock): Promise<string>;
