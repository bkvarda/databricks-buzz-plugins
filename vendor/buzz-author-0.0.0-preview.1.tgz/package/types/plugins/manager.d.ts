import { type PluginStorage } from "./storage";
import { PluginRuntime } from "./runtime";
import type { Context } from "@deepseek-ai/cordis";
import type { PluginManifest, PluginModule } from "./api";
import type { ConfigurationState, ManagementAction, PluginInfo } from "./types";
export declare function canRetryPlugin(plugin: PluginInfo | undefined, activation: ReturnType<PluginRuntime["snapshot"]>[string] | undefined, externalPluginsPaused: boolean): boolean;
export type BundledPlugin = {
    manifest: PluginManifest;
    module: PluginModule;
    enabledByDefault?: boolean;
};
export declare function createPluginManager(ctx: Context, { bundled, builtIn, storage, }: {
    bundled: readonly BundledPlugin[];
    /** Host-owned contributions, independent of optional-plugin storage. */
    builtIn?: readonly BundledPlugin[];
    storage?: PluginStorage | undefined;
}): {
    snapshot: () => {
        configuration: ConfigurationState;
        activation: import("./runtime").PluginStates;
        busy: boolean;
        error: string | null;
        refreshError: string | null;
    };
    startup: () => "loading" | "ready" | "recovery";
    subscribe(listener: () => void): () => void;
    imports: import("./types").PluginImports | undefined;
    installImport: (token: string, path: string) => Promise<boolean>;
    change: (action: ManagementAction, id: string) => Promise<boolean>;
    reload: (id: string) => Promise<boolean>;
    retryPlugin: (id: string) => boolean;
    retry: () => Promise<boolean>;
    recover: () => Promise<boolean>;
    dismissError: () => void;
    dispose(): Promise<void>;
};
export type PluginManager = ReturnType<typeof createPluginManager>;
