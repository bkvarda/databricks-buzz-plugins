import type { Context } from "@deepseek-ai/cordis";
import type { PluginModule } from "./api";
import type { PluginInfo } from "./types";
export type PluginState = {
    revision: string;
    status: "starting" | "active" | "failed";
    error: string | null;
};
export type PluginStates = Record<string, PluginState>;
export declare class PluginRuntime {
    private readonly root;
    private readonly entries;
    private states;
    private closed;
    private readonly load;
    private readonly listeners;
    private readonly timeoutMs;
    constructor(root: Context, load: (plugin: PluginInfo) => Promise<PluginModule>, timeoutMs?: number, 
    /** Whether the manager is still reading which plugins to run. */
    configuring?: () => boolean);
    snapshot: () => PluginStates;
    subscribe: (listener: () => void) => () => void;
    isActive: (id: string, revision: string) => boolean;
    private publish;
    reconcile(plugins: readonly PluginInfo[], retryId?: string): void;
    private update;
    private start;
    private watch;
    private fail;
    private stop;
    dispose(): Promise<void>;
}
