import { type Context } from "@deepseek-ai/cordis";
import type { PluginManager } from "./manager";
export type GitPluginInstallSource = Readonly<{
    repository: string;
    reference: string;
    path?: string;
    /** Install exactly this commit; the import is refused if the fetched head differs. */
    commit?: string;
}>;
/**
 * One plugin artifact (`buzzodz plugin pack`) over HTTPS, for people without access
 * to the Git host. Buzz installs it only if it hashes to `sha256` and its manifest ID is `id`.
 */
export type UrlPluginInstallSource = Readonly<{
    id: string;
    url: string;
    sha256: string;
}>;
export type PluginInstallSource = GitPluginInstallSource | UrlPluginInstallSource;
export type PluginInstallOutcome = "installed" | "updated" | "cancelled" | "unavailable";
type PluginInstallationStatus = "installed" | "absent" | "unavailable";
export type PluginInstaller = Readonly<{
    /** The source kinds `requestInstall` accepts. Missing on hosts that accept only Git. */
    sources?: readonly ("git" | "url")[];
    /** Opens Settings → Plugins for the user to review; it never installs silently. */
    requestInstall(source: PluginInstallSource): Promise<PluginInstallOutcome>;
    /**
     * Checks stable manifest-ID membership in the ready catalog, regardless of
     * enabled state or install source. Returns unavailable until the catalog is ready.
     */
    getInstallationStatus(id: string): PluginInstallationStatus;
    /** Listen for status changes; call getInstallationStatus after subscribing for the current status. */
    subscribeInstallationStatus(id: string, listener: (status: PluginInstallationStatus) => void): () => void;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        /** Read with `ctx.reflect.get("pluginInstaller")` for old-host compatibility. */
        pluginInstaller?: PluginInstaller;
    }
}
export declare function pluginArtifactUrl(value: unknown): string | null;
export declare function isUrlInstallSource(source: PluginInstallSource): source is UrlPluginInstallSource;
/** The normalized request, or null when any field is outside the accepted grammar. */
export declare function parsePluginInstallSource(input: unknown): PluginInstallSource | null;
/** The calling plugin as its own context reports it: a hint for the review, not proof. */
export type PluginInstallOrigin = Readonly<{
    id: string;
    name: string;
}>;
export type PluginInstallRequest = Readonly<{
    id: number;
    source: PluginInstallSource;
    origin: PluginInstallOrigin;
}>;
export type GitPluginInstallRequest = PluginInstallRequest & Readonly<{
    source: GitPluginInstallSource;
}>;
export type UrlPluginInstallRequest = PluginInstallRequest & Readonly<{
    source: UrlPluginInstallSource;
}>;
export declare function createPluginInstallRequests({ ttlMs, }?: {
    ttlMs?: number;
}): {
    snapshot: () => Readonly<{
        id: number;
        source: PluginInstallSource;
        origin: PluginInstallOrigin;
    }> | undefined;
    subscribe(listener: () => void): () => void;
    /** Resolves "unavailable" at once while another request or any review is open. */
    request(source: PluginInstallSource, origin: PluginInstallOrigin): Promise<PluginInstallOutcome>;
    /**
     * A review dialog took the request; it now lives as long as that dialog.
     * Refused, and settled unavailable, while another review dialog is open.
     */
    claim(id: number): boolean;
    /**
     * The user confirmed the install. Until the returned function runs, the
     * requester going away (as it does when it updates itself) does not cancel
     * the request, so the install can still report its outcome.
     */
    confirm(id: number): () => void;
    /**
     * The requester or the review went away: cancels the request unless a
     * confirmed install is still running, which then reports its own outcome.
     */
    end(id: number): void;
    /** Marks a plugin review dialog as open until the returned function runs. */
    holdReview(): () => void;
    settle: (id: number, outcome: PluginInstallOutcome) => void;
};
export type PluginInstallRequests = ReturnType<typeof createPluginInstallRequests>;
type InstallHost = Readonly<{
    plugins: Pick<PluginManager, "snapshot" | "subscribe" | "imports">;
    requests: PluginInstallRequests;
    openPlugins(): Promise<{
        status: string;
    }>;
}>;
export declare function createPluginInstallCore({ plugins, requests, openPlugins, }: InstallHost): {
    holdReview: () => () => void;
    getInstallationStatus: (id: string) => PluginInstallationStatus;
    subscribeInstallationStatus(id: string, listener: (status: PluginInstallationStatus) => void): () => void;
    submit(source: PluginInstallSource, caller: Readonly<{
        id: string;
        /** Runs `end` when the caller goes away and returns a function that stops
         * watching; throws when the caller is already gone. */
        lifetime(end: () => void): () => void;
    }>): Promise<PluginInstallOutcome>;
};
export type PluginInstallCore = ReturnType<typeof createPluginInstallCore>;
/** The handle plugins read from `ctx.reflect`. */
export declare function createPluginInstallerService(ctx: Context, host: Readonly<{
    core: PluginInstallCore;
}>): PluginInstaller;
export {};
