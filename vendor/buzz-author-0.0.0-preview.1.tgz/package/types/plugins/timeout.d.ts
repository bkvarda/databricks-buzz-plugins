export declare function withTimeout<T>(operation: Promise<T>, message: string, milliseconds?: number): Promise<T>;
