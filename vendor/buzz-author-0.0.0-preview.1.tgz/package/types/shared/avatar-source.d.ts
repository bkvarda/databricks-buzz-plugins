/** Display-only avatars. No file URLs, SVG data, executable schemes or credentials. */
export declare function avatarSource(value: unknown): string | undefined;
/** Displayable small avatar: inline data as-is, remote art through the
 * session's authenticated media path (never the raw URL). */
export declare function avatarMedia(value: unknown, media: ((url: string, size: "small") => string | undefined) | undefined): string | undefined;
