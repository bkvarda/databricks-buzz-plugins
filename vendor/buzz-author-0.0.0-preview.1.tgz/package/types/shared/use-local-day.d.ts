/** Re-render the caller when the local day (or time zone) changes. */
export declare function useLocalDay(): string;
