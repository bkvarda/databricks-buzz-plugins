import { type Contrast, type Accent } from "./accent";
/** Host-owned, device-local appearance. Never depends on plugin/relay readiness. */
export type ColorMode = "light" | "dark";
export type ColorModePreference = ColorMode | "system";
export declare const APPEARANCE_KEY = "buzz-appearance.v1";
export type MessageWidth = "narrow" | "wide";
export declare const MESSAGE_WIDTH_KEY = "buzz-message-width.v1";
export declare const parseMessageWidth: (value: unknown) => MessageWidth;
export declare const FONT_SCALE_KEY = "buzz-font-scale.v1";
export declare const MIN_FONT_SCALE = 0.8;
export declare const MAX_FONT_SCALE = 2;
export declare function parseFontScale(value: unknown): number;
export declare const parseColorMode: (value: unknown) => ColorMode;
export declare const parseColorModePreference: (value: unknown) => ColorModePreference;
/** Vertical rhythm of conversation rows; text size stays with the font scale. */
export type MessageDensity = "default" | "compact";
export declare const DENSITY_KEY = "buzz-message-density.v1";
export declare const parseMessageDensity: (value: unknown) => MessageDensity;
export interface AppearanceSnapshot {
    readonly preference: ColorModePreference;
    readonly mode: ColorMode;
    readonly messageWidth: MessageWidth;
    readonly messageWidthError: string | null;
    readonly fontScale: number;
    readonly fontError: string | null;
    readonly accent: Accent;
    readonly accentError: string | null;
    readonly contrast: Contrast;
    readonly contrastError: string | null;
    readonly density: MessageDensity;
    readonly densityError: string | null;
    readonly error: string | null;
}
export declare function createAppearance(host?: Window | undefined): {
    snapshot: () => AppearanceSnapshot;
    subscribe(listener: () => void): () => void;
    setMode(preference: ColorModePreference): void;
    setFontScale(value: number): void;
    setMessageWidth(value: MessageWidth): void;
    setAccent(value: Accent): void;
    setContrast(value: Contrast): void;
    setDensity(value: MessageDensity): void;
    /** After `dispose`, setters change nothing. */
    isDisposed: () => boolean;
    dispose(): void;
};
export type Appearance = ReturnType<typeof createAppearance>;
