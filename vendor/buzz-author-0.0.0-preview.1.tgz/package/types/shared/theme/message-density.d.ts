import { type MessageDensity } from "./service";
/** The applied density, for layout choices CSS cannot make (row order, alignment). */
export declare function useMessageDensity(): MessageDensity;
