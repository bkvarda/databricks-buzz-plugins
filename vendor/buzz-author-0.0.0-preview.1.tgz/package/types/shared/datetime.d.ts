/**
 * Relative date labels for messages and day groups, ported from Buzz desktop
 * (`desktop/src/shared/lib/datetime.ts`) so both apps read the same.
 *
 * The ladder follows the Block writing standard for relative dates, with one
 * deliberate deviation noted on `formatDayGroupLabel`. Formats use the default
 * locale and time zone, checked again after yielding, so a running app follows
 * OS changes without resolving the defaults for every row in one render batch.
 * Clock times follow the hour cycle and seconds chosen in Appearance settings.
 */
/** Local calendar day of a unix-seconds timestamp. Every row compares days on
 * each render, so days are memoized under the time zone `dateFormats` saw. */
export declare function calendarDay(createdAt: number): string;
/**
 * Label for a group of items that share a calendar day, such as a day divider.
 *
 * ```
 * Today            → "Today"
 * Yesterday        → "Yesterday"
 * 2–6 days ago     → "Monday"
 * older, this year → "Saturday, June 20"
 * earlier years    → "June 20, 2025"
 * ```
 *
 * Deliberate deviation from the standard: the standard collapses anything over
 * ten months old to month and year ("Aug 2022"). A group label has to identify
 * its day, so the day is kept and only the year is conditional.
 *
 * `nowSeconds` stays a parameter, not a captured constant: a label rendered
 * before midnight has to say "Yesterday" once the day rolls over.
 */
export declare function formatDayGroupLabel(unixSeconds: number, nowSeconds?: number): string;
/**
 * Label for one item's timestamp, such as a message byline or a list row.
 *
 * ```
 * withTime: false (narrow rows)   withTime: true (roomy rows)
 * Today   → "2:34 PM"             Today   → "2:34 PM"
 * Yest.   → "Yesterday"           Yest.   → "Yesterday at 2:34 PM"
 * 2–6d    → "Monday"              2–6d    → "Monday at 2:34 PM"
 * year    → "Sat, Jun 20"         year    → "Sat, Jun 20 at 2:34 PM"
 * older   → "Jun 20, 2025"        older   → "Jun 20, 2025 at 2:34 PM"
 * ```
 *
 * Today needs no date word: a bare clock time already reads as today.
 * `withTime` is a surface decision: pass `true` where people read
 * conversation, and `false` in a narrow list row with the full date a hover
 * away.
 */
export declare function formatItemTimestamp(unixSeconds: number, { withTime, nowSeconds, }?: {
    withTime?: boolean;
    nowSeconds?: number;
}): string;
/** The complete date and time, such as a timestamp's hover text:
 * "Friday, October 2, 2026 at 3:05:09 PM EDT". */
export declare function formatFullTimestamp(unixSeconds: number): string;
/** The clock time, such as "3:05 PM". */
export declare function formatTime(unixSeconds: number): string;
/** A continuation clock without the day period, sharing the full date's settings. */
export declare function formatCompactTime(unixSeconds: number): string;
