/** Matches Buzz desktop's thread-summary recency ladder (dateFormatters.ts). */
export declare function relativeTimestamp(unixSeconds: number, nowSeconds?: number): string;
