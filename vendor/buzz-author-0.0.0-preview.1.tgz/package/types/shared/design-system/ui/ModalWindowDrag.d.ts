import { type PointerEvent, type ReactNode } from "react";
type WindowDrag = {
    canDrag(event: PointerEvent<HTMLElement>): boolean;
    startDragging(): void;
};
/** The host owns native window behavior; modal surfaces forward only backdrop gestures. */
export declare function ModalWindowDragProvider({ children, value, }: {
    children: ReactNode;
    value: WindowDrag | undefined;
}): import("react").JSX.Element;
export declare function useModalWindowDrag(): {
    onPointerDown(event: PointerEvent<HTMLElement>): void;
    onPointerMove(event: PointerEvent<HTMLElement>): void;
    onPointerUp: () => void;
    onPointerCancel: () => void;
    onLostPointerCapture: () => void;
    /** Keep the drag fence through release/cancel: a click may follow either. */
    wasWindowDrag: () => boolean;
};
export {};
