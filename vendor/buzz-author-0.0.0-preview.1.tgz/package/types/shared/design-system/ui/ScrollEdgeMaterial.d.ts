/** Surface fade and progressive blur behind sticky chrome; its contents stay sharp. */
export declare function ScrollEdgeMaterial({ edge, className, }: {
    edge: "top" | "bottom";
    className?: string;
}): import("react").JSX.Element;
