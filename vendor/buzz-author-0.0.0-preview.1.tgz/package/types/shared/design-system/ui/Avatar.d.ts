import "../styles/avatar-shape.css";
import "../styles/avatar-status.css";
import { type ReactNode } from "react";
/** The host may supply artwork for recognized sources; unknown images keep normal loading. */
export declare const AvatarArtworkContext: import("react").Context<((src: string) => ReactNode) | null>;
type AvatarSize = "tiny" | "compact" | "small" | "default" | "large" | "fill";
export declare function Avatar({ src, alt, fallback, fallbackContent, fallbackSurface, size, shape, statusBadge, loading, }: {
    src?: string | null | undefined;
    alt: string;
    fallback: string;
    fallbackContent?: ReactNode;
    /** Panel-colored monogram for avatars displayed on an inset surface. */
    fallbackSurface?: "subtle" | "panel";
    size?: AvatarSize;
    shape?: "circle" | "squircle";
    statusBadge?: "online" | "away" | "offline" | undefined;
    /** Immediate visible editors may bypass lazy scheduling, never image readiness. */
    loading?: "eager" | "lazy";
}): import("react").JSX.Element;
export {};
