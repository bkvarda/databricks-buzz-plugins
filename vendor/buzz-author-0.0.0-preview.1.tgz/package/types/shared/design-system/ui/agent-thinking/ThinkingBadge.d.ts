import { type ReactNode } from "react";
import "./thinking.css";
/** One silhouette travels from the corner to the compact Start-button capsule. */
export declare function ThinkingBadge({ thinking, enabled, children, avatarSize, }: {
    thinking: boolean;
    enabled?: boolean;
    children: ReactNode;
    avatarSize?: number;
}): import("react").JSX.Element;
