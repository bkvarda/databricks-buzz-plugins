import { type AriaAttributes, type ReactElement, type ReactNode } from "react";
/** DESIGN.md "Hover timing": how long a hint waits for a resting pointer. */
export type HintTiming = "helpful" | "familiar";
/** Hints in one provider open instantly while a neighbor is showing. */
export declare function TooltipProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** A short supplementary hint. The trigger still owns its accessible name. */
export declare function Tooltip({ children, content, hint, closeOnClick, disableHoverablePopup, side, follow, open: controlledOpen, onOpenChange, }: {
    children: ReactElement<Pick<AriaAttributes, "aria-describedby" | "aria-expanded"> & {
        "data-accent"?: string;
        "data-color-mode"?: string;
    }>;
    content: ReactNode;
    hint?: HintTiming | undefined;
    closeOnClick?: boolean;
    disableHoverablePopup?: boolean;
    side?: "top" | "right";
    /** Attach a non-interactive hint below/right of the native pointer. */
    follow?: "trigger" | "pointer";
    /** Action feedback may open a hint after an asynchronous result. */
    open?: boolean;
    onOpenChange?(open: boolean): void;
}): import("react").JSX.Element;
