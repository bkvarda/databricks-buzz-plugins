import { Button as BaseButton } from "@base-ui/react/button";
import type { ComponentProps, ReactNode } from "react";
import { type HintTiming } from "./Tooltip";
type ButtonVariant = "prominent" | "subtle" | "glass" | "subtle-muted" | "ghost" | "destructive" | "outline" | "attention" | "glass" | "glass-ghost" | "glass-clear" | "inverted" | "link" | "plain" | "primary" | "quiet";
type ButtonSize = "caption" | "inline" | "row" | "xs" | "sm" | "md" | "lg" | "compact" | "default";
export type ButtonProps = Omit<ComponentProps<typeof BaseButton>, "className"> & {
    children: ReactNode;
    variant?: ButtonVariant;
    size?: ButtonSize;
    loading?: boolean;
    /** How long the `title` hint waits; see DESIGN.md "Hover timing". */
    hint?: HintTiming;
} & ({
    shape?: "capsule" | "control";
} | {
    shape: "icon";
    "aria-label": string;
});
/** Base UI owns activation. Legacy variant/size names remain during migration. */
export declare function Button({ children, variant, size, shape, type, loading, disabled, onClick, title, hint, ...props }: ButtonProps): import("react").JSX.Element;
export {};
