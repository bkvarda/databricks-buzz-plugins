import type { ReactNode } from "react";
/** A content card for empty, setup, and status views. Actions and state stay caller-owned. */
export declare function EmptyState({ icon, title, description, action, level, }: {
    icon: ReactNode;
    title: string;
    description?: ReactNode;
    action?: ReactNode;
    level?: 3 | 4;
}): import("react").JSX.Element;
