import { type ReactNode } from "react";
/** Delay feedback, never content. The caller supplies the stable content geometry. */
export declare function LoadingRegion({ pending, label, children, feedback, statusVisibility, }: {
    pending: boolean;
    /** The delayed status. Decorative motion inside it, such as `TypingDots`,
     * must be hidden from assistive technology so only the text is announced. */
    label: ReactNode;
    children: ReactNode;
    /** Immediate scoped error/retry; replaces only the reserved feedback slot. */
    feedback?: ReactNode;
    /** Keep delayed announcements without reserving a visible status row. */
    statusVisibility?: "visible" | "screen-reader";
}): import("react").JSX.Element;
