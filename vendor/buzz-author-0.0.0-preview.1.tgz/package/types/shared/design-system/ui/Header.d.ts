import type { ReactNode } from "react";
type HeaderProps = {
    title: ReactNode;
    subtitle?: ReactNode;
    eyebrow?: ReactNode;
    icon?: ReactNode;
    actions?: ReactNode;
    id?: string;
    level?: 1 | 2 | 3 | 4;
};
/** Content hierarchy; panel chrome and dialog semantics remain with their owners. */
export declare function Header({ level, ...props }: HeaderProps): import("react").JSX.Element;
export declare function InlineHeader({ level, ...props }: HeaderProps): import("react").JSX.Element;
export {};
