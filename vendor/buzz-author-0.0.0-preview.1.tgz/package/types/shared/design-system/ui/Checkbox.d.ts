import { Checkbox as BaseCheckbox } from "@base-ui/react/checkbox";
import { type ComponentProps, type ReactNode } from "react";
export declare function Checkbox({ label, id, indeterminate, size, ...props }: Omit<ComponentProps<typeof BaseCheckbox.Root>, "className" | "children"> & {
    label: ReactNode;
    size?: "sm" | "md";
}): import("react").JSX.Element;
