import { type ComponentPropsWithRef, type ReactNode, type ReactElement } from "react";
/** A host action in a tab's menu. */
export type TabAction = {
    label: string;
    run(): void;
};
export type TabItem<Value extends string> = {
    value: Value;
    label: string;
    icon?: ReactNode;
    disabled?: boolean;
    trailing?: ReactNode;
    /** Compose an anchored surface around the actual tab trigger, replacing its default hint. */
    renderTab?: ((tab: ReactElement<ComponentPropsWithRef<"button">>) => ReactElement) | undefined;
    /** Link a retained, externally owned tab panel. */
    panelId?: string;
    /** Increment to briefly identify an already-open navigation tab. */
    attentionRequest?: number | undefined;
    onClose?: (() => void) | undefined;
    /** Option/Alt+Shift+Arrow moves this tab one position; the caller places it. */
    draggable?: boolean | undefined;
    onMove?: ((delta: -1 | 1) => void) | undefined;
    /** Double-click, F2 or the tab's menu edits its name; blank restores the default. */
    onRename?: ((name: string) => void) | undefined;
    /** Listed first in the tab's menu. */
    actions?: readonly TabAction[] | undefined;
};
/**
 * Which background this control is drawn for.
 *
 * `chrome` is the glass pill that belongs on the app gradient. `panel` is an
 * underline for a plain light or dark surface. `segmented` groups filters
 * on an opaque surface with an inset track and a raised selection.
 *
 * **A variant rather than a second component**, because behaviour, keyboard
 * model, accessibility, props, and the Base UI tabs underneath are identical —
 * only the appearance differs, which is what a variant is for. `IconButton`
 * spells the same idea the same way.
 *
 * `chrome` is the default because every existing call site is on the gradient.
 */
export type TabsVariant = "chrome" | "dock" | "panel" | "workspace" | "navigation" | "segmented" | "segmented-icons";
export declare function Tabs<Value extends string>({ value, items, label, onValueChange, onReselect, trailingAction, variant, orientation, size, showSelection, previewValue, arrivalValue, renderPanel, tabMenu, }: {
    /** Scoped host actions, composed with each tab's Rename action. */
    tabMenu?: {
        key: string;
        closeAll(): boolean;
        /** Closes every tab but `value`, which stays open and selected. */
        closeOthers?: ((value: Value) => boolean) | undefined;
    } | undefined;
    /** Omit only when composing an existing externally owned view. */
    renderPanel?: (value: Value) => ReactNode;
    value: Value | null;
    items: readonly TabItem<Value>[];
    label: string;
    onValueChange: (value: Value) => void;
    /** Opt in when activating the selected tab returns from a nested view. */
    onReselect?: (value: Value) => void;
    trailingAction?: ReactNode;
    variant?: TabsVariant;
    orientation?: "horizontal" | "vertical";
    /** Segmented filter track size; other variants retain their own geometry. */
    size?: "sm" | "md";
    /** Hide the visual selection for a single-view header; tab semantics remain. */
    showSelection?: boolean;
    /** Incoming tab being previewed before a workspace drop is committed. */
    previewValue?: Value;
    /** Brief visual confirmation of a tab arriving after a completed move. */
    arrivalValue?: Value | undefined;
}): import("react").JSX.Element;
/** One shared menu composes host actions and tab naming with close actions. */
export declare function TabMenu({ label, actions, onClose, onRename, closeAll, closeOthers, children, }: {
    label: string;
    actions: readonly TabAction[] | undefined;
    onClose: (() => void) | undefined;
    onRename: (() => void) | undefined;
    closeAll: (() => boolean) | undefined;
    /** This tab stays, so the menu returns focus to it. */
    closeOthers: (() => boolean) | undefined;
    children: ReactNode;
}): import("react").JSX.Element;
