/** The topmost available modal: the last open one in document order. */
export declare function activeModal(document: Document): Element | undefined;
/**
 * Native top-layer hover surfaces paint above ordinary portals regardless of
 * z-index. Reuse popup semantics and Base UI's rendered lifetime, not a second
 * overlay registry. Inline lists, toasts and supplemental previews aren't popups.
 * The element's `own` popup, and popups nested in its portal, don't cover it.
 */
export declare function behindActiveOverlay(element: Element, own?: Element | null): boolean;
/** Open/close need not move focus or the pointer; watch the existing DOM state. */
export declare function observeOverlays(update: () => void): () => void;
