import { type SVGProps } from "react";
/** The Block, Inc. mark: a three-by-three grid of rounded squares. */
export declare const BlockLogoArtwork: import("react").ForwardRefExoticComponent<Omit<SVGProps<SVGSVGElement> & {
    size?: number | string;
}, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
