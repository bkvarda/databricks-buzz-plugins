import type { IconProps } from "./createDecorativeIcon";
/** Designer-approved Soft & wide mark: fuller canvas with narrow, inward ears. */
export declare const RobotArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
