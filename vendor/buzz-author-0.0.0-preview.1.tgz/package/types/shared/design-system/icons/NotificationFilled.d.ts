import type { IconProps } from "./createDecorativeIcon";
/** Designer-requested filled counterpart to Tabler's outline Notification. */
export declare const NotificationFilledArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
