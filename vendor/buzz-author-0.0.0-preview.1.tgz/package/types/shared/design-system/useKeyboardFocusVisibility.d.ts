export declare function focusWithKeyboard(element: HTMLElement): void;
/**
 * Makes keyboard focus visible without treating a pointer click in a text field
 * as keyboard navigation. Browsers intentionally match :focus-visible for text
 * inputs even after a click, so this app-level modality fact gates the visual
 * treatment consistently for every control.
 */
export declare function useKeyboardFocusVisibility(): void;
