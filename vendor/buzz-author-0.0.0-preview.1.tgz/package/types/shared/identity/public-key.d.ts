/** The full npub of a hex public key, or undefined for anything else. */
export declare function canonicalPublicKey(pubkey: string): string | undefined;
/** Display only: never use this abbreviation for copying, storage or routing. */
export declare function formatPublicKey(pubkey: string, suffixLength?: number): string | undefined;
/** Distinct public identities share the shortest unambiguous suffix, starting at three. */
export declare function publicKeyLabels(pubkeys: Iterable<string>): ReadonlyMap<string, string>;
/** Compact single-line public identity with recognizable leading and trailing characters. */
export declare function abbreviatedPublicKey(pubkey: string): string | undefined;
/** The hex public key that typed text names exactly: 64 hex characters in
 * either case, or a lowercase or uppercase npub with or without `nostr:`.
 * Undefined for anything else, including a key still being typed. */
export declare function typedPublicKey(text: string): string | undefined;
