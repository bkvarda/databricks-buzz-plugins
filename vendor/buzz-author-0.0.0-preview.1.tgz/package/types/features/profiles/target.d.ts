/** Public identity locator, not a relay hint or an authority claim. */
export declare function profileTarget(pubkey: string, hint?: {
    agent: boolean;
}): string | undefined;
/** App-local avatar presentation only; never evidence of ownership or control. */
export declare function profileAgentHint(target: string): boolean;
export declare function profilePanelKey(target: string): string | undefined;
/** Public message/composer input must never supply an app-local avatar hint. */
export declare function profileKey(target: string): string | undefined;
/** App-local Activity destination, never a public identity or authority claim.
 * `transcript` is for an opener that knows which one conversation the work is
 * in: Activity then shows that conversation's transcript first. */
export declare function profileActivityViewTarget(pubkey: string, options?: {
    transcript: boolean;
}): string | undefined;
export declare function profileActivityViewKey(target: string): string | undefined;
export declare function subscribeProfileTranscripts(listener: () => void): () => undefined;
/** Opens `target` through `open`, asking the profile it opens to show its
 * transcript once. A target that is only shown again, as when its retained
 * tab remounts on returning to the channel, asks for nothing. */
export declare function openProfileTranscript(target: string, open: (target: string) => boolean): boolean;
/** The opening still asking `target`'s profile for its transcript. */
export declare function profileTranscriptRequest(target: string): number | undefined;
/** Takes `target`'s opening for the profile now showing it, so a profile
 * mounted later, as on returning to the channel, finds nothing to act on. */
export declare function claimProfileTranscript(target: string): number | undefined;
/** Whether an Activity destination asks for its conversation's transcript. */
export declare function profileActivityTranscript(target: string): boolean;
