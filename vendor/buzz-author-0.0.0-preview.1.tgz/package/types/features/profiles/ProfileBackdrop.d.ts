import type { ReactNode } from "react";
/** Decorative artwork; callers resolve images through their existing media owner. */
export declare function ProfileBackdrop({ src, children, }: {
    src: string | null | undefined;
    children?: ReactNode;
}): import("react").JSX.Element | null;
