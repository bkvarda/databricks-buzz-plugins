import type { RelaySession } from "../relay/session";
/** Verified NIP-OA owner of the winning signed kind 0, or none. Agent hints
 * decide whether to mount this view; they never establish ownership.
 * Private admission must inspect readiness as well as signed-head ownership.
 * Public identity attribution may still display its retained signed evidence. */
export declare function useAgentOwnerEvidence(session: RelaySession, pubkey: string | undefined, attempt?: number): {
    status: "loading" | "ready" | "error" | "unavailable";
    owner: string | undefined;
    failed: boolean;
    settled: boolean;
};
