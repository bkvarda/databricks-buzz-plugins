import type { ChannelSummary } from "../relay/contracts";
/** What names a channel and chooses how it is shown. */
export type ChannelLabel = Pick<ChannelSummary, "name" | "private" | "channelType">;
/** Ordinary channel visibility chooses its icon, as the sidebar shows it;
 * callers retain non-channel type icons. */
export declare function channelIcon(channel: {
    readonly private?: true | undefined;
    readonly channelType?: string | undefined;
} | undefined): import("../../shared/design-system/icons/createDecorativeIcon").DefinedIcon;
/** The channel's name as plain text, `#`-prefixed only where its icon is a hash. */
export declare function channelText(channel: ChannelLabel): string;
