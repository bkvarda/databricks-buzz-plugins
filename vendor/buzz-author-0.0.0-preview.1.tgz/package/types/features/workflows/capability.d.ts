import type { EventData } from "../relay/events";
import type { RelayReader } from "../relay/reader";
import type { Outbox, LocalEvents } from "../relay/outbox";
import type { WorkflowHost } from "./host";
import type { WorkflowCapability } from "./types";
/** Session-owned configuration snapshots and bounded result state; never an engine. */
export declare function createWorkflows({ reader, viewer, outbox, local, host, relayHttpUrl, canAccess, notify, }: {
    reader: RelayReader | undefined;
    viewer: string;
    outbox: Outbox | undefined;
    local: LocalEvents | undefined;
    host: WorkflowHost | undefined;
    /** Relay HTTP base for display only; hook URLs are never fetched from here. */
    relayHttpUrl?: string | undefined;
    canAccess(channel: string): boolean;
    notify?: (listener: () => void) => void;
}): {
    capability: Readonly<WorkflowCapability>;
    validate(event: EventData): void;
    receipt(event: EventData, message: string | undefined): void;
    interrupt(): void;
    clear(): void;
    dispose(): void;
};
