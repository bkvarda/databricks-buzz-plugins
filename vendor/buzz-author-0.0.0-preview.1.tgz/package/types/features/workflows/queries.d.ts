/** The relay bounds aggregate explicit channel values at 128. */
export declare const WORKFLOW_CHANNEL_BATCH = 128;
export declare const WORKFLOW_DEFINITION_LIMIT = 100;
/** Narrow exception to the generic four-filter budget, shared with the broker. */
export declare function isWorkflowDefinitionBatch(value: unknown): boolean;
