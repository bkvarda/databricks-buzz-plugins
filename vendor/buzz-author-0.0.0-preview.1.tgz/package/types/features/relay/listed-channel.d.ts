import type { ChannelQueries, ChannelSummary } from "./contracts";
/** One roster fact about one channel. Previews and activity replace the list and
 * its summaries on every message, so `select` must return a primitive or a
 * reference the store retains (such as `members`); the caller then renders only
 * when that fact changes. */
export declare function useListedChannel<T>(queries: Partial<Pick<ChannelQueries, "list" | "subscribeList">> | undefined, channelId: string | undefined, select: (channel: ChannelSummary | undefined) => T): T;
