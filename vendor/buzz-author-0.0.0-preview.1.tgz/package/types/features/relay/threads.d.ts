export { threadReference } from "./thread-reference";
import type { ChannelMessage } from "./contracts";
import type { RelayEvent } from "./events";
import type { LocalEvents } from "./outbox";
import type { Priority, RelayReader } from "./reader";
import { MessageClock } from "./message-order";
export type ThreadSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    root: ChannelMessage | undefined;
    replies: readonly ChannelMessage[];
    error: string | undefined;
    /** Continuation is possible, not a claim about total thread size or exhaustion. */
    canLoadMore: boolean;
    limited: boolean;
    /** Older pages are demand-loaded; forward is the legacy bounded walk. */
    direction?: "older" | "forward";
    /** The in-flight or failed read, distinct from the traversal direction. */
    readKind?: "older" | "refresh" | undefined;
    /** Exact navigation target, folded independently of bounded thread traversal. */
    target?: ChannelMessage | undefined;
    targetStatus?: "loading" | "ready" | "unavailable" | "error" | undefined;
}>;
export type ThreadRetarget = "selected" | "different" | "unavailable" | "error" | "cancelled";
export type ThreadView = {
    snapshot(): ThreadSnapshot;
    subscribe(listener: () => void): () => void;
    refresh(): Promise<void>;
    loadMore(): Promise<void>;
    /** Change exact selection only when verified ancestry belongs to this thread. */
    retarget(messageId: string, signal: AbortSignal): Promise<ThreadRetarget>;
    dispose(): void;
};
/** Why an exact read can't show its target: this channel holds no such message
 * (`not-found`), or the read failed (`unavailable`). A failed thread read also
 * fails a target that is its `root`. Undefined while the read may still show it. */
export declare function threadFailure(snapshot: ThreadSnapshot, root: boolean): "not-found" | "unavailable" | undefined;
/** Session-owned evidence. Finite page cursors NEVER come from the live/local display union. */
export declare function createThreadView({ channelId, messageId, relayAuthor, signingAuthority, agentOwner, reader: sourceReader, targetReader: sourceTargetReader, admitTarget, seed, local, canAccess, canRefresh, visible, notify, exact, priority, admit, clock, dropped: openedDropped, }: {
    channelId: string;
    messageId: string;
    relayAuthor: string;
    /** Explicit NIP-11 self; only it may attribute messages to others. */
    signingAuthority?: string | undefined;
    agentOwner?: ((pubkey: string) => string | undefined) | undefined;
    reader: RelayReader;
    targetReader?: RelayReader;
    admitTarget?: (events: readonly RelayEvent[]) => readonly RelayEvent[];
    seed: RelayEvent | undefined;
    local: LocalEvents | undefined;
    canAccess(): boolean;
    /** Cached membership can display saved rows but cannot authorize a network retry. */
    canRefresh?(): boolean;
    visible(events: readonly RelayEvent[]): readonly RelayEvent[];
    notify(listener: () => void): void;
    exact?: boolean;
    /** Admission for every read this view makes. A passive reader, one that
     * only decorates a link, takes `background` so an opened or previewed
     * conversation's reads start ahead of it. */
    priority?: Priority | undefined;
    /** The session's send clock; rendered replies raise its channel watermark. */
    clock?: MessageClock;
    /** Exact finite reads enter session reconciliation only after a complete fold. */
    admit?: ((events: readonly RelayEvent[]) => readonly RelayEvent[]) | undefined;
    /** Opened while the stream was down, or before it was up: the first read
     * is the snapshot its establishment refresh must reach. */
    dropped?: boolean;
}): {
    channelId: string;
    event: (id: string) => import("nostr-tools").VerifiedEvent | undefined;
    events: () => import("nostr-tools").VerifiedEvent[];
    receive: (events: readonly RelayEvent[]) => void;
    purge: (clear?: boolean) => void;
    /** The stream dropped: the replies held now are what its establishment
     * refresh must reach. */
    stale(): void;
    /** The stream is back: refresh, reaching the replies held across the drop. */
    established: () => Promise<void>;
    localChanged(): void;
    /** Profiles change the rows only through an owner the fold looked up. */
    ownersChanged(): void;
    view: {
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            root: ChannelMessage | undefined;
            replies: readonly ChannelMessage[];
            error: string | undefined;
            /** Continuation is possible, not a claim about total thread size or exhaustion. */
            canLoadMore: boolean;
            limited: boolean;
            /** Older pages are demand-loaded; forward is the legacy bounded walk. */
            direction?: "older" | "forward";
            /** The in-flight or failed read, distinct from the traversal direction. */
            readKind?: "older" | "refresh" | undefined;
            /** Exact navigation target, folded independently of bounded thread traversal. */
            target?: ChannelMessage | undefined;
            targetStatus?: "loading" | "ready" | "unavailable" | "error" | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        retarget: (id: string, signal: AbortSignal) => Promise<ThreadRetarget>;
        refresh: () => Promise<void>;
        loadMore: () => Promise<void>;
        dispose(): void;
    };
};
