import type { OutboxStorage } from "./outbox";
/** Drops one partition's journal, including its legacy record, after that
 * community's session is disposed: nothing left there can still be delivered. */
export declare function purgeOutboxStorage(scope: string): Promise<void>;
/** Incremental asynchronous journal, atomically partitioned by relay and viewer. */
export declare function browserOutboxStorage(scope: string): OutboxStorage;
