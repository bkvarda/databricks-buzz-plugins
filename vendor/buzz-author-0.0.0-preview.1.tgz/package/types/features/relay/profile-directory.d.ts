import type { VerifiedProfileAuthority, VerifiedProfileFilter, VerifiedProfileSink } from "./verified-profile";
import type { Outbox } from "./outbox";
import type { Profile } from "./contracts";
import type { RelayEvent } from "./events";
import type { Priority, RelayReader } from "./reader";
/** Shared profile reads for any feature, independent of channel history. */
export interface ProfileQueries {
    snapshot(): ReadonlyMap<string, Profile>;
    subscribe(listener: () => void): () => void;
    /** Fetch missing profiles; optional enrichment can yield to conversation reads. */
    ensure(ids: readonly string[], priority?: Priority): Promise<void>;
    /** The winning signed kind 0 retained for one identity, for provenance checks. */
    event?(pubkey: string): RelayEvent | undefined;
    /** Identities a completed read found no profile for, until one arrives. */
    unnamed?(): ReadonlySet<string>;
    /** Cryptographically verified owner of the retained signed profile head. */
    owner?(pubkey: string): string | undefined;
    /** Moves each time a full cache clear or dispose drops every loaded profile.
     * A channel access change keeps profiles, so it does not move this. A view
     * that ensured the identities it shows must ensure them again: the clear
     * notifies after it removes content, so only names still on screen are
     * reread. */
    generation?(): number;
    /** Room for `members` more profiles while a view of that many people is
     * open, within the hard limit. Growth is immediate. After a release, the
     * next task returns the limit to the largest remaining reservation and
     * evicts the least recently used profiles past it. */
    reserve?(members: number): () => void;
    /** Profiles the cache can hold now; one ensure may ask for at most this many. */
    limit?(): number;
    /** Moves when the budget drops loaded profiles or a shrink cancels pending
     * background reads. A view that requested names once and skips repeats must
     * request again after it moves. */
    evictions?(): number;
    /** The community's current verified-profile authority, or undefined while
     * it advertises none. Subscribers are notified when it changes. */
    verifiedAuthority?(): VerifiedProfileAuthority | undefined;
    /** Whether the shared verified directory holds a head for `pubkey`. Its
     * profile's `verified`, present or not, then outranks a search's answer:
     * a newer inactive or malformed head revokes an older name. */
    verifiedHeld?(pubkey: string): boolean;
    /** Moves with every change to the shared verified heads, including one that
     * leaves every profile as it was (a first inactive head), and notifies. */
    verifiedRevision?(): number;
    /** Whether a `verifiedRevision()` after `revision` accepted a head for
     * `pubkey`, even one the cache evicted before publishing it. Past what it
     * remembers it answers yes, never no for a head it accepted. */
    verifiedSince?(pubkey: string, revision: number): boolean;
}
/** One bounded source of signed profile events. Display values are derived from it. */
export declare function createProfileDirectory(reader: RelayReader, local?: Pick<Outbox, "snapshot" | "subscribe">, notify?: (listener: () => void) => void, verification?: {
    authority?: VerifiedProfileAuthority | undefined;
    refresh?: ((signal: AbortSignal) => Promise<VerifiedProfileAuthority | null>) | undefined;
    subscribe(filter: VerifiedProfileFilter, sink: VerifiedProfileSink): (() => void) | undefined;
}): {
    queries: ProfileQueries;
    ensure: (ids: readonly string[], priority?: Priority, refresh?: boolean) => Promise<void>;
    accept: (incoming: readonly RelayEvent[], read?: AbortSignal) => void;
    clear: () => void;
    connected(value: boolean): void;
    reconnect(): Promise<void>;
    event: (id: string) => import("nostr-tools").VerifiedEvent | undefined;
    stats: () => {
        entries: number;
        bytes: number;
    };
    dispose(): void;
};
export type ProfileDirectory = ReturnType<typeof createProfileDirectory>;
