import type { ReadFilter } from "./events.ts";
import { ReadError } from "./errors.ts";
/** Admission owns starts, not retries or delivery semantics. An admitted write is
 * still sent once; a lost response is never permission to repeat it. */
export declare class ApiPaused extends ReadError {
    constructor(retryAfterMs: number);
}
export declare class ApiNotSent extends Error {
}
export declare class ApiCapacity extends ApiNotSent {
    constructor();
}
export type ApiFailure = Readonly<{
    error: string;
    code?: string;
    quota?: "api";
    paused?: true;
    retryAfterMs?: number;
    sent?: false;
    /** A relay-shaped 401/403. An edge or proxy page (for example a VPN still
     * reconnecting) has the same status but is not the relay's answer. */
    denied?: true;
    /** The relay refused this account at its front door, for every request in
     * the community, not one item: its sign-in ended or it has no access. */
    admission?: CommunityRefusal;
}>;
export type CommunityRefusal = "sign-in" | "access";
/** The development broker's mark on a response whose relay request the
 * community refused (`relay-broker.mjs`). */
export declare const BROKER_REFUSAL_HEADER = "x-buzz-refusal";
/** The refusal a read's error reports, when it was the relay's community-wide
 * one (its `ApiFailure.error`): a refusal met while connecting. */
export declare function refusalOfError(error: unknown): CommunityRefusal | undefined;
/** Only a correlated relay quota reason becomes a shared API cooldown. Local
 * broker concurrency 429 and arbitrary response text must not impersonate it. */
export declare function apiFailure(status: number, value: unknown): ApiFailure;
/** Consumes one bounded error body; success payloads remain their owner's concern.
 * `reason` may keep an exact, caller-allowed upstream refusal from that body. */
export declare function readApiFailure(response: Response, reason?: (body: unknown, status: number) => string | Pick<ApiFailure, "error" | "code"> | undefined): Promise<ApiFailure>;
type Ticket = {
    priority: "foreground" | "background";
    signal?: AbortSignal | undefined;
    start(): void;
    reject(error: Error): void;
    abort(): void;
};
/** One host/principal API lane, bounded like the broker's six-request ceiling.
 * Available capacity dispatches immediately; only server cooldowns pause starts.
 * Cooldowns reject queued work rather than spending a read's 10s deadline. */
export declare function createApiAdmission(): {
    /** Lossy snapshot lease; never consumes ordinary slots or start credit. */
    tryPresence(): (() => void) | undefined;
    presenceIdle: () => boolean;
    /** Retain bounded ownership across asynchronous auth and its final dispatch.
     * A cancelled unabortable signer keeps its slot until it settles: repeatedly
     * cancelling must not admit an unbounded number of outstanding sign prompts. */
    prepare<T>(work: () => Promise<T>): Promise<T>;
    idle: () => boolean;
    pause(milliseconds: number): void;
    run<T>(work: () => Promise<T>, signal?: AbortSignal, priority?: Ticket["priority"]): Promise<T>;
};
/** Wrap the actual fetch boundary in both hosts. No transparent request retry.
 * Normalize bounded error evidence while preserving the original status/headers. */
export declare function admittedApiRequest(lane: ReturnType<typeof createApiAdmission>, request: () => Promise<Response>, signal?: AbortSignal, priority?: Ticket["priority"], reason?: (body: unknown, status: number) => string | Pick<ApiFailure, "error" | "code"> | undefined): Promise<Response>;
/** The optional lane accepts only this bounded presence shape, never a priority hint. */
export declare function presenceFilter(raw: unknown): raw is ReadFilter[];
export declare function presenceText(response: Response): Promise<string>;
export {};
