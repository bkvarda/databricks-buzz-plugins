import { type RelayEvent } from "./events.ts";
export declare function readSnapshotCommunity(value: unknown): string | undefined;
export declare const readSnapshotFilter: (viewer: string) => {
    kinds: number[];
    authors: string[];
    read_state_snapshot: number;
}[];
export declare function isReadSnapshotFilter(raw: unknown, viewer: string): boolean;
/** Complete at the writer's cut only; not a CAS revision, message total or live cursor. */
export declare function parseReadSnapshot(raw: unknown, viewer: string, communityId: string, signal?: AbortSignal): Promise<RelayEvent[]>;
/** Bound the encoded envelope before JSON parsing, in both browser and broker.
 * Event-array semantics retain their stricter independent 8 MiB budget. */
export declare function readSnapshotText(response: Response): Promise<string>;
