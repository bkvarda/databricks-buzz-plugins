import { type ReadTransport, type Signer } from "./transport";
export declare const nativeWriteKinds: readonly [30078, 7, 9, 1984, 9000, 9001, 30030, 30175, 30177, 30178, 30315, 40003, 40100, 42000, 45010, 30620, 46020, 5];
/** Cancellation stops a native read at once; a dispatched native write may
 * still complete, so it only fences the JS result. */
export declare function nativeRelayRequest(community: string, path: string, body?: unknown, signal?: AbortSignal): Promise<Response>;
/** Relay media through the native `buzz-media` scheme (`src-tauri/src/relay.rs`),
 * which signs each Blossom `get`, including every `Range` request. */
export declare function nativeMediaUrl(url: string): string;
export declare function nativeRelaySigner(community: string): Signer;
/** Device evidence can be verified before any relay connection exists. */
export declare function verifyNativeStored(values: readonly unknown[]): Promise<import("nostr-tools").VerifiedEvent[]>;
export declare const NOT_A_COMMUNITY_ERROR = "That URL didn't look like a Buzz community. Enter a community URL like wss://communities.buzz.xyz.";
export declare function nativeRelayInfo(community: string, signal?: AbortSignal): Promise<Record<string, unknown>>;
/** The relay's own key as NIP-11 `self` publishes it: 64 lowercase hex, else absent. */
export declare function relaySelf(info: Record<string, unknown>): string | undefined;
export declare function connectNativeTransport(community: string, signal?: AbortSignal): Promise<ReadTransport>;
