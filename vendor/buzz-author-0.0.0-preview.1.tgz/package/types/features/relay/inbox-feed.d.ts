import type { ChannelQueries } from "./contracts";
import type { RelayEvent, ReadFilter } from "./events";
import type { RelayReader } from "./reader";
export type InboxFeedSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    error?: string | undefined;
    /** Exact addressed targets whose stored edits/deletions are not settled. */
    incomplete: readonly string[];
}>;
/** The session owns finite, verified, viewer-addressed history. No new live route,
 * polling, or parallel channel store. Current membership gates completeness targets. */
export declare function createInboxFeed({ viewer, reactionReader, relayAuthor, signingAuthority, channels, reader, addressedRead, retainedEvent, retainedEditIds, notify, }: {
    viewer: string;
    reactionReader?: RelayReader;
    relayAuthor?: string | undefined;
    signingAuthority?: string | undefined;
    channels: ChannelQueries;
    reader: RelayReader;
    /** Private lookups in the existing bounded unread evidence owner. */
    retainedEvent: (id: string) => RelayEvent | undefined;
    retainedEditIds: (ids: readonly string[]) => readonly string[];
    /** Verified session admission calls prepare before publishing unread evidence. */
    addressedRead: (filter: ReadFilter, signal: AbortSignal, prepare: (events: readonly RelayEvent[]) => void) => Promise<readonly RelayEvent[]>;
    notify?: (listener: () => void) => void;
}): Readonly<{
    reactions: {
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            items: readonly import("./inbox-reactions").InboxReaction[];
            error?: string | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        subscribeArrival(listener: (event: RelayEvent) => void): () => void;
        ensure: () => Promise<void>;
        refresh: () => Promise<void>;
        receive(events: readonly RelayEvent[], phase?: "live" | "replay"): void;
        clear: () => void;
        reconnect(): void;
        dispose(): void;
    };
    snapshot: () => Readonly<{
        status: "idle" | "loading" | "ready" | "error";
        error?: string | undefined;
        /** Exact addressed targets whose stored edits/deletions are not settled. */
        incomplete: readonly string[];
    }>;
    subscribe(listener: () => void): () => void;
    ensure: () => Promise<void>;
    refresh: () => Promise<void>;
    stale(): void;
    reconnect(): void;
    clear: () => void;
    purge: () => void;
    dispose(): void;
}>;
