import type { UploadedAttachment } from "./attachments";
import { type CustomEmoji } from "./emoji";
import { type RelayEvent } from "./events";
import type { Priority, RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
export type EmojiSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    entries: readonly CustomEmoji[];
    /** The viewer's own latest set: the only one this client may republish. */
    mine: readonly CustomEmoji[];
    error?: string | undefined;
}>;
export type EmojiAuthoring = Readonly<{
    writer: RelayWriter;
    upload?(file: File, signal: AbortSignal): Promise<UploadedAttachment>;
}>;
/** Community-owned latest complete member sets, including empty replacement evidence.
 * No LRU eviction: forgetting a replacement can resurrect a removed shortcode. */
export declare function createEmojiDirectory(reader: RelayReader, notify?: (listener: () => void) => void, viewer?: string, authoring?: EmojiAuthoring): {
    queries: Readonly<{
        snapshot: () => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            entries: readonly CustomEmoji[];
            /** The viewer's own latest set: the only one this client may republish. */
            mine: readonly CustomEmoji[];
            error?: string | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        ensure: (priority?: Priority) => Promise<void>;
        refresh: () => Promise<void>;
        remove?: (name: string) => Promise<void>;
        upload?: (file: File, signal: AbortSignal) => Promise<UploadedAttachment>;
        add?: (name: string, url: string) => Promise<string>;
    }>;
    accept: (incoming: readonly RelayEvent[]) => void;
    clear: () => void;
    reconnect: () => void;
    /** A continuous profiles replay delivered every set change since the last
     * connection heard the relay, so a complete ready catalog stays as it is.
     * Anything else, a read still out from before the drop included, reads
     * again as on any reconnect. */
    resume(): void;
    tags(content: string): string[][];
    dispose(): void;
};
