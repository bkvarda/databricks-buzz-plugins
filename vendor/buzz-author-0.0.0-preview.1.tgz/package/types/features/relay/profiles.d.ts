import type { EventData } from "./events";
import type { Profile } from "./contracts";
/** Kind 0 metadata. Only the author's own latest event counts. */
export declare function foldProfiles(events: readonly EventData[]): Map<string, Profile>;
