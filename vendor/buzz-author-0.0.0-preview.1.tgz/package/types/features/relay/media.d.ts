export declare function saveData(): boolean;
export declare function wasIntended(url: string): boolean;
/** Opening frames captured by video previews, so a remounted virtualized row
 * reuses its poster instead of seeking and re-encoding. Bounded by encoded
 * size; disposing session media (cache clear, access purge, teardown) forgets
 * them and refuses captures that began before. */
export type OpeningFrame = Readonly<{
    poster: string;
    width: number;
    height: number;
}>;
export declare function openingFrame(source: string): OpeningFrame | undefined;
export declare function openingFrameCapture(): number;
export declare function rememberOpeningFrame(source: string, frame: OpeningFrame, capture: number): void;
export declare function decodedImageCapture(): number;
export declare function hasDecodedImage(owner: object, source: string): boolean;
/** Claims the retained element; a concurrent mount of the source gets none. */
export declare function takeDecodedImage(owner: object, source: string): HTMLImageElement | undefined;
export declare function retainDecodedImage(owner: object, source: string, image: HTMLImageElement, capture: number): void;
/** Avatar request warming, the react-native-web Image model: fetch and
 * decode() into detached images, then retain nothing. The browser's own HTTP
 * and decoded-image caches serve the real <img> mounts. Never warms
 * originals/attachments that this renderer doesn't display. */
export declare function createMediaPreparation(): {
    prepare(urls: readonly string[]): void;
    /** Prefetch-path warming: appends speculation instead of replacing it, so
     * serial background channel reads accumulate avatars across channels. */
    warm(urls: readonly string[]): void;
    stats: () => {
        active: number;
        queued: number;
        prefetched: number;
        decoded: number;
    };
    dispose(): void;
};
