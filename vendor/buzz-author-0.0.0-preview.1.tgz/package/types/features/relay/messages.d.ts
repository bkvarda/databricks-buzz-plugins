import type { ProfileQueries } from "./profile-directory";
import { type UploadedAttachment } from "./attachments";
import { type CustomEmoji } from "./emoji";
import type { EventTemplate } from "nostr-tools";
import { type ChannelMessage } from "./contracts";
import type { EventData } from "./events";
import type { Outbox, OutboxRecovery } from "./outbox";
/** Owner authorization is supplied only after the agent's signed profile is verified. */
export type AgentOwnerAuthorization = Readonly<{
    agentId: string;
    ownerId: string;
}>;
/** NIP-56 types accepted by the Buzz relay for message reports. */
export declare const REPORT_TYPES: readonly ["spam", "profanity", "nudity", "impersonation", "malware", "illegal", "other"];
export type ReportType = (typeof REPORT_TYPES)[number];
/** `["effort", agentPubkey, level]` and `["model", agentPubkey, model]`: what
 * an addressed agent's owner asks of its next run. Only the owner is honoured. */
export declare const EFFORT_TAG = "effort";
export declare const MODEL_TAG = "model";
export type RunPick = Readonly<{
    model?: string;
    effort?: string;
}>;
/** The model and effort picked for each addressed agent, by pubkey. */
export type MentionPicks = Readonly<Record<string, RunPick>>;
/** Domain convenience only. Delivery and read reconciliation remain session-owned. */
export declare function createMessages(outbox: Outbox | undefined, viewer: string | undefined, find: (id: string) => EventData | undefined, emojiTags: (content: string) => string[][], validateMentions: (channelId: string, pubkeys: readonly string[]) => void, canWrite?: (channelId: string, owner?: AgentOwnerAuthorization) => boolean, relayOrigin?: string, 
/** Resolves on relay OK. Reports are never echoed, so they bypass the outbox. */
publishReport?: (template: EventTemplate) => Promise<void>, 
/** Explicit relay NIP-11 self; never inferred from contacts or a displayed row. */
signingAuthority?: string, profiles?: ProfileQueries, 
/** Who a message in the channel addresses without a mention: a one-to-one
 * DM's other member. A pick may name them as well as a mention. */
unmentionedRecipients?: (channelId: string) => readonly string[], 
/** Events whose `buzz:copy-of` tag names this message id (sent-to-channel copies). */
copiesOf?: (id: string) => readonly EventData[]): Readonly<{
    send(channelId: string, content: string, mentions?: readonly string[], attachments?: readonly UploadedAttachment[], recovery?: OutboxRecovery, references?: readonly string[], picks?: MentionPicks): string;
    /** Copy an authored reply as a fresh top-level event, preserving its displayed semantics. */
    sendToChannel(row: ChannelMessage, root?: ChannelMessage): string;
    reply(channelId: string, rootId: string, content: string, mentions?: readonly string[], attachments?: readonly UploadedAttachment[], parentId?: string, references?: readonly string[], picks?: MentionPicks, mediaTargetUrl?: string): string;
    /** Supply the current folded attachmentSourceId, or the row ID for original media. */
    edit: (messageId: string, content: string, attachmentSourceId: string) => string;
    /** Verified owner edit. Empty text removes the message, as in the composer.
     * As a guest it signs only once `profiles.owner` names the viewer; an
     * earlier call fails delivery as read-only, and `retry(id)` resends it. */
    editOwnedAgent(messageId: string, content: string, attachmentSourceId: string): Promise<string>;
    react(messageId: string, content: string, emoji?: CustomEmoji): string;
    remove: (eventIds: readonly string[], authorization?: AgentOwnerAuthorization) => string;
    /** Undefined when this connection cannot publish reports. */
    report: ((messageId: string, type: ReportType, note?: string) => Promise<void>) | undefined;
    reactionTarget(event: Pick<EventData, "kind" | "tags">): string | undefined;
    retry(id: string): void;
}>;
