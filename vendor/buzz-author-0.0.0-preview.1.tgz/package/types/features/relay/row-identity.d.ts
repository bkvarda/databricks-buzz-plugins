import type { ChannelMessage } from "./contracts";
/** Reuse immutable rows whose complete folded value is unchanged. */
export declare function shareMessageRows(previous: readonly ChannelMessage[], next: readonly ChannelMessage[]): readonly Readonly<{
    id: string;
    channelId: string;
    delivery?: import("./outbox").Delivery | undefined;
    deliveryError?: string | undefined;
    authorId: string;
    signerId?: string | undefined;
    workflowOwnerId?: string | undefined;
    createdAt: number;
    createdAtMs?: number;
    content: string;
    sourceContent?: string;
    agentEnvelope?: true;
    audience?: "agents";
    diff?: Readonly<{
        filePath?: string | undefined;
        repoUrl?: string | undefined;
        commitSha?: string | undefined;
        description?: string | undefined;
        truncated: boolean;
    }>;
    membership?: import("./contracts").MembershipChange;
    huddle?: Readonly<{
        room: string;
        state: "started" | "ended";
        endedAt?: number;
    }>;
    edited?: true;
    attachmentSeams?: readonly number[];
    mentions: readonly string[];
    mentionReferences?: readonly string[];
    attachmentSourceId?: string;
    attachments: readonly import("./contracts").Attachment[];
    emoji?: readonly import("./emoji").CustomEmoji[];
    reactions: readonly import("./contracts").MessageReaction[];
    threadRootId?: string | undefined;
    replyParentId?: string | undefined;
    sentFromThread?: Readonly<{
        rootId: string;
        excerpt?: string | undefined;
    }> | undefined;
    replyCount: number;
    participants: readonly string[];
}>[];
