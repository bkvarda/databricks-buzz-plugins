import type { SidebarPreferences } from "./sidebar-preferences";
/** Device-local resume data, never proof of current access or permission to write. */
export type SavedStartup = {
    discovery?: {
        savedAt: number;
        relayAuthor: string;
        events: unknown[];
        profiles?: unknown[];
    };
    preferences?: {
        savedAt: number;
        data: SidebarPreferences;
    };
};
/** Signed wire records only. The owner re-verifies before displaying cached history.
 * A cache hit is never authority for current membership or freshness. No keys/tokens are persisted. */
export type SavedHead = {
    channelId: string;
    savedAt: number;
    events: unknown[];
    profiles: unknown[];
};
export interface HeadPersistence {
    read(): Promise<SavedHead[]>;
    readStartup?(): Promise<SavedStartup | undefined>;
    writeStartup?(patch: SavedStartup): Promise<void>;
    write(head: SavedHead): Promise<void>;
    remove(channelId: string): Promise<void>;
    retain(channelIds: readonly string[]): Promise<void>;
    clear(): Promise<void>;
    close(): void;
}
export declare function createHeadPersistence(viewer: string, relay: string): HeadPersistence;
