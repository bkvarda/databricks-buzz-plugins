import type { ChannelQueries } from "./contracts";
import type { ReadTransport } from "./transport";
import type { RelayReader } from "./reader";
import type { Outbox } from "./outbox";
import type { ProfileSearch } from "./profile-search";
import { type VerifiedProfile, type VerifiedProfileAuthority } from "./verified-profile";
/** The longest text the community people search accepts. */
export declare const PEOPLE_SEARCH_MAX_LENGTH = 100;
/** Opening is idempotent by participant set; first messages use the durable outbox. */
export declare function createDirectMessages(transport: ReadTransport | null, reader: RelayReader, channels: ChannelQueries, outbox: Outbox | undefined, journal: Pick<Outbox, "snapshot" | "subscribe"> | undefined, lifetime: AbortSignal, directoryReader: RelayReader, searchProfiles: ProfileSearch, verifiedAuthority: () => VerifiedProfileAuthority | undefined): Readonly<{
    available: boolean;
    /** Observe relay-confirmed opens; opening also unhides the DM on the relay. */
    subscribeOpened(listener: (id: string) => void): () => undefined;
    people(query: string, page: number, signal: AbortSignal): Promise<{
        people: {
            pubkey: string;
            name: string;
            username?: string;
            picture?: string;
            isAgent?: true;
            ownerPubkey?: string;
        }[];
        hasMore: boolean;
    }>;
    /** One bounded read of the community's verified names for a search page,
     * with the authority that checked them. Like `people`, it stays out of the
     * shared profile views. Undefined when nothing was checked: the community
     * advertises no authority, or it changed during the read. */
    verified(pubkeys: readonly string[], signal: AbortSignal): Promise<{
        authority: VerifiedProfileAuthority;
        profiles: ReadonlyMap<string, VerifiedProfile>;
    } | undefined>;
    open(pubkeys: readonly string[], signal: AbortSignal): Promise<string>;
    delivery(id: string): import("./outbox").Delivery | undefined;
    delivered(id: string, channelId: string, signal: AbortSignal): Promise<void>;
}>;
