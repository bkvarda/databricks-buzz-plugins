import type { LiveSocket } from "./live";
/** No reconnect policy here. live.ts owns connection generations and NIP-42. */
export declare class NativeSocket implements LiveSocket {
    private readonly url;
    readyState: number;
    readonly connectionTimeoutMs = 90000;
    onopen: LiveSocket["onopen"];
    onmessage: LiveSocket["onmessage"];
    onerror: LiveSocket["onerror"];
    onclose: LiveSocket["onclose"];
    private readonly id;
    private browser?;
    private closed;
    constructor(url: string);
    private connect;
    private refuse;
    send(data: string): void;
    private finish;
    close(): void;
}
export declare const nativeSocket: (url: string) => LiveSocket;
