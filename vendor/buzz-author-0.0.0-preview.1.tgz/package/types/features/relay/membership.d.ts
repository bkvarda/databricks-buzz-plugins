import type { ChannelMessage, MembershipChange } from "./contracts";
import type { EventData } from "./events";
/** Content rows retained by channel history/live windows, not the unread kind set. */
export declare const CHANNEL_ROW_KINDS: number[];
export declare const channelRowKind: (kind: number) => boolean;
/** Only the session's verified relay identity may describe membership activity. */
export declare function membershipChange(event: EventData, relayAuthor: string): MembershipChange | undefined;
/** Shared profile demand includes system actors/subjects without inventing mentions. */
export declare function rowProfileIds(row: ChannelMessage): readonly string[];
/** Activity never replaces the latest conversational sidebar preview. */
export declare function messagePreview(rows?: readonly ChannelMessage[]): string | undefined;
