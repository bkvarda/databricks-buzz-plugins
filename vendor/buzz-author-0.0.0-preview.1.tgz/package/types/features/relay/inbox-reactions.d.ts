import type { ChannelQueries, ChannelMessage } from "./contracts";
import type { RelayEvent } from "./events";
import type { RelayReader } from "./reader";
export type InboxReaction = Readonly<{
    id: string;
    channelId: string;
    message: ChannelMessage;
    events: readonly RelayEvent[];
    createdAt: number;
}>;
export type ReactionFeedSnapshot = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    items: readonly InboxReaction[];
    error?: string | undefined;
}>;
/** Bounded addressed reaction evidence. No message reading intent or counters.
 * The reader supplies verified events; reference/access admission happens only
 * after exact targets and their edit/deletion closure have been resolved. */
export declare function createInboxReactions({ reader, viewer, channels, relayAuthor, signingAuthority, notify, }: {
    reader: RelayReader;
    viewer: string;
    channels: ChannelQueries;
    relayAuthor?: string | undefined;
    signingAuthority?: string | undefined;
    notify: (listener: () => void) => void;
}): {
    snapshot: () => Readonly<{
        status: "idle" | "loading" | "ready" | "error";
        items: readonly InboxReaction[];
        error?: string | undefined;
    }>;
    subscribe(listener: () => void): () => void;
    subscribeArrival(listener: (event: RelayEvent) => void): () => void;
    ensure: () => Promise<void>;
    refresh: () => Promise<void>;
    receive(events: readonly RelayEvent[], phase?: "live" | "replay"): void;
    clear: () => void;
    reconnect(): void;
    dispose(): void;
};
