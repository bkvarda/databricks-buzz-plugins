import type { ReadFilter, RelayEvent } from "./events";
import { ReadError } from "./errors";
export type ThreadCursor = Readonly<{
    created_at: number;
    id: string;
}>;
export declare class MissingThreadBounds extends ReadError {
    readonly legacyRows: boolean;
    constructor(legacyRows?: boolean);
}
export declare const canonicalChannel: RegExp;
/** Same authority normalization as buzz-core::tenant::normalize_host. Never use the local broker host. */
export declare function threadAuthority(origin: string): string;
/** NIP-CW thread-mode v1, identical to buzz-core::thread_window::Request::binding. */
export declare function threadBinding(filter: ReadFilter, origin: string, viewer: string): Promise<string>;
export declare function threadBounds(event: RelayEvent): {
    hasMore: boolean;
    cursor: ThreadCursor | null;
};
/** Runs on signature-verified finite results BEFORE session admission. Missing bounds
 * are distinct from invalid bounds; only the first probe may choose a clean legacy restart. */
export declare function verifyThreadWindows(filters: readonly ReadFilter[], events: readonly RelayEvent[], origin: string | undefined, viewer: string, relayAuthor: string): Promise<void>;
