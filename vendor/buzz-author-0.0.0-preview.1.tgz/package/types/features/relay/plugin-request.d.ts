import type { EventData } from "./events";
/** The id in a message's signed `plugin-request` tag. The `plugin_request`
 * tool writes it; the plugin request card reads it. */
export declare function pluginRequestId(event: EventData): string | undefined;
