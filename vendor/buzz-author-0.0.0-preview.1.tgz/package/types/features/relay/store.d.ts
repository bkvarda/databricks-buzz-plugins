import type { Outbox } from "./outbox";
import { type RelayProfiler } from "./profiling";
import type { ChannelQueries } from "./contracts";
import { type RelayEvent } from "./events";
import type { RelayReader } from "./reader";
import type { ProfileDirectory } from "./profile-directory";
import type { HeadPersistence } from "./persistence";
import { MessageClock } from "./message-order";
export type ChannelStoreOptions = {
    profiling?: RelayProfiler;
    maxWindows?: number;
    unavailableReason?: string;
    prepared?: boolean;
    /** Local resume session has no network authority or writer. */
    cachedOnly?: boolean;
    /** Prioritize the previous conversation; other saved heads restore in background. */
    initialChannelId?: string | undefined;
    /** Warm every roster channel's head in the background before it is opened. */
    warm?: boolean;
    persistence?: HeadPersistence;
    maxDiscoveryBytes?: number;
    maxHeadBytes?: number;
    maxHeads?: number;
    maxHistoryRows?: number;
    maxHistoryBytes?: number;
    /** Public directory budget in whole pages; at most the default 20,000. */
    maxPublicDirectory?: number;
    /** Public directory page size, at most the default 500. */
    publicDirectoryPage?: number;
    now?: () => number;
    local?: Pick<Outbox, "snapshot" | "subscribe">;
    /** The session's send clock; rendered windows raise its channel watermarks. */
    clock?: MessageClock;
    notifyListener?: (listener: () => void) => void;
};
/** Session-owned read model. Broad byte-bounded heads are separate from the small history LRU.
 * Preparing a head never mounts a timeline or evicts a subscribed history window. */
export declare function createChannelStore(transport: (RelayReader & {
    viewer: string;
    relayAuthor: string;
    /** Explicit NIP-11 self; only it may attribute messages to others. */
    archiveAuthority?: string | undefined;
    media(url: string, size?: "small"): string | undefined;
    /** `ids` names the channels that lost access when known; omitted means any. */
    revokeAccess(commit: () => void, ids?: readonly string[]): void;
    /** A complete roster read applied. A replica can lag, so a channel it
     * left out may still list the viewer; `unlisted` asks the writer. */
    rosterComplete?(): void;
    visible(events: readonly RelayEvent[]): readonly RelayEvent[];
    /** Reverified, authorized disk evidence, before any restored rows become observable. */
    restored?(events: readonly RelayEvent[]): void;
    /** Returns true when session post-subscribe catch-up owns this demand. */
    demand?(channelId: string): boolean;
    rosterChanged?(strong?: boolean): void;
    /** The relay advertises NIP-CL; label lookups are refused without it. */
    channelIdentity?: true | undefined;
}) | null, directory: ProfileDirectory, options?: ChannelStoreOptions): {
    queries: ChannelQueries;
    roster: () => Readonly<{
        state: "idle" | "pending" | "verified" | "deferred" | "error";
        error?: string;
        /** Set with an error that a later retry can fix; see isTransientFailure. */
        transient?: true;
    }>;
    /** A full roster read is still due: the last one did not verify, or a
     * retired exact confirmation left a strong read owed. */
    rosterOwed: () => boolean;
    /** Preserve a retired exact confirmation's routing without scheduling work.
     * The next refresh/Retry owns dispatch and the existing cooldown. */
    requireStrongListRead(): void;
    retryList(): void;
    restore: () => Promise<void>;
    canAccess: (id: string) => boolean;
    canParticipate: (id: string) => boolean;
    canWrite: (id: string) => boolean;
    unlisted: (ids: readonly string[], signal: AbortSignal) => Promise<string[]>;
    purgeAccess: (visible: (events: readonly RelayEvent[]) => readonly RelayEvent[]) => void;
    denyChannel: (channelId: string, error: unknown) => void;
    suspendPreviews(ids: readonly string[]): void;
    suspendedPreviews: () => string[];
    acceptDiscovery: (events: readonly RelayEvent[], complete?: ReadonlySet<string>, started?: ReadonlyMap<string, RelayEvent>, cached?: boolean, readProof?: boolean) => boolean | undefined;
    accept: (events: readonly RelayEvent[]) => void;
    clearCache: () => Promise<void>;
    dispose: () => void;
    /** A disconnected stream invalidates a head's freshness lease, not its content.
     * Inactive cached heads will revalidate when demanded, without an all-roster read.
     * The session drops its queued catch-ups with the stream, so an empty window
     * that only a queued catch-up marked loading becomes idle: the next ensure()
     * reads it again. Running reads settle their own windows when cancelled.
     * The rows held now are what the catch-up must reach; a second drop before
     * one completes keeps that snapshot, and a window reading its head before
     * the stream is back takes one from that read. */
    staleHeads(): void;
    /** Revalidate only a retained reader after establishing the stream. An unopened
     * channel needs no eager HTTP head; its normal ensure() owns that finite handoff.
     * Live replay covers minutes, not a long disconnect, so the head may stop short
     * of the rows the reader kept across the drop: page back from it until one is
     * reached, merging each page as it lands. Past the page bound, or when a page
     * fails or is cancelled, the kept rows go and the window continues from the
     * pages read rather than showing a gap as history. */
    catchUp(channelId: string): Promise<boolean>;
    /** Also settles queued obligations refused before catchUp could dispatch. */
    catchUpFailed(channelId: string, error: unknown): void;
    retainedChannels: () => string[];
    retainedEvent(id: string): import("nostr-tools").VerifiedEvent | undefined;
    retainedEvents(): RelayEvent[];
    demandedChannels: () => string[];
    /** A catch-up head read is queued: the rows wait to be revalidated, an
     * empty window is loading, and an earlier failure is no longer the answer.
     * catchUp settles it again. */
    catchUpQueued(channelId: string): void;
    diagnostics: () => {
        heads: {
            entries: number;
            bytes: number;
        };
        media: {
            active: number;
            queued: number;
            prefetched: number;
            decoded: number;
        };
        historyRows: number;
    };
};
