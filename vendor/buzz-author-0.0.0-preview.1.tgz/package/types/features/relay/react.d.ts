import type { ChannelMessage, ChannelQueries, ChannelSummary } from "./contracts";
import type { ProfileQueries } from "./profile-directory";
export declare function useChannelList(queries: ChannelQueries): Readonly<{
    status: import("./contracts").ListStatus;
    coverage?: "partial";
    asOf?: number;
    activityStatus?: "idle" | "loading" | "ready" | "error" | "unavailable";
    channels: readonly ChannelSummary[];
    error?: string;
}>;
/**
 * The roster without its live activity: previews and activity replace the list
 * on every message, so a ready list that changed only those fields keeps the
 * previous snapshot. Read `preview` and `lastActivityAt` from useChannelList.
 */
export declare function useChannelRoster(queries: ChannelQueries): Readonly<{
    status: import("./contracts").ListStatus;
    coverage?: "partial";
    asOf?: number;
    activityStatus?: "idle" | "loading" | "ready" | "error" | "unavailable";
    channels: readonly ChannelSummary[];
    error?: string;
}>;
export declare function useChannelWindow(queries: ChannelQueries, channelId: string): Readonly<{
    channelId: string;
    status: import("./contracts").WindowStatus;
    rows: readonly ChannelMessage[];
    hasMore: boolean;
    loadingOlder: boolean;
    error: string | undefined;
    freshness?: "cached" | "verified";
    historyLimited?: boolean;
    refreshing?: boolean | undefined;
}>;
/** The directory's purge generation. Read it in an effect that ensures the
 * profiles a view shows, so the view ensures them again after an access purge. */
export declare function useProfileGeneration(queries: ProfileQueries | undefined): number;
export declare function useRowProfiles(queries: ProfileQueries, rows: readonly ChannelMessage[]): ReadonlyMap<string, Readonly<{
    verified?: import("./verified-profile").VerifiedProfile;
    name: string;
    nameIsFallback?: true;
    username?: string;
    picture?: string;
    about?: string;
    nip05?: string;
    isAgent?: true;
    ownerPubkey?: string;
}>>;
/** Subscribe to replacement as well as connection readiness; never capture a startup session once. */
export declare function useRelayConnection(relay: import("./service").RelayData): Readonly<{
    status: "disconnected" | "connecting" | "ready" | "error";
    generation: number;
    scope?: string;
    origin?: string;
    session: import("./session").RelaySession;
    viewer?: string;
    error?: string;
    cached?: true;
    restoring?: true;
    retrying?: true;
    denied?: true;
}>;
