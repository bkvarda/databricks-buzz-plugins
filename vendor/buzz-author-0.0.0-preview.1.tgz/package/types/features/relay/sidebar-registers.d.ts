/** Section and section-choice registers. No persistence or publication owner. */
export type SidebarRegister = [number, string, unknown];
type Coordinate = "channel-sections" | "channel-sort" | "channel-filter";
/** Metadata is authoritative; never trust a conflicting legacy projection. */
export declare function projectSidebarRecord(coordinate: Coordinate, value: Record<string, unknown>): Record<string, unknown>;
/**
 * Apply only the requested leaves; preserve every other register and tombstone.
 * With `all`, any change restamps every requested leaf (a whole-list reorder).
 */
export declare function editSidebarRecord(coordinate: Coordinate, current: Record<string, unknown>, createdAt: number, writes: readonly (readonly [readonly string[], unknown])[], now?: number, all?: boolean): Record<string, unknown>;
/** Insertion uses canonical orders, not the densely numbered legacy projection. */
export declare function nextSidebarSectionOrder(current: Record<string, unknown>, position?: "first" | "last"): number;
export {};
