/** Controlled by the development log level, alongside broker traffic. */
export declare function relayDebug(...parts: readonly unknown[]): void;
