/** Event kinds delivered on the application's channel subscriptions. */
export declare const CHANNEL_KINDS: number[];
/** Includes channel-scoped kinds that only explicit watches poll. Global kinds
 * and target-derived commands cannot claim a source just by supplying h. */
export declare const channelSourceKind: (kind: number) => boolean;
