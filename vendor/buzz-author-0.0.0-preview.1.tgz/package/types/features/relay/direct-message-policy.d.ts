/** Participant-set policy shared by the app and the existing browser broker. */
export declare function validDirectMessageParticipants(pubkeys: readonly string[], viewer: string): boolean;
