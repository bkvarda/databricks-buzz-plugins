import type { EventTemplate } from "nostr-tools";
import type { ChannelSummary } from "./contracts.ts";
import { type RelayEvent } from "./events.ts";
export type ChannelLifecycleAction = "archive" | "unarchive" | "delete" | "leave" | "hide";
/** Join is not a confirmed member action: it starts from a nonmember preview.
 * The auto-join switch is a relay owner/admin metadata edit without confirmation. */
export type ChannelLifecycleCommand = ChannelLifecycleAction | "join" | "auto-join-on" | "auto-join-off";
export declare const CHANNEL_LIFECYCLE_KINDS: readonly [9002, 9008, 9021, 9022, 41012];
export declare const DM_VISIBILITY_KIND = 30622;
export declare function lifecycleChannelId(value: string): string;
export declare function lifecycleTemplate(action: ChannelLifecycleCommand, channelId: string): EventTemplate;
/** The host never accepts generic metadata edits or other-member removal. */
export declare function validateLifecycleTemplate(event: EventTemplate): void;
export declare function exactLifecycleTag(event: RelayEvent, name: string): string | undefined;
/**
 * The channel type of relay-signed channel state. NIP-CL puts the type in
 * the first `t` tag; later `t` tags are channel labels, not a second type.
 */
export declare function channelTypeTag(event: RelayEvent): string | undefined;
export declare function lifecycleRecord(events: readonly RelayEvent[], kind: number, id: string, relayAuthor: string): import("nostr-tools").VerifiedEvent | undefined;
export type ChannelLifecycleSettings = Readonly<{
    channelId: string;
    channelType: "stream" | "forum" | "dm" | "system";
    canArchive: boolean;
    canUnarchive: boolean;
    canDelete: boolean;
    deleteUnavailable?: boolean;
    canLeave: boolean;
    canHide: boolean;
    leaveReason?: string;
}>;
export declare function lifecycleSettings(events: readonly RelayEvent[], id: string, viewer: string, relayAuthor: string): ChannelLifecycleSettings;
/**
 * Actions to offer from the session's live channel state, without a read:
 * the signed roster's role hints match its administrator record. `run`
 * still checks fresh relay state before publishing, and the relay decides.
 */
export declare function lifecycleOffer(channel: ChannelSummary, viewer: string, agentOwner: boolean): ChannelLifecycleSettings | undefined;
/** Owners whose verified agent profile could grant the viewer more: none
 * where nothing is offered or a direct role already permits Delete or, if
 * archived, Unarchive. */
export declare function ownerEvidence(channel: ChannelSummary, viewer: string): readonly string[];
/** An owner-role agent's human may archive, unarchive and delete like an owner. */
export declare function ownerAgentGrant(settings: ChannelLifecycleSettings, archived: boolean): ChannelLifecycleSettings;
