import { type MentionDraft } from "../messages/mention-draft";
/** Remove only structured leading recipient tags; literal @ text remains title content. */
export declare function startingChatTitle(value: MentionDraft | string): string;
/** Older clients persisted literal Markdown; accept their default during automatic naming. */
export declare function isStartingChatTitle(name: string, value: MentionDraft | string): boolean;
