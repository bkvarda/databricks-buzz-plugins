import type { ComposerSession } from "../messages/composer-session";
import type { Profile } from "../relay/contracts";
import type { MentionRecipient } from "../messages/mention-draft";
/** Whether a Solo chat has another person in it. Alone, the viewer addresses
 * agents and must tag one; once shared, people can talk without a tag. Only a
 * loaded, non-agent profile counts: a member still loading (or failing to)
 * keeps the tag requirement. */
export declare function soloHasPeople(members: readonly string[] | undefined, viewer: string | undefined, profiles: ReadonlyMap<string, Profile>, agents: ReadonlySet<string>): boolean;
/** Whether every member besides the viewer is a known agent. Stricter than
 * `!soloHasPeople`: a member whose profile hasn't loaded is not known to be an
 * agent, so it counts as a person until it is, and a roster that hasn't
 * loaded (absent, or empty before discovery fills it) is not known at all. */
export declare function soloAgentsOnly(members: readonly string[] | undefined, viewer: string | undefined, agents: ReadonlySet<string>): boolean;
/** Who a saved Solo chat's composer may tag: its people (never the viewer,
 * never an agent it doesn't own) plus the viewer's available agents. */
export declare function soloRoster(members: readonly string[] | undefined, viewer: string | undefined, profiles: ReadonlyMap<string, Profile>, agents: ReadonlySet<string>, selectable: readonly MentionRecipient[]): readonly MentionRecipient[];
/** Live soloHasPeople for one chat, from the channel list, profiles and agent
 * library. Subscribes nothing unless enabled (the conversation is a Solo chat). */
export declare function useSoloHasPeople(session: ComposerSession, channelId: string, enabled: boolean): boolean;
/** Live Solo membership: whether people are in the chat, and whether every
 * member is a known agent (no unloaded profile left to doubt). */
export declare function useSoloMembers(session: ComposerSession, channelId: string, enabled: boolean): {
    withPeople: boolean;
    agentsOnly: boolean;
};
