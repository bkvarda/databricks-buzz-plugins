import { type ChannelDetailsDraft } from "../relay/channel-details-protocol";
import type { ChannelSummary } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import type { MemberAdditionIntent } from "../channel-members/members";
/** Sharing changes access, never presentation or Solo placement. */
export declare function canShareConversation(session: RelaySession, channel?: ChannelSummary): boolean;
export declare const soloChatLink: (id: string) => string;
export declare const soloChatLinkMessage: (id: string, name?: string) => string;
/** Exact selected people are grants to the chat, not the destination or its parent. */
export declare function grantSoloChatAccess(session: RelaySession, channelId: string, people: readonly string[], intents: Map<string, MemberAdditionIntent>, signal: AbortSignal, onConfirmed: (key: string) => void, includeAgents?: boolean, soloParticipant?: boolean, skipArchived?: boolean, beforeDispatch?: () => void): Promise<void>;
/** Conversations whose members a chat can be shared with: channels and DMs. */
export declare function sharesWithMembers(destination: Pick<ChannelSummary, "channelType"> | undefined): boolean;
/** The destination's current members other than the viewer, without archived
 * identities, including oversized rosters so the 100-recipient check sees them. */
export declare function destinationShareAudience(session: RelaySession, destinationId: string, signal: AbortSignal): Promise<string[]>;
/** Captured members a share grants: those missing from at least one chat. */
export declare function missingAccess(sources: readonly ChannelSummary[], audience: readonly string[]): string[];
/** Why sharing these chats with this audience can't succeed, if it can't. */
export declare function shareBlocker(session: RelaySession, sources: readonly ChannelSummary[], audience: readonly string[]): "This channel has too many members to share with at once. Send the link only, or share with people directly." | "You can’t share access to this chat, so some people may not be able to open it. Send the link only, or ask its owner to share it." | undefined;
/** A reason that retrying the same share can't change. */
export declare class Unshareable extends Error {
}
/** The one way to share chats with a channel: give its current members who
 * lack access a membership in each chat. The caller posts the link. Grants
 * already confirmed are skipped, so a retry only adds who is still missing. */
export declare function shareChatsWithChannel(session: RelaySession, sourceIds: readonly string[], channelId: string, { signal, check, audience, grants, onStarted, }: {
    signal: AbortSignal;
    /** Throws to stop before the next grant, e.g. when a draft changed. */
    check?: () => void;
    /** A previously captured audience; read fresh when absent. */
    audience?: readonly string[];
    grants?: Map<string, Map<string, MemberAdditionIntent>>;
    onStarted?: () => void;
}): Promise<readonly string[]>;
/** Promote in place through the existing signed details owner. A retry checks an
 * uncertain save; it never republishes it or resets an unchanged cleanup deadline. */
export declare function applySharedChannelDetails(session: RelaySession, id: string, draft: ChannelDetailsDraft, expected: ChannelDetailsDraft, signal: AbortSignal): Promise<void>;
