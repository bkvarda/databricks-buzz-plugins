export type BackupChoice = Readonly<{
    available: boolean;
    pubkey: string;
    automatic: boolean | null;
}>;
export type IdentitySnapshot = {
    status: "loading";
} | {
    status: "missing";
    busy: boolean;
    error?: string;
    recovery?: RecoveryState;
} | {
    status: "error";
    error: string;
} | {
    status: "ready";
    viewer: string;
};
export type RecoveryResult = {
    candidates: {
        handle: string;
        pubkey: string;
    }[];
    currentPubkey: string | null;
    failedCount: number;
};
export type RecoveryState = {
    status: "waiting";
} | {
    status: "saving";
} | {
    status: "canceling";
} | ({
    status: "choosing";
} & RecoveryResult) | {
    status: "error";
    error: string;
};
/** Native recovery's answer when this build or the tenant has no recovery (`nsec_backup.rs` UNAVAILABLE). */
export declare const RECOVERY_UNAVAILABLE = "Backup recovery is unavailable.";
/** Native recovery's refusal for this account (`nsec_backup.rs` REFUSED: a public org, or no Buzz access). */
export declare const RECOVERY_REFUSED = "Backup recovery is not offered for this account.";
/** A recovery error no retry changes: none here, or the account is refused it. */
export declare const recoveryOff: (recovery: RecoveryState | undefined) => boolean;
export declare function createIdentity(): {
    ready: Promise<string>;
    snapshot: () => IdentitySnapshot;
    subscribe(listener: () => void): () => void;
    retry: () => Promise<void>;
    importKey: (nsec: string) => Promise<void>;
    create: () => Promise<void>;
    /** Whether installed old Buzz left data here; never opens secure storage. */
    legacyAvailable: () => Promise<boolean>;
    /** Reads old Buzz's saved key only now, so any OS prompt follows this click. */
    importLegacy: () => Promise<void>;
    backupAvailable: () => Promise<boolean>;
    beginRecovery: () => Promise<void>;
    installRecovery: (handle: string) => Promise<void>;
    cancelRecovery: () => Promise<boolean>;
    exportKey: () => Promise<string>;
    /** Public consent only; enabling it wakes the configured native uploader after sign-in. */
    getBackupChoice: () => Promise<Readonly<{
        available: boolean;
        pubkey: string;
        automatic: boolean | null;
    }>>;
    /** Pass the key returned by getBackupChoice so a stale selection cannot affect another key. */
    setBackupChoice: (pubkey: string, automatic: boolean) => Promise<Readonly<{
        available: boolean;
        pubkey: string;
        automatic: boolean | null;
    }>>;
    /** Why this build can't wipe, if it can't; `sign_out` enforces it either way. */
    wipeRefusal: () => Promise<string | null>;
    /** Stops agents and restarts; the key (and data, with wipe) goes on next launch. */
    signOut: (choices: {
        wipe: boolean;
        removeAgents: boolean;
    }) => Promise<void>;
    /** The native uploader's status; registers on first read, outside the snapshot. */
    backup: {
        snapshot: () => import("./backup").BackupStatus | undefined;
        ready: () => Promise<Readonly<{
            seq: number;
            pass: number;
            builderlab: boolean;
        } & {
            status: "idle" | "running" | "complete";
        }> | Readonly<{
            seq: number;
            pass: number;
            builderlab: boolean;
        } & {
            status: "waiting";
            reason: "no_consent" | "no_session" | "not_linked";
        }> | Readonly<{
            seq: number;
            pass: number;
            builderlab: boolean;
        } & {
            status: "failed";
            kind: "busy" | "signed_out" | "not_offered" | "other_key_linked" | "invalid_service" | "refused" | "unreachable" | "unconfirmed" | "storage";
        }>>;
        subscribe(listener: () => void): () => void;
        dispose(): void;
    };
    dispose(): void;
};
export type Identity = ReturnType<typeof createIdentity>;
export declare const nativeIdentityEnabled: () => boolean;
