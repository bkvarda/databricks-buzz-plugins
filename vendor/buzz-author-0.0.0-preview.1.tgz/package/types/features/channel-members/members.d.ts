import type { RelaySession } from "../relay/session";
import type { ChannelSummary } from "../relay/contracts";
import type { LocalEvents, OutgoingEvent } from "../relay/outbox";
/** The relay remains authoritative; never offer role changes or DM expansion. */
export declare function canAddMembers(session: {
    viewer?: string | undefined;
    outbox?: {
        supports(kind: number): boolean;
    } | undefined;
}, channel?: ChannelSummary): boolean;
/** A session share adds only to this session. It never opens ordinary Members UI
 * or inherits parent-channel membership. */
export declare function canShareSoloChat(session: RelaySession, channel?: ChannelSummary): boolean;
/** A batch addition is settled by the roster read after it, never resumed. */
export declare const isBatchAddition: (item: OutgoingEvent) => boolean;
export type MemberAdditionIntent = {
    id?: string;
    confirmed?: boolean;
    dismissed?: boolean;
    /** Adds the person as a guest, who can read but not post. */
    role?: "guest";
    /** Outbox recovery is not an explicit request to re-invite a removed member. */
    retry?: true;
};
/** Explicit single-person intent. Membership truth and pending writes stay
 * session-owned. Whatever the outcome, settles the batches it may complete. */
export declare function addChannelMember(...args: Parameters<typeof addOneMember>): Promise<void>;
declare function addOneMember(session: RelaySession, channelId: string, pubkey: string, signal: AbortSignal, intent?: MemberAdditionIntent, receipts?: LocalEvents | undefined, soloParticipant?: boolean): Promise<void>;
/** A batch is the only durable record of the people it names until each is
 * in the roster or has their own addition pending, so only then is it
 * acknowledged. Batches still sending are left to their own sender. */
export declare function settleBatchAdditions(session: RelaySession, channelId: string): Promise<void>;
/**
 * Adds people missing from a channel with one kind:9000 per role and at most
 * 100 people, then reads the roster once. Returns everyone it shows, including
 * people already there. A relay without batch support adds only the first
 * person each event names. Best effort: only an abort throws.
 * Everyone not returned is left to `addChannelMember`, which also says
 * why they failed, as is anyone with an earlier single addition pending, so a
 * stale role is never resent. A batch is never resumed and never blocks one;
 * it stays in Outbox until everyone it names is settled.
 */
export declare function addChannelMembersAtOnce(session: RelaySession, channelId: string, people: readonly string[], intents: ReadonlyMap<string, MemberAdditionIntent>, signal: AbortSignal, soloParticipant?: boolean, 
/** Receipts the single addition reads, including resolved ones. */
receipts?: LocalEvents): Promise<ReadonlySet<string>>;
export {};
