import type { RelaySession } from "../relay/session";
import type { ChannelSummary } from "../relay/contracts";
import type { LocalEvents } from "../relay/outbox";
/** The relay remains authoritative; never offer role changes or DM expansion. */
export declare function canAddMembers(session: {
    viewer?: string | undefined;
    outbox?: {
        supports(kind: number): boolean;
    } | undefined;
}, channel?: ChannelSummary): boolean;
/** A session share adds only to this session. It never opens ordinary Members UI
 * or inherits parent-channel membership. */
export declare function canShareSoloChat(session: RelaySession, channel?: ChannelSummary): boolean;
export type MemberAdditionIntent = {
    id?: string;
    confirmed?: boolean;
    dismissed?: boolean;
    /** Adds the person as a guest, who can read but not post. */
    role?: "guest";
    /** Outbox recovery is not an explicit request to re-invite a removed member. */
    retry?: true;
};
/** Explicit single-person intent. Membership truth and pending writes stay session-owned. */
export declare function addChannelMember(session: RelaySession, channelId: string, pubkey: string, signal: AbortSignal, intent?: MemberAdditionIntent, receipts?: LocalEvents | undefined, soloParticipant?: boolean, allowSoloAgents?: boolean, 
/** Runs synchronously just before a new or retried addition is dispatched. */
beforeDispatch?: () => void): Promise<void>;
