import type { NamingIdentity } from "./policy";
import type { LocalAgents } from "../agents/local";
import { Service, type Context } from "@deepseek-ai/cordis";
import type { ProfileQueries } from "../relay/profile-directory";
import type { AgentLibrary } from "../agents/library";
export type NamingPolicy = {
    id: string;
    /** Compare all displayed aliases across distinct keys; return each key's last
     * supplied alias. Repeated configurations of one key are not namesakes.
     * With `candidates`, the directory passes only the rows `scopeKeys` selects
     * (the candidates and their agents' owners), not the whole cache. */
    resolve(identities: readonly NamingIdentity[], viewer?: string, candidates?: readonly string[]): ReadonlyMap<string, {
        name: string;
        qualifier?: string | undefined;
    }>;
};
export type NameSource = {
    viewer?: string | undefined;
    relayUrl?: string | undefined;
    profiles: ProfileQueries;
    agentLibrary: {
        snapshot(): AgentLibrary & {
            status: string;
        };
        subscribe(listener: () => void): () => void;
        refresh(): Promise<void>;
        retain(): () => void;
    };
};
export type NameProvider = {
    id: string;
    /** Resolve keys against one candidate scope; the requested key always joins it. */
    scope(source: NameSource, candidates?: readonly string[], displayFacts?: readonly NamingIdentity[]): (pubkey: string) => {
        name: string;
        qualifier?: string | undefined;
    } | undefined;
    activate(source: NameSource): undefined | (() => void);
    subscribe?(listener: () => void): () => void;
};
export type IdentityName = Readonly<{
    name: string;
    qualifier?: string | undefined;
    source: "agent-directory" | "public-profile";
}>;
export interface IdentityNameView {
    lookup(pubkey: string, candidates?: readonly string[], displayFacts?: readonly NamingIdentity[]): IdentityName | undefined;
    /** Normalize one candidate scope once for many lookups. */
    scope(candidates?: readonly string[], displayFacts?: readonly NamingIdentity[]): (pubkey: string) => IdentityName | undefined;
    resolve(pubkey: string, fallback?: string, candidates?: readonly string[], displayFacts?: readonly NamingIdentity[]): string | undefined;
    snapshot(): number;
    subscribe(listener: () => void): () => void;
}
export interface IdentityNames {
    bind(source: NameSource): IdentityNameView & {
        dispose(): void;
    };
    register(policy: NamingPolicy): void;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        identityNames: IdentityNames;
    }
}
/** Stable injected service; provider replacement never replaces consumers' handle. */
export declare class IdentityNamesService extends Service implements IdentityNames {
    private readonly control?;
    private readonly entries;
    private readonly registrations;
    constructor(ctx: Context, control?: LocalAgents | undefined);
    register(policy: NamingPolicy): void;
    bind(source: NameSource): IdentityNameView & {
        dispose(): void;
    };
}
/** Without an active policy, use public names and caller fallbacks. */
export declare function bindNames(source: NameSource, providers?: {
    snapshot(): readonly NameProvider[];
    subscribe(listener: () => void): () => void;
}): IdentityNameView & {
    dispose(): void;
};
