import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType } from "react";
import { type Contribution } from "../../plugins/contributions";
export type DecisionQuestion = 
/** Answered with the probability that the statement holds. */
Readonly<{
    type: "yes_no";
    instructions: string;
}>
/** One of 2 to 255 options: value -> when to pick it. */
 | Readonly<{
    type: "choice";
    instructions: string;
    options: Readonly<Record<string, string>>;
}>
/** A place on a scale of 2 to 10 level labels, lowest first. */
 | Readonly<{
    type: "score";
    instructions: string;
    levels: readonly string[];
}>;
export type DecisionRequest = Readonly<{
    /** The text to judge. The provider sees it, so send only what it needs. */
    state: string;
    /** 1 to 32 questions keyed by answer name (at most 64 characters). */
    questions: Readonly<Record<string, DecisionQuestion>>;
    /** How long to wait, 1 to 30 seconds. Defaults to 30. */
    timeoutMs?: number;
    /** The Buzz community (its relay URL) the text comes from. A provider
     * that bills the community, such as Builderlab, refuses a request
     * without one. */
    community?: string;
}>;
export type DecisionAnswer = Readonly<{
    type: "yes_no";
    probability: number;
}> | Readonly<{
    type: "choice";
    choice: string;
    confidence: number;
    /** Option value -> probability, where the provider reports them. */
    probabilities: Readonly<Record<string, number>>;
}> | Readonly<{
    type: "score";
    /** Where the answer falls on the 0-based scale; it can be fractional. */
    score: number;
    confidence: number;
    /** Level index ("0", "1", …) -> probability. */
    probabilities: Readonly<Record<string, number>>;
}>;
/**
 * - `unavailable`: no decision provider is registered.
 * - `missing_credentials`: the provider has no saved key or sign-in.
 * - `unauthorized`: the provider refused the key or sign-in.
 * - `invalid_request`: the questions are malformed or were rejected.
 */
export type DecisionFailure = "unavailable" | "missing_credentials" | "unauthorized" | "invalid_request" | "input_limit" | "timeout" | "service_error" | "invalid_response";
export type DecisionResult = Readonly<{
    outcome: "answered";
    /** The key of the provider that answered. */
    backend: string;
    model: string;
    /** One answer per question, of the question's type. */
    answers: Readonly<Record<string, DecisionAnswer>>;
}> | Readonly<{
    outcome: "failed";
    /** The provider that was asked; undefined when none is registered. */
    backend: string | undefined;
    reason: DecisionFailure;
}>;
/** What a provider's `decide` resolves with. The host checks it. */
export type DecisionReply = Readonly<{
    outcome: "answered";
    model: string;
    answers: Readonly<Record<string, DecisionAnswer>>;
}> | Readonly<{
    outcome: "failed";
    reason: DecisionFailure;
}>;
/**
 * - `checking`: not known yet, for example while a saved key is read.
 *   Callers that need an answer wait.
 * - `ready`: it can answer.
 * - `unconfirmed`: it may be able to answer, but could not check, for
 *   example when the keychain is locked.
 * - `needs-setup`: it cannot answer until the user sets it up in Settings.
 */
export type DecisionProviderStatus = "checking" | "ready" | "unconfirmed" | "needs-setup";
/** A decision provider, as a plugin registers it. */
export type DecisionProvider = Readonly<{
    /** Unique within the plugin. */
    id: string;
    /** The name Settings shows, such as "TypeSafe". */
    label: string;
    /** One line about what it uses, such as "Use your own API key." */
    description: string;
    status(): DecisionProviderStatus;
    subscribe(listener: () => void): () => void;
    /** Answers the request. The request is already checked against the
     * limits, and its `timeoutMs` is set. The host stops waiting at the
     * deadline and aborts `signal`. */
    decide(request: DecisionRequest & {
        timeoutMs: number;
    }, options: {
        signal: AbortSignal;
    }): Promise<DecisionReply>;
    /** Its settings, shown under Settings > Decisions API while it is
     * selected. */
    Settings?: ComponentType<{
        active(): boolean;
    }>;
    /** Lower comes first in Settings. Default 0. */
    order?: number;
}>;
/** What plugins get as `ctx.decisions`. `decide` never rejects. */
export interface Decisions {
    decide(request: DecisionRequest): Promise<DecisionResult>;
    /** The key of the provider that answers this device's decisions, or
     * undefined when none is registered. */
    backend(): string | undefined;
    /** That provider's status, or `unavailable` when there is none. */
    status(): DecisionProviderStatus | "unavailable";
    subscribe(listener: () => void): () => void;
    /** Offers a provider while the calling plugin runs, or until the returned
     * function removes it. `Decisions` exposes no way to choose the provider;
     * the user does in Settings. */
    registerProvider(provider: DecisionProvider): () => void;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        decisions: Decisions;
    }
}
export type RegisteredProvider = Contribution<DecisionProvider>;
export declare const DECISION_BACKEND_KEY = "buzz-decision-backend.v1";
/** A provider's status; one that throws is unconfirmed. Host code reads
 * provider status only through this. */
export declare const statusOf: (provider: DecisionProvider) => DecisionProviderStatus;
/** The provider that answers when no other default is registered. */
export declare const DEFAULT_DECISION_PROVIDER = "buzz.typesafe/typesafe";
/** Bundled providers that answer, in this order, while the user has not
 * chosen one or their choice is not registered. The first that can answer
 * does; see `DecisionsService.route`. */
export declare const DEFAULT_DECISION_PROVIDERS: readonly string[];
/** Answers come from the provider the user chose, or the first registered
 * default until they choose. Decision text can include private messages, so
 * no other provider gets it without that choice: while a chosen provider
 * that is not a default is not registered, decisions are unavailable rather
 * than sent somewhere else. */
export declare class DecisionsService extends Service implements Decisions {
    private readonly storage;
    private readonly setTimer;
    private readonly registry;
    /** The user's choice in Settings; undefined until they make one. */
    private chosen;
    private sorted;
    private readonly listeners;
    constructor(ctx: Context, storage?: Storage | undefined, setTimer?: (run: () => void, ms: number) => () => void);
    registerProvider(provider: DecisionProvider): () => void;
    /** Host-only: every registered provider, in Settings order. */
    providers: () => readonly RegisteredProvider[];
    /** The provider that answers now, and its status. Without a registered
     * choice, the first default that can answer does; otherwise TypeSafe,
     * whose setup the user can do, `checking` while another default is still
     * finding out whether it can answer. */
    private route;
    private current;
    /** Resolves once the routed provider is not `checking`, or on `signal`. */
    private known;
    backend: () => string | undefined;
    status: () => DecisionProviderStatus | "unavailable";
    /** Host-only: Settings chooses the provider. Not part of `Decisions`. */
    setBackend(key: string): void;
    private notify;
    subscribe: (listener: () => void) => (() => void);
    decide(request: DecisionRequest): Promise<DecisionResult>;
}
/** The limits every provider accepts, or why the request breaks them. */
export declare function checkRequest(request: DecisionRequest): DecisionFailure | undefined;
/** The answers, checked against the questions: every question answered with
 * its own type, a known choice, a place on the scale, values within 0–1.
 * Answers to questions not asked are dropped. */
export declare function checkAnswers(questions: DecisionRequest["questions"], answers: unknown): Readonly<Record<string, DecisionAnswer>> | undefined;
