import type { AgentReads, MemoryListing } from "../agents/reads";
/** How long a shared read may take; each caller can stop waiting sooner. It
 * matches the frontend's bound on the native read, which answers a slow
 * listing partial within it. */
export declare const READ_TIMEOUT_MS = 10000;
/** One read per connection, agent and slug (or full listing) at a time, which
 * concurrent turns and tool calls share. A new connection, even to the same community, may read as
 * someone else, so it shares nothing with an old one. A read stops once every
 * caller sharing it has stopped waiting. */
export declare class MemoryReads {
    private reads;
    read(source: Pick<AgentReads, "connection" | "memoryListing">, agent: string, signal: AbortSignal, slug?: string): Promise<Readonly<{
        entries: readonly import("../../buzz-mcp/client").Memory[];
        deleted?: readonly Readonly<{
            slug: string;
            createdAt: number;
        }>[];
        partial: boolean;
    }>>;
    /** After a memory write, a read that may have started before it is not
     * shared with later callers. */
    forget(connection: object, agent: string): void;
}
/** The `core` memory in a listing (best read alone, by slug): its text, `null` when the agent has none,
 * or undefined when a partial listing may have missed it. */
export declare function coreOf(listing: MemoryListing): string | null | undefined;
/** The `core` memory section of a prompt: its text, a prompt to create one
 * when it is `null`, or nothing when it is unread (`undefined`) or blank. */
export declare function coreMemorySection(memory: string | null | undefined): string;
/** The most of each note `recentNotesSection` shows, in UTF-8 bytes. */
export declare const NOTE_LIMIT: number;
/** Yesterday's and today's `mem/notes/<date>` notes, in a section of a prompt.
 * Dates are this device's, which JS takes as UTC when it has no time zone.
 * Notes are appended to, so a long one keeps its end. A note that is missing,
 * blank or unread adds nothing. */
export declare function recentNotesSection(read: (slug: string) => Promise<MemoryListing>, now?: Date): Promise<string>;
/** Stops waiting when `signal` aborts, even if the read itself does not. */
export declare function abortable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T>;
