import type { EventData } from "../relay/events";
export type Project = Readonly<{
    /** The prompt section; empty when the Canvas is. */
    section: string;
    /** The folders the agent may work in, besides its own workspace. */
    directories: readonly string[];
}>;
/** A Solo chat with no owner's Canvas: says so, so an agent stops following
 * one it was handed before. */
export declare const NO_PROJECT: Project;
export declare function project(canvas: string | undefined): Project;
/** How long a turn waits for its chat's Canvas. */
export declare const CANVAS_TIMEOUT_MS = 4000;
type CanvasHead = Pick<EventData, "pubkey" | "kind" | "created_at" | "tags" | "content">;
/** The channel's Canvas text when `owner`, or an agent they attest, wrote its
 * current head; undefined when it has none or someone else wrote it. A chat
 * the owner's device is still `starting` answers with the Canvas it starts
 * with, before the relay has it. */
export declare function ownerCanvas(canvas: Readonly<{
    available: boolean;
    read(channelId: string): Promise<CanvasHead | null | undefined>;
}> | undefined, owner: string, channelId: string, starting?: string): Promise<string | undefined>;
/** The chat's project from `read`, or undefined when it could not be read in
 * time or there is no reader: the caller keeps what it knew. */
export declare function readProject(read: (() => Promise<string | undefined>) | undefined): Promise<Project | undefined>;
export {};
