import { AcpSession } from "./session";
import type { AcpHooks, Choice, PlatformTools, ServeMcp, Spawn, ToolServer } from "./types";
/** How long a harness has to answer a request that starts it or opens or
 * closes a session. One that does not is stopped. A turn's prompt is never
 * timed. */
export declare const REQUEST_TIMEOUT_MS = 60000;
/** The HTTP MCP server every session declares; its tools are named
 * `buzz__<name>`. */
export declare const TOOL_SERVER = "buzz";
/** How long a harness that failed to start has to exit once stopped. */
export declare const STOP_TIMEOUT_MS = 5000;
/** Never reaches a harness, whatever its hooks or launch say: its Buzz tools
 * come over HTTP MCP, never a Buzz key. */
export declare const PROTECTED_ENV: Readonly<Record<string, null>>;
export declare class AcpProcess {
    private readonly process;
    readonly hooks: AcpHooks;
    private readonly serve;
    readonly exited: Promise<number | null>;
    private readonly sessions;
    /** Sessions whose close is in flight or failed, by id. */
    private readonly closing;
    private readonly calls;
    private requests;
    private buffer;
    private stderr;
    private alive;
    private code;
    private capabilities;
    /** Whether the harness names untitled sessions, read once. */
    private naming;
    private constructor();
    /** Starts the harness with `args` and checks it can reach the Buzz tools.
     * Sessions with tools need `serve`, which starts their MCP server. Once
     * `signal` aborts, it stops the harness and rejects. */
    static start(spawn: Spawn, hooks: AcpHooks, launch: Readonly<{
        cwd: string;
        args?: readonly string[];
        env?: Readonly<Record<string, string | null>>;
        serve?: ServeMcp;
        signal?: AbortSignal;
        /** The one agent the harness runs: its tools get its Buzz credential. */
        agent?: Readonly<{
            pubkey: string;
            relay: string;
        }>;
        /** Given the harness as soon as it has started, before `initialize`, so
         * a caller can keep one whose start fails until it has exited. */
        onProcess?: (acp: AcpProcess) => void;
    }>): Promise<AcpProcess>;
    get running(): boolean;
    get busy(): boolean;
    /** The `agentCapabilities` the harness answered `initialize` with. */
    get agentCapabilities(): Readonly<Record<string, unknown>>;
    /** Whether `initialize` advertised `sessionCapabilities[name]`. */
    advertises(name: string): boolean;
    /** Opens a new session in `cwd`, named `title`, whose system prompt has
     * `systemPrompt` appended. With `named`, the harness names it instead when
     * it names sessions, and `named` takes that name. `tools` answers its Buzz
     * tools; without them it has no tools at all. Each turn runs on the
     * provider and model `choice` gives as it starts. */
    open(launch: Readonly<{
        cwd: string;
        systemPrompt: string;
        title?: string;
        named?: (title: string) => void;
        tools?: ToolServer;
        choice?: () => Choice;
        /** Built-ins beside the Buzz tools, for harnesses that take them. */
        platform?: PlatformTools;
        /** Replaces the harness's own base prompt with `systemPrompt` instead
         * of appending it, for small models that a long prompt throws off. */
        replacePrompt?: boolean;
        /** Given the session as soon as the harness has opened it, before it
         * is set up, so a caller can close one whose open then fails. */
        onSession?: (session: AcpSession) => void;
    }>): Promise<AcpSession>;
    private names;
    /** Ends a session. Its turn, if any, is cancelled first. The harness is
     * asked to close it only when it says it can. A close already started is
     * shared, and one that failed stays failed while the harness runs: `strict`
     * rejects with it, as with a harness that cannot acknowledge one. Once the
     * harness has exited the session counts as closed. */
    close(session: AcpSession, strict?: boolean): Promise<void>;
    private end;
    kill(): Promise<void>;
    /** Stops the harness, and resolves once it has exited or `timeout` ms
     * have passed, whichever is first. */
    stop(timeout?: number): Promise<void>;
    /** Sends a request and resolves with its result. When the harness does not
     * answer within `timeout` ms it is stopped, which fails its sessions. */
    request(method: string, params: Record<string, unknown>, timeout?: number): Promise<unknown>;
    notify(method: string, params: Record<string, unknown>): void;
    private write;
    private readError;
    private read;
    private handle;
    private update;
    /** Answers what the harness asks its client: since tools run without
     * asking, any permission prompt with allow. */
    private answer;
    /** One MCP message for a session's Buzz tools, answered with its JSON-RPC
     * response; a notification gets none. A final message that succeeded ends
     * its turn. The host answers a throw with an internal error. */
    private mcp;
}
