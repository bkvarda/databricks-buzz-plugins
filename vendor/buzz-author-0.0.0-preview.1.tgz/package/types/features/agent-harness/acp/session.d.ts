import type { HostMcpServer } from "../../host/service";
import type { AcpProcess } from "./process";
import type { ActivityReceipt, Choice, Settled } from "./types";
/** A session's settings, as `session/new` and `session/set_config_option`
 * return them. */
export type ConfigOptions = {
    configOptions?: {
        category?: string | null;
        options?: ConfigValue[];
    }[];
};
/** A select's choice, or a group of them. */
export type ConfigValue = {
    value?: string;
    options?: ConfigValue[];
};
/** Every choice's value, groups flattened. */
export declare const valuesOf: (options?: readonly ConfigValue[]) => string[];
/** One conversation's ACP session. Messages sent while a turn runs are
 * steered into it, when the harness can steer; one that arrives as the turn
 * ends, or asks for another model, runs as the next turn. */
export declare class AcpSession {
    private readonly acp;
    readonly id: string;
    /** Serves this session's Buzz tools; closed with it. */
    readonly server?: HostMcpServer | undefined;
    private readonly choice?;
    /** The provider, model and thinking level it runs on, as chosen here. */
    chosen: Choice;
    /** Instructions that lead its first prompt, for a harness that takes no
     * system prompt. */
    private preamble;
    /** The conversation it serves. */
    conversation: string | undefined;
    /** Takes the first name the harness generates for it; a titled session gets
     * none. */
    named: ((title: string) => void) | undefined;
    /** The harness's id for the running turn, which a steer must name. */
    private runId;
    /** Steers waiting for the running turn's id, which the harness sends just
     * after the turn starts. */
    private runWaiters;
    /** A `session/prompt` is in flight. */
    private prompting;
    private readonly steering;
    private steered;
    /** Turns to run, each with the model and level it was asked for, if any. */
    private readonly queue;
    /** The model the running turn runs on; empty is its provider's default. */
    private model;
    /** The thinking level the running turn runs on; empty is the harness's own. */
    private level;
    /** The thinking levels the harness last listed for the session's model. */
    private levels;
    /** Messages sent and not yet answered. */
    private pending;
    private waiters;
    /** The waiter that posts the burst's error or text: the latest message
     * acknowledged, else the latest sent. */
    private owner;
    private readonly active;
    private lastStep;
    /** The receipt each queued request displaced in its scope, superseded only
     * once that request is sent, so a request refused before then gives the
     * scope back, Stop included. */
    private readonly displaced;
    /** The burst's latest error, with the JSON-RPC code of that same error. */
    private lastFailure;
    /** Whether this work answered in Buzz, and what the harness wrote meanwhile: a
     * provider failure comes back as text, and text is never posted. */
    private acted;
    private written;
    private closed;
    /** A final message ended the work: the id of its tool call, whose result
     * cancels the running turn once the harness reports it, then `true` until
     * that turn ends. Meanwhile the turn takes no steers. */
    private ending;
    /** The work the owner stopped, while the harness ends it: the messages it
     * had taken, and their activity. What it wrote meanwhile is not posted, and
     * messages sent since wait for a turn of their own. `ended` is set once
     * the cancel ended the turn, not when the turn finished on its own. */
    private stopped;
    private idlers;
    /** How often its work has been stopped or has ended. */
    private generation;
    constructor(acp: AcpProcess, id: string, 
    /** Serves this session's Buzz tools; closed with it. */
    server?: HostMcpServer | undefined, choice?: (() => Choice) | undefined, 
    /** The provider, model and thinking level it runs on, as chosen here. */
    chosen?: Choice, 
    /** Instructions that lead its first prompt, for a harness that takes no
     * system prompt. */
    preamble?: string);
    get busy(): boolean;
    get working(): boolean;
    get open(): boolean;
    /** The thinking level it was put on; empty while it runs on the harness's own. */
    get effort(): string;
    /** Resolves once nothing runs, waits to run or waits for its answer:
     * unlike `busy`, it waits out the end of the turn after a final `send` too. */
    idle(): Promise<void>;
    /** Sends one user message, whose turn runs on `model` of the provider and
     * thinking level `effort` when given. Resolves when it, and anything sent
     * after it, has been answered, or a final message ended the work. */
    send(text: string, activity?: ActivityReceipt, model?: string, effort?: string, 
    /** A synced level the turn must run on, or it fails before its prompt. */
    kept?: string): Promise<Settled>;
    /** Whether the work running now, if any, still runs unstopped and
     * unfinished when asked later; work after it is not that work. */
    current(): () => boolean;
    /** A final message succeeded: the work counts as done at once, and the
     * turn of tool call `call` ends, unless another message is still waiting
     * for its answer. */
    finished(call?: string): void;
    /** Stops the work: the running turn, as ACP's `session/cancel` does, and
     * the messages waiting for a turn after it, which the harness cannot stop
     * apart. A turn not yet sent is never sent. The work then ends as the
     * harness ends it; a message sent before it has runs as a new turn after. */
    interrupt(): void;
    /** A Buzz tool that answers, such as `send`, succeeded. */
    answered(): void;
    /** Called by the process with each `session/update` for this session. */
    update(update: Record<string, unknown>): void;
    /** Ends the session's work with `error`; nothing more is sent to it. */
    fail(error: string): void;
    private steer;
    /** Ends one request the harness never saw, leaving the rest of the work:
     * unsent, or failed with `error` when it was refused before its prompt.
     * Either way it is undelivered, so what it carried comes back for the next
     * turn. */
    private discard;
    private get handingOff();
    private pump;
    /** Puts the session on the provider, model and thinking level chosen now,
     * or `model` of that provider and level `effort`. A steer joins the running
     * turn, so a change waits for the next. */
    private select;
    /** Notes the thinking levels in a `session/new` or
     * `session/set_config_option` answer, which list the current model's. */
    offer({ configOptions }: ConfigOptions): void;
    private ranAs;
    private acknowledge;
    /** A queued request reached the harness: the receipt it displaced is
     * superseded. */
    private sent;
    /** A queued request left before the harness saw it: its scope goes back to
     * the receipt it displaced, unless a later request has the scope now. */
    private withdraw;
    private done;
    /** The owner's cancel ended the turn, if it was stopping it. */
    private cancelEnded;
    /** Settles the work the owner stopped, leaving messages sent since. */
    private endStopped;
    private settle;
    private quiet;
    private wake;
}
