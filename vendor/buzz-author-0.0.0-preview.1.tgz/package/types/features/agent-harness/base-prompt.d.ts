export declare const BASE_PROMPT: string;
