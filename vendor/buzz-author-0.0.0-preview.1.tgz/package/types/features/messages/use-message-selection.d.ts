import { type RefObject } from "react";
import type { ChannelMessage } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
/** Makes a rendered message list keyboard-selectable within its edit scope. */
export declare function useMessageSelection(list: RefObject<HTMLElement | null>, rows: readonly ChannelMessage[], session: RelaySession): void;
/** For lists that render their own edit scope provider. */
export declare function MessageSelection(props: {
    list: RefObject<HTMLElement | null>;
    rows: readonly ChannelMessage[];
    session: RelaySession;
}): null;
