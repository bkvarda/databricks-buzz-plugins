import { type RefObject } from "react";
/** An unclaimed file or link drop would navigate the webview to it, so the app rejects it. */
export declare function useRejectUnclaimedDrops(): void;
/** Route a file drop to this pane's composer, never another open conversation. */
export declare function useFileDrop(composer: RefObject<HTMLFormElement | null>, enabled: boolean, attach: (files: readonly File[]) => void): boolean;
