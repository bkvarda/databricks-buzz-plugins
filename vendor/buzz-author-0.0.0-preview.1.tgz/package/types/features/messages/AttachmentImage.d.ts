import type { Attachment } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
export declare function AttachmentImage({ attachment, session, source, thumbnail, cached, compact, overlayCount, onOpenReview, onOpenLink, keepMounted, label, }: {
    label?: string;
    attachment: Attachment;
    session?: RelaySession | undefined;
    source: string | undefined;
    thumbnail?: string | undefined;
    cached?: boolean;
    /** Square thumbnail geometry for a condensed image group. */
    compact?: boolean;
    /** Includes the covered image, matching the gallery's remaining count. */
    overlayCount?: number;
    onOpenReview?: (attachment: Attachment, seconds: number) => void;
    onOpenLink?: ((url: string) => boolean) | undefined;
    /** Pins the owning row in a virtualized list; returns the release. */
    keepMounted?: (() => () => void) | undefined;
}): import("react").JSX.Element;
