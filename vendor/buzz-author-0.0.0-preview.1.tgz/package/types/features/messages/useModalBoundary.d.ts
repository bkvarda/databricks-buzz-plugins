import { type RefObject } from "react";
/** Makes a portalled viewer a real modal and restores its available opener. */
export declare function useModalBoundary(backdrop: RefObject<HTMLElement | null>, initialFocus: RefObject<HTMLElement | null>, close: () => void, restoreFocus?: RefObject<HTMLElement | null>): void;
