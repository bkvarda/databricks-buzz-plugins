import { type RefObject } from "react";
import type { RelaySession } from "../relay/session";
/** Wake dwell after owner-controlled positioning, even when geometry is unchanged. */
export declare function readingPositioned(element: HTMLElement | null): void;
type Reading = {
    session: RelaySession;
    channelId: string;
    latestMessageId?: string | undefined;
    rootId?: string | undefined;
    scroller: RefObject<HTMLElement | null>;
    settled: RefObject<boolean>;
    /** True while the list shows its latest row in place of the reader's own,
     * still loading: the rows shown are read, but that bottom is not caught up. */
    restoring?: (() => boolean) | undefined;
    /** False: this list marks nothing read; its owner decides what was read. */
    enabled?: boolean | undefined;
};
/** `useReading` for an owner that renders its own `MessageEditScope`. */
export declare function Reading(props: Reading): null;
/**
 * Consumer-owned observation: focused, visible, settled rows, never virtualizer
 * overscan. Call it inside the `MessageEditScope` this message list shares with
 * its composer, so focus in that composer counts and another surface's does not.
 */
export declare function useReading({ session, channelId, latestMessageId, rootId, scroller, settled, restoring, enabled, }: Reading): void;
export {};
