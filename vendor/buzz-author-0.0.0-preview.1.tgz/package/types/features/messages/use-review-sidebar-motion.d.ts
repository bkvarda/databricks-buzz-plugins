import { type RefObject } from "react";
/** Resize the layout once; move the live picture instead of resizing a GIF every frame. */
export declare function useReviewSidebarMotion(frame: RefObject<HTMLElement | null>, open: boolean): (pointer: boolean) => void;
