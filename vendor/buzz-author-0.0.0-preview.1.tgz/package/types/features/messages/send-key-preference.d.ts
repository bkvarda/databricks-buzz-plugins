/** Device-local choice: ⌘/Ctrl+Enter sends and Enter adds a line. Off by default. */
export declare const sendKeyPreference: {
    read: () => boolean;
    subscribe: (listener: () => void) => () => void;
    usePreference: () => boolean;
    useSaveError: () => "This choice is active, but could not be saved on this device. Try again." | null;
    set: (enabled: boolean) => string | null;
};
export declare const sendWithModEnterPreference: () => boolean, useSendWithModEnterPreference: () => boolean, setSendWithModEnterPreference: (enabled: boolean) => string | null;
