import type { ChannelMessage } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import { requestWork } from "../agents/request-work";
type Activity = RelaySession["agentActivity"];
type Snapshot = ReturnType<Activity["snapshot"]>;
type ActivityRun = {
    ids: string[];
    history: ChannelMessage[];
    latest: ChannelMessage;
    participants: string[];
    requestId: string | undefined;
    followingMessage: ChannelMessage | undefined;
};
export type ActivityPresentation = ActivityRun & {
    /** Retires the live treatment only; coordination history remains readable. */
    retired: boolean;
    outcomes: Pick<ReturnType<typeof requestWork>[number], "agent" | "state" | "reason">[];
    /** Only the latest update run for an agent/request owns live work and Stop. */
    liveParticipants: string[];
    /** Agents whose current work or outcome this group can actually present. */
    presentedParticipants: string[];
    working: boolean;
    /** Latest recorded update belonging to a participant still working here. */
    workingUpdate: ChannelMessage | undefined;
    standalone: boolean;
};
export type ActivityRowPresentation = {
    requestId: string | undefined;
    active: boolean;
    ownsLive: boolean;
    /** Keep a failure's author visible in history shared with other agents. */
    showAuthor?: boolean;
    container: "history" | "bubble" | "standalone";
};
/** The activity snapshot, changing only when these channels' evidence does:
 * work elsewhere in the session does not re-render this conversation. */
export declare function useChannelActivitySnapshot(activity: Activity | undefined, channels: ReadonlySet<string>): Readonly<{
    status: "unavailable" | "disabled" | "connecting" | "listening" | "interrupted";
    records: readonly (Readonly<{
        id: string;
        agent: string;
        createdAt: number;
        plaintext: string;
        envelope?: import("../relay/events").RelayEvent;
    }> & Readonly<{
        receivedAt: number;
        kind: string;
        channelIds: readonly string[];
    }>)[];
    turns: readonly import("../agents/activity").ActivityTurn[];
    local?: readonly import("../agents/local-activity").LocalWork[];
    typing: readonly {
        readonly agent: string;
        readonly channelId: string;
        readonly threadRootId: string | undefined;
        readonly startedAt: number;
        readonly working: boolean;
    }[];
    trimmed: number;
    turnsTrimmed?: boolean;
}> | undefined;
/** Shared projection for timeline and thread; hosts own scrolling and disclosure state. */
export declare function activityPresentation(rows: readonly ChannelMessage[], snapshot: Snapshot | undefined, agents: ReadonlySet<string> | undefined, rootId?: string, canAbsorbFailure?: (failure: ChannelMessage) => boolean): {
    groups: ActivityPresentation[];
    byRow: Map<string, ActivityRowPresentation>;
    representedAgents: Map<string, string[]>;
    repliedAgents: Map<string, string[]>;
    replyRequests: Map<string, string>;
    bubbleAnchors: Set<string>;
};
export declare function useActivityPresentation(rows: readonly ChannelMessage[], activity: Activity | undefined, agents: ReadonlySet<string> | undefined, rootId?: string): {
    groups: ActivityPresentation[];
    byRow: Map<string, ActivityRowPresentation>;
    representedAgents: Map<string, string[]>;
    repliedAgents: Map<string, string[]>;
    replyRequests: Map<string, string>;
    bubbleAnchors: Set<string>;
};
/** Each activity projection allocates fresh row values. Reuse the previous ones
 * while they are equal, so memoized rows skip unrelated activity updates. */
export declare function useStableRowActivity(): {
    activity(id: string, next: ActivityRowPresentation | undefined, container?: "bubble" | "history" | "standalone" | undefined): ActivityRowPresentation | undefined;
    agents(id: string, next: readonly string[] | undefined): readonly string[] | undefined;
};
export {};
