import type { ChannelMessage } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
type Activity = RelaySession["agentActivity"];
type Snapshot = ReturnType<Activity["snapshot"]>;
type ActivityRun = {
    ids: string[];
    history: ChannelMessage[];
    latest: ChannelMessage;
    participants: string[];
    requestId: string | undefined;
    followingMessage: ChannelMessage | undefined;
};
export type ActivityPresentation = ActivityRun & {
    /** Display policy only; a public reply is not lifecycle completion. */
    hidden: boolean;
    retained?: boolean;
    working: boolean;
    standalone: boolean;
};
export type ActivityRowPresentation = {
    requestId: string | undefined;
    active: boolean;
    ownsLive: boolean;
    container: "history" | "bubble" | "standalone";
};
/** The activity snapshot, changing only when these channels' evidence does:
 * work elsewhere in the session does not re-render this conversation. */
export declare function useChannelActivitySnapshot(activity: Activity | undefined, channels: ReadonlySet<string>): Readonly<{
    status: "unavailable" | "disabled" | "connecting" | "listening" | "interrupted";
    records: readonly (Readonly<{
        id: string;
        agent: string;
        createdAt: number;
        plaintext: string;
        envelope?: import("../relay/events").RelayEvent;
    }> & Readonly<{
        receivedAt: number;
        kind: string;
        channelIds: readonly string[];
    }>)[];
    turns: readonly import("../agents/activity").ActivityTurn[];
    local?: readonly import("../agents/local-activity").LocalWork[];
    typing: readonly {
        readonly agent: string;
        readonly channelId: string;
        readonly threadRootId: string | undefined;
        readonly startedAt: number;
        readonly working: boolean;
    }[];
    trimmed: number;
}> | undefined;
/** Shared projection for timeline and thread; hosts own scrolling and disclosure state. */
export declare function activityPresentation(rows: readonly ChannelMessage[], snapshot: Snapshot | undefined, agents: ReadonlySet<string> | undefined, rootId?: string, pinnedIds?: ReadonlyMap<string, number>): {
    groups: ActivityPresentation[];
    byRow: Map<string, ActivityRowPresentation>;
    representedAgents: Map<string, string[]>;
    bubbleAnchors: Set<string>;
};
export declare function useActivityPresentation(rows: readonly ChannelMessage[], activity: Activity | undefined, agents: ReadonlySet<string> | undefined, rootId?: string, pinnedIds?: ReadonlyMap<string, number>): {
    byRow: Map<string, ActivityRowPresentation>;
    representedAgents: Map<string, string[]>;
    bubbleAnchors: Set<string>;
    groups: ActivityPresentation[];
};
/** Retired updates stay in Activity; hiding is not a claim of successful completion. */
export declare function activityDisplayRows<T extends ChannelMessage>(rows: readonly T[], groups: readonly ActivityPresentation[], revealedId?: string): readonly T[];
/** Each activity projection allocates fresh row values. Reuse the previous ones
 * while they are equal, so memoized rows skip unrelated activity updates. */
export declare function useStableRowActivity(): {
    activity(id: string, next: ActivityRowPresentation | undefined, container?: "bubble" | "history" | "standalone" | undefined): ActivityRowPresentation | undefined;
    agents(id: string, next: readonly string[] | undefined): readonly string[] | undefined;
};
export {};
