import type { ChannelMessage } from "../relay/contracts";
import type { ComposerSession } from "./composer-session";
import { type MentionDraft } from "./mention-draft";
/** The next scoped draft remembers only exact agents notified by the sent message. */
export declare function rememberedMentions(session: ComposerSession, draft: MentionDraft, notified: readonly string[]): MentionDraft;
/** A composer with nothing saved starts with the agents the viewer's latest
 * message in its conversation notified, under their current known names:
 * relay history, not a saved draft, so every device derives the same prefill.
 * Classification matches rememberedMentions; a key with no known name is
 * skipped, since a mention span must read `@Name`. */
export declare function seedMentions(session: ComposerSession, seed: Pick<ChannelMessage, "mentions">): MentionDraft;
/** Whether the evidence classifying a message's tagged keys has settled: the
 * agent inventory is complete and every key has a profile or an identity. A
 * seed taken earlier may name a subset of the agents, so a composer keeps it
 * provisional until then. */
export declare function seedEvidenceSettled(session: ComposerSession, seed: Pick<ChannelMessage, "mentions">): boolean;
/** The viewer's latest top-level message in a channel window: the seed for a
 * channel, Huddle, DM or Solo composer. Replies seed their thread instead, and
 * the Huddle and membership rows the viewer signs are not messages. */
export declare function latestOwnMessage(viewer: string, rows: readonly ChannelMessage[]): ChannelMessage | undefined;
/** Who a Solo chat's toolbar holds before it has an audience, whatever the
 * remember-agents preference says. Waits for complete agent choices.
 *
 * Every agent the viewer's latest top-level message in the loaded window
 * tagged that can still be tagged. Without one: the main agent if it is a
 * member; else the first member agent that runs on this computer; else all the
 * chat's usable agent members; else the main agent. */
export declare function seedAgents(session: ComposerSession, channelId: string, rows: readonly ChannelMessage[], admits: (pubkey: string) => boolean, main?: string): readonly string[];
