import type { ComposerSession } from "./composer-session";
export declare function mentionHistory(session: ComposerSession, channelId: string): Map<string, number> | undefined;
export declare function rememberMention(session: ComposerSession, channelId: string, pubkey: string): void;
