import { type RefObject } from "react";
import type { ReportType } from "../relay/messages";
/** Retain submitted work when its modal presentation is dismissed. */
export declare function ReportMessageDialog({ report, close, finalFocus, }: {
    report(type: ReportType, note: string): Promise<void>;
    close(submitted: boolean): void;
    finalFocus?: RefObject<HTMLElement | null>;
}): import("react").JSX.Element | null;
