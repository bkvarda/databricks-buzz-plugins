import type { MessageLinkOrigin } from "./MessageRow";
import { type ReactNode } from "react";
import type { RelaySession } from "../relay/session";
import type { ActivityPresentation } from "./activity-presentation";
import type { ChannelMessage, Profile } from "../relay/contracts";
/** One stable disclosure for a run of activity, showing its latest speaker. */
export declare function ActivityGroupPreview({ group, session, profiles, media, expanded, onToggle, layout, renderHistory, openActivity, canOpenActivity, }: {
    openActivity?: ((target: string, origin?: MessageLinkOrigin) => boolean) | undefined;
    canOpenActivity?: ((target: string) => boolean) | undefined;
    group: ActivityPresentation;
    session?: RelaySession | undefined;
    profiles: ReadonlyMap<string, Profile>;
    media: (url: string, size?: "small") => string | undefined;
    expanded: boolean;
    onToggle: () => void;
    layout?: "timeline" | "thread";
    renderHistory?: (row: ChannelMessage) => ReactNode;
}): import("react").JSX.Element;
