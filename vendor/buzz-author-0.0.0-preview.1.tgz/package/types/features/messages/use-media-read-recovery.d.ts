/** Reload bytes after a network failure. Playback permission and decoding
 * failures remain explicit; recovery never starts playback itself. */
export declare function useMediaReadRecovery(source: string | undefined, failed: () => void, recovered?: () => void): {
    recover: (element: HTMLMediaElement) => boolean;
    cancel(): void;
};
