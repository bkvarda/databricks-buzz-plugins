import { type ReactNode } from "react";
import type { ConversationExtensions } from "../conversation/contracts";
import type { ChannelMessage } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import { type MessageLinkOrigin } from "./MessageRow";
import { type MessageComposerProps } from "./MessageComposer";
import type { PageNavigation } from "../navigation/service";
export type ThreadPanelProps = {
    extensions?: ConversationExtensions | undefined;
    session: RelaySession;
    scope: string;
    channelName: string;
    channelId: string;
    /** Solo agents answer at top level, so a Solo thread is read-only. */
    soloConversation?: boolean | undefined;
    disabled?: boolean | undefined;
    messageId: string;
    /** Channel workspaces retain the editor across same-thread link navigation. */
    retainThread?: boolean | undefined;
    /** The hosting tab strip owns the title, close and Escape. */
    tabbed?: boolean | undefined;
    /** Called with the reader's verified thread root once it is known. */
    onResolvedRoot?: ((rootId: string) => void) | undefined;
    /** Workspace identity is retained when a link's claimed root was wrong. */
    onDifferentThread?: ((requested: string, kept: string) => void) | undefined;
    /** Retry a failed routed opening with fresh navigation authority. */
    onRetryNavigation?: (() => void) | undefined;
    replyRequest?: number | undefined;
    /** Each new value focuses the reply box, keeping its target. */
    focusRequest?: number | undefined;
    /** A saved draft carries its cancellable target through a delayed root read. */
    autoFocus?: MessageComposerProps["autoFocus"];
    /** Inline Inbox visit retains and reveals its exact selected message. */
    revealSelected?: boolean | undefined;
    /** With revealSelected: each new value reveals the selected message again. */
    revealRequest?: number | undefined;
    headerActions?: ReactNode | undefined;
    /** Saved drafts may compose only against a verified matching root. */
    requireReadyRoot?: boolean | undefined;
    onDraftSaved?: (() => void) | undefined;
    active?: boolean | undefined;
    navigation?: PageNavigation | undefined;
    /** Omit to embed the thread: no header or Escape dismissal; the owner supplies both. */
    close?: (() => void) | undefined;
    /** The conversation this thread lives in, named as Inbox rows name it, when
     * the host can show the thread there. */
    parent?: {
        label: string;
        open(): void;
    } | undefined;
    onOpenLink(url: string, origin?: MessageLinkOrigin): boolean;
    onOpenMediaReview?(messageId: string, attachment: ChannelMessage["attachments"][number], seconds: number, hasComments?: boolean, attachments?: ChannelMessage["attachments"]): void;
    canOpenLink?: ((target: string) => boolean) | undefined;
};
/** Safe to retarget through ordinary props; callers do not own internal remount keys. */
export declare function ThreadPanel(props: ThreadPanelProps): import("react").JSX.Element;
