export type DownloadState = "idle" | "pending" | "saved" | "failed";
/** The caller keys its action by attachment/source so each mount owns one lifetime. */
export declare function useNativeDownload(source: string, name: string, savedDuration?: number): {
    state: DownloadState;
    download: () => Promise<void>;
};
