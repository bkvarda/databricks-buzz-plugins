import type { ConversationExtensions } from "../conversation/contracts";
import type { RelaySession } from "../relay/session";
import { type MessageLinkOrigin } from "./MessageRow";
import type { Attachment, ChannelWindow } from "../relay/contracts";
import type { PageNavigation } from "../navigation/service";
export type ChannelTimelineProps = {
    extensions?: ConversationExtensions | undefined;
    channelId: string;
    scope: string;
    viewer?: string | undefined;
    queries: RelaySession;
    /** A parent keyed by connection generation can preserve its timeline on cache promotion. */
    continuityKey?: string | undefined;
    window: ChannelWindow;
    launchPending?: boolean | undefined;
    /** Solo chats page history on scroll; retain an explicit button for errors. */
    historyControl?: "button" | "scroll";
    /** Personal chats keep their compact initial history spacing. */
    chatPresentation?: boolean | undefined;
    /** False: rows open existing threads but offer none to start; see MessageRow. */
    startsThreads?: boolean | undefined;
    onOpenLink(url: string, origin?: MessageLinkOrigin): boolean;
    canOpenLink?: ((target: string) => boolean) | undefined;
    revealMessageId?: string | undefined;
    /** One inline exact visit: focus the verified mounted row, without a page
     * navigation. `focus: false` marks it beside a reader that owns focus. */
    inlineTarget?: Readonly<{
        messageId: string;
        signal: AbortSignal;
        focus?: false;
    }> | undefined;
    /** Draft context starts at the returned tail, never reads/writes canonical scroll. */
    transient?: boolean | undefined;
    /** False: viewing rows marks nothing read; the owner decides what was read. */
    marksRead?: boolean | undefined;
    navigation?: PageNavigation | undefined;
    onOpenThread?(messageId: string, threadRootId: string, intent?: "reply"): void;
    onOpenMediaReview?(messageId: string, attachment: Attachment, seconds: number, hasComments?: boolean, initialAttachments?: readonly Attachment[]): void;
};
/** Safe to retarget through ordinary props; callers do not own internal remount keys. */
export declare function ChannelTimeline(props: ChannelTimelineProps): import("react").JSX.Element;
