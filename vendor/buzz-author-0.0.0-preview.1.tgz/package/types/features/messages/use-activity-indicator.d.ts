import type { RelaySession } from "../relay/session";
import type { ChannelMessage } from "../relay/contracts";
/** A current, rendered activity row owns the live signal for its exact scope. */
export declare function useActivityIndicator(session: RelaySession | undefined, row: ChannelMessage, eligible: boolean, participants?: readonly string[], requestId?: string): boolean;
