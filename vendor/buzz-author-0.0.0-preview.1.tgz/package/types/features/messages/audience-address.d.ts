import type { ChannelMessage } from "../relay/contracts";
import type { profileMentionParts } from "./profile-mentions";
/** Who a message opens by addressing — its leading bound mentions — and the
 * message as shown without them. Display only: a message that is nothing but
 * mentions, or opens with prose, is shown as written. */
export declare function addressedMessage(row: ChannelMessage, parts: ReturnType<typeof profileMentionParts>): Readonly<{
    recipients: readonly string[];
    body: ChannelMessage;
}>;
