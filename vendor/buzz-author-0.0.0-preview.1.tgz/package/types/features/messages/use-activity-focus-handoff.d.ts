import { type RefObject } from "react";
/** Preserve keyboard position when an activity owner retires or is replaced. */
export declare function useActivityFocusHandoff(owner: RefObject<HTMLElement | null>): void;
