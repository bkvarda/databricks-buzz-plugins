/** Avatar artwork inside the control. A static gradient remains if WebGL fails. */
export declare function EffortMesh({ avatarSrc, effort, }: {
    avatarSrc: string | undefined;
    effort: number;
}): import("react").JSX.Element;
