/** Device-local opt-in to native spelling correction in the message composer. */
export declare function messageAutocorrectPreference(): boolean;
export declare function useMessageAutocorrectPreference(): {
    enabled: boolean;
    unsaved: boolean;
};
export declare function setMessageAutocorrectPreference(enabled: boolean): void;
