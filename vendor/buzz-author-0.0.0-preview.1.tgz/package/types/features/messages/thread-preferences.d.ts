export type ThreadPlacement = "main" | "side";
/** Device-local default for new tabs, never an instruction to move existing ones. */
export declare function threadPlacementPreference(): ThreadPlacement;
export declare function useThreadPlacementPreference(): {
    placement: ThreadPlacement;
    unsaved: boolean;
};
export declare function setThreadPlacementPreference(value: ThreadPlacement): void;
