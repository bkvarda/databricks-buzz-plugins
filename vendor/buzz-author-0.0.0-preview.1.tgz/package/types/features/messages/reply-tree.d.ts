import type { ChannelMessage } from "../relay/contracts";
/**
 * A forest of the available history, never a claim that all parents were loaded.
 * Branches are one level deep: a reply to a nested reply joins its branch, in
 * order, so continuing a conversation never drifts further in.
 */
export declare function replyTree(rows: readonly ChannelMessage[], rootId?: string): {
    children: Map<string | undefined, Readonly<{
        id: string;
        channelId: string;
        delivery?: import("../relay/outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        notice?: "execution-failure";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("../relay/contracts").MembershipChange;
        pluginRequest?: Readonly<{
            id: string;
        }>;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("../relay/contracts").Attachment[];
        emoji?: readonly import("../relay/emoji").CustomEmoji[];
        reactions: readonly import("../relay/contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        mediaTargetUrl?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }>[]>;
    parents: Map<string, string>;
    ancestors(id: string): string[];
};
