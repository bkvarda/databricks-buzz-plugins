import type { DeviceSetting } from "../../shared/device-settings";
export declare function rememberAgentsPreference(): boolean;
export declare function useRememberAgentsPreference(): boolean;
export declare function setRememberAgentsPreference(enabled: boolean): string | null;
/** Remembering mentioned agents as a device setting. */
export declare const rememberAgentsSetting: DeviceSetting;
