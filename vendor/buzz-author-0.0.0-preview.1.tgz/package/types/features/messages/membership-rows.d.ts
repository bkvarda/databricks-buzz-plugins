import type { ChannelMessage, Profile } from "../relay/contracts";
export type TimelineRow = ChannelMessage & {
    membershipRows?: readonly ChannelMessage[];
};
/** A Solo chat implies the agents its owner started it with; omit the owner's
 * agent additions and removals before the first message once history reaches
 * the chat's start. Later changes, people and agents added by someone else
 * still show. */
export declare function withoutStartingAgents(rows: readonly ChannelMessage[], owner: string | undefined, agents: ReadonlySet<string>, complete: boolean): readonly ChannelMessage[];
/** Newest-anchored groups keep loaded keys stable when history is prepended.
 * Every uninterrupted membership run is one row, regardless of elapsed time.
 * A conversation entry (including a huddle) always breaks the group. */
export declare function membershipRows(rows: readonly ChannelMessage[]): readonly TimelineRow[];
/** The index of the row that renders an event. A hidden membership event, such
 * as a reading anchor saved before self-joins were hidden, resolves to the
 * nearest later rendered event, else the nearest earlier one. */
export declare function renderedRowIndex(rows: readonly TimelineRow[], events: readonly ChannelMessage[], id: string): number;
/** A prose segment; `id` marks a member name that may open that profile. */
export type MembershipPart = {
    text: string;
    id?: string;
    preview?: {
        label: string;
        members: readonly {
            id: string;
            name: string;
        }[];
    };
};
export declare function membershipDescription(rows: readonly ChannelMessage[], profiles: ReadonlyMap<string, Profile>, viewer?: string, resolveName?: (id: string, fallback: string) => string): {
    targets: string[];
    parts: MembershipPart[];
    text: string;
    title: string;
};
