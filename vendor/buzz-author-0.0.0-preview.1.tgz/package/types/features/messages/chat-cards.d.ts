import type { ChannelMessage } from "../relay/contracts";
import type { ReferenceChannel } from "./ReferenceText";
/** One durable representation for cards admitted by staging or draft restoration. */
export declare function canonicalChatCard(value: unknown): string | undefined;
/** Project presentation only. Actions, copy and replies keep the original row. */
export declare function separateChatCards(row: ChannelMessage, channels: readonly ReferenceChannel[]): {
    caption: Readonly<{
        id: string;
        channelId: string;
        delivery?: import("../relay/outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("../relay/contracts").MembershipChange;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("../relay/contracts").Attachment[];
        emoji?: readonly import("../relay/emoji").CustomEmoji[];
        reactions: readonly import("../relay/contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }>;
    cards: {
        content: string;
        start: number;
    }[];
    ranges: {
        start: number;
        end: number;
    }[];
};
/** The Solo chats a message's cards link to, using exactly the card renderer's
 * exclusions for quoted, code and hidden links. */
export declare function chatCardIds(content: string): string[];
