import { type ReactNode, type RefObject } from "react";
import { type readReviewOrigin } from "./use-review-entrance";
/** Shared fullscreen surface for sent media and local composer previews. */
export declare function MediaReviewFrame({ title, label, isVideo, video, frame, origin, canReturnToOrigin, returnOrigin, commentsOpen, commentsMotion, actions, navigate, children, sidebar, restoreFocus, close, }: {
    title: string;
    label: string;
    isVideo: boolean;
    video: RefObject<HTMLVideoElement | null>;
    frame: RefObject<HTMLElement | null>;
    origin: ReturnType<typeof readReviewOrigin>;
    canReturnToOrigin?: boolean;
    returnOrigin?: (() => ReturnType<typeof readReviewOrigin>) | undefined;
    commentsOpen?: boolean;
    commentsMotion?: boolean;
    actions?: ReactNode;
    navigate?: ((direction: -1 | 1) => void) | undefined;
    children: ReactNode;
    sidebar?: ReactNode;
    restoreFocus?: RefObject<HTMLElement | null> | undefined;
    close(): void;
}): import("react").ReactPortal;
