import type { Agents } from "../agents/service";
import type { PortableAgent } from "../agents/native";
import type { MentionRecipient } from "./mention-draft";
/** Offers to import a mentioned agent that only an earlier Buzz on this
 * machine runs, before the send that would otherwise go unanswered. */
export declare function useOldAgentMentions(agents: Agents | undefined, restoreFocus: () => void): {
    /** The mentioned agents an earlier Buzz on this machine still runs;
     * at once when none can be, so an ordinary send stays synchronous. */
    find(people: readonly MentionRecipient[]): readonly PortableAgent[] | Promise<readonly PortableAgent[]>;
    /** Resolves null when the owner closed the dialog and the send stops;
     * otherwise the agents to pass to `decline` once the message goes out. */
    ask(found: readonly PortableAgent[], signal: AbortSignal, current: () => boolean): Promise<readonly string[] | null>;
    /** Records agents sent to without importing, so this run asks no more.
     * Called only once every step before sending passed, since a send
     * stopped later leaves nothing declined. */
    decline(keys: readonly string[]): void;
    dialog: import("react").JSX.Element;
};
