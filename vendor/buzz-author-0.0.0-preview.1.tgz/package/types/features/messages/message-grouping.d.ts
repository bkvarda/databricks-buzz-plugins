import type { ChannelMessage } from "../relay/contracts";
export declare function continuesMessageGroup(previous: ChannelMessage | undefined, current: ChannelMessage): boolean;
/** Only same-author activity can bridge two public messages. */
export declare function publicMessageNeighbor(rows: readonly ChannelMessage[], index: number, direction: -1 | 1): Readonly<{
    id: string;
    channelId: string;
    delivery?: import("../relay/outbox").Delivery | undefined;
    deliveryError?: string | undefined;
    authorId: string;
    signerId?: string | undefined;
    workflowOwnerId?: string | undefined;
    createdAt: number;
    createdAtMs?: number;
    content: string;
    sourceContent?: string;
    agentEnvelope?: true;
    audience?: "agents";
    diff?: Readonly<{
        filePath?: string | undefined;
        repoUrl?: string | undefined;
        commitSha?: string | undefined;
        description?: string | undefined;
        truncated: boolean;
    }>;
    membership?: import("../relay/contracts").MembershipChange;
    huddle?: Readonly<{
        room: string;
        state: "started" | "ended";
        endedAt?: number;
    }>;
    edited?: true;
    attachmentSeams?: readonly number[];
    mentions: readonly string[];
    mentionReferences?: readonly string[];
    attachmentSourceId?: string;
    attachments: readonly import("../relay/contracts").Attachment[];
    emoji?: readonly import("../relay/emoji").CustomEmoji[];
    reactions: readonly import("../relay/contracts").MessageReaction[];
    threadRootId?: string | undefined;
    replyParentId?: string | undefined;
    sentFromThread?: Readonly<{
        rootId: string;
        excerpt?: string | undefined;
    }> | undefined;
    replyCount: number;
    participants: readonly string[];
}> | undefined;
