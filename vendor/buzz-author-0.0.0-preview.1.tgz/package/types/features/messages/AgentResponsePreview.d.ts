import type { ReactNode } from "react";
/** Incoming message geometry for work that has not published a response yet. */
export declare function AgentResponsePreview({ name, picture, participants, layout, children, stackPrevious, }: {
    stackPrevious?: boolean;
    name: string;
    picture?: string | undefined;
    participants?: readonly {
        id: string;
        name: string;
        picture?: string | undefined;
    }[];
    layout?: "timeline" | "thread" | "continuation" | undefined;
    children: ReactNode;
}): import("react").JSX.Element;
