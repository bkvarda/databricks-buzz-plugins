import type { VirtualizerHandle } from "virtua";
import type { ChannelMessage, Profile } from "../relay/contracts";
import type { ChannelQueries } from "../relay/contracts";
export declare function geometryFor(queries: ChannelQueries): {
    get(channelId: string, signature: string, width: number): import("virtua").CacheSnapshot | undefined;
    set(channelId: string, signature: string, width: number, cache: VirtualizerHandle["cache"]): void;
};
export declare const geometrySignature: (events: readonly ChannelMessage[], profiles: ReadonlyMap<string, Profile>, resolveName?: (id: string, fallback: string) => string) => string;
