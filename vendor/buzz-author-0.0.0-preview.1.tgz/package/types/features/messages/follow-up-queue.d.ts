import type { RelaySession } from "../relay/session";
import type { OutboxRecovery } from "../relay/outbox";
import { type FollowUpMessage } from "./follow-up-storage";
type Entry = {
    id: string;
    createdAt?: number;
    channelId: string;
    text: string;
    recipients: readonly string[];
    publish(recovery?: OutboxRecovery): string;
    message?: FollowUpMessage;
    restored?: boolean;
    recovered?: true;
    admitted?: boolean;
    resumedBy?: Set<string>;
    deliveryId?: string | undefined;
    dismissedDelivery?: string | undefined;
    resumeCancelled?: boolean;
    predecessorRemoved?: boolean;
    sending?: boolean;
    ready?(): boolean;
    beforeRelease?(): Promise<void>;
    beforePublish?(): void;
    onSend?(id: string): void;
    error?: string;
};
/** Pending Solo sends survive navigation and, with a message payload, restart. */
export declare function followUpQueue(session: RelaySession): {
    snapshot: () => readonly Entry[];
    storageError: () => string | undefined;
    subscribe(listener: () => void): () => void;
    /** `validated` means the caller checked recipients just now; only a later release revalidates. */
    submit(entry: Omit<Entry, "id">, validated?: boolean): string | undefined;
    /** Resume only the chats the runner is actually recovering. Seed the
     * request barriers before it reads/restarts them, including reconnects. */
    resumeAfter(agent: string, turns: Readonly<Record<string, string>>, beforePublish?: (entry: Pick<Entry, "channelId" | "recipients">) => void): void;
    /** A request positively abandoned by the runner is not completion evidence. */
    pauseAfter(agent: string, turns: Readonly<Record<string, string>>): void;
    sendNow(id: string, beforePublish?: () => void): void;
    remove(id: string): void;
};
export {};
