import type { ChannelMessage } from "../relay/contracts";
export declare function DeliveryNotice({ row, retry, }: {
    row: ChannelMessage;
    retry?: ((id: string) => void) | undefined;
}): import("react").JSX.Element | null;
