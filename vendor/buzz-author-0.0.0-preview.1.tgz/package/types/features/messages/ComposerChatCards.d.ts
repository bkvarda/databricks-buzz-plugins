import type { ComposerSession } from "./composer-session";
import type { ConversationExtensions } from "../conversation/contracts";
export declare function ComposerChatCards({ cards, session, scope, channelId, extensions, disabled, remove, }: {
    cards: readonly string[];
    session: ComposerSession;
    scope: string;
    channelId: string;
    extensions: ConversationExtensions | undefined;
    disabled: boolean;
    remove(index: number): void;
}): import("react").JSX.Element | null;
