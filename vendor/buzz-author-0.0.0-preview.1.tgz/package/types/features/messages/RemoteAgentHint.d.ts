import type { ComposerSession } from "./composer-session";
type RemoteAgentProps = {
    session?: Pick<ComposerSession, "viewer" | "agentChoices"> | undefined;
    viewer: string | undefined;
    pubkey: string;
};
export declare function RemoteWorkIcon({ active, ...props }: RemoteAgentProps & {
    active: boolean;
}): import("react").JSX.Element | null;
export declare function RemoteAgentHint(props: RemoteAgentProps): import("react").JSX.Element | null;
export {};
