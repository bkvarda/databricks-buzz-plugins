import { avatarMedia } from "../../shared/avatar-source";
import type { ProfileQueries } from "../relay/profile-directory";
import type { SessionPlace } from "../agents/service";
import type { MentionPicks, RunPick } from "../relay/messages";
/** The draft's picks, each with the agent type it was made under. */
export type DraftPicks = Readonly<Record<string, RunPick & Readonly<{
    type?: string;
}>>>;
/** Model and effort for the next run of each mentioned agent of the viewer's
 * that offers a choice. Session controls act immediately on this conversation. */
export declare function ComposerModels({ pubkeys, profiles, media, value, disabled, resettable, explicitOnly, onChange, onResolved, onRetryInventory, startsThread, place, }: {
    pubkeys: readonly string[];
    profiles: ProfileQueries;
    media: Parameters<typeof avatarMedia>[1];
    value: DraftPicks;
    disabled: boolean;
    /** Solo chat picks are defaults for the chat until explicitly reset. */
    resettable?: boolean;
    /** A new Solo chat keeps provider defaults unchanged unless picked. */
    explicitOnly?: boolean;
    onChange(value: DraftPicks, resetPubkeys?: readonly string[]): void;
    /** null waits for choices; undefined invalidates the picker's snapshot. */
    onResolved(value: MentionPicks | null | undefined, error?: string): void;
    onRetryInventory?(): void;
    /** The message starts a thread of its own, as a channel's top-level one
     * does, so a thread-scoped agent has no session to act on. */
    startsThread: boolean;
    place: SessionPlace;
}): import("react").JSX.Element | null;
