import { avatarMedia } from "../../shared/avatar-source";
import type { ProfileQueries } from "../relay/profile-directory";
import type { SessionPlace } from "../agents/service";
import type { MentionPicks, RunPick } from "../relay/messages";
/** The draft's picks, each with the agent type it was made under. */
export type DraftPicks = Readonly<Record<string, RunPick & Readonly<{
    type?: string;
}>>>;
/** Model and effort for the next run of each mentioned agent of the viewer's
 * that offers a choice. Session controls act immediately on this conversation. */
export declare function ComposerModels({ pubkeys, profiles, media, value, disabled, onChange, onResolved, startsThread, place, }: {
    pubkeys: readonly string[];
    profiles: ProfileQueries;
    media: Parameters<typeof avatarMedia>[1];
    value: DraftPicks;
    disabled: boolean;
    onChange(value: DraftPicks): void;
    onResolved(value: MentionPicks): void;
    /** The message starts a thread of its own, as a channel's top-level one
     * does, so a thread-scoped agent has no session to act on. */
    startsThread: boolean;
    place: SessionPlace;
}): import("react").JSX.Element | null;
