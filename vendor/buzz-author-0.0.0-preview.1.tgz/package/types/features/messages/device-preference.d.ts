/** A device-local boolean choice with an independent unsaved fallback. */
export declare function devicePreference(preferenceKey: string, changedEvent: string): {
    read: () => boolean;
    subscribe: (listener: () => void) => () => void;
    usePreference: () => boolean;
    useSaveError: () => "This choice is active, but could not be saved on this device. Try again." | null;
    set: (enabled: boolean) => string | null;
};
