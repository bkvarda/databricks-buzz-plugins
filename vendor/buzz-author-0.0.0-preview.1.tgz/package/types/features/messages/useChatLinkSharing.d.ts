import type { RelaySession } from "../relay/session";
/** Consent only. Existing membership receipts own grants; the composer owns the one message/reply. */
export declare function useChatLinkSharing(session: RelaySession | undefined, channelId: string, restoreFocus: () => void): {
    prepare(sources: readonly string[], signal: AbortSignal, current: () => boolean): Promise<boolean>;
    dialog: import("react").JSX.Element;
};
