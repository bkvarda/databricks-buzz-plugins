import type { ReactNode } from "react";
/** The request's typing footprint opens into its real current step. */
export declare function ActivityStepPreview({ text, state, icon, }: {
    text?: string | undefined;
    state: "waiting" | "working";
    icon?: ReactNode;
}): import("react").JSX.Element;
/** The same readable step names both the preview and its trigger. */
export declare function activityStepLabel(text?: string): string;
