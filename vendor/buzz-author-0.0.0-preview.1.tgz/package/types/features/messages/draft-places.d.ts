import type { ComposerSession } from "./composer-session";
type Session = Pick<ComposerSession, "scope">;
/** The one rule for whether a saved draft counts: Drafts & sent and every
 * draft marker read through it, so they cannot disagree. */
export declare function draftCounts(session: Session, key: string, value: unknown): boolean;
/** A composer on screen marks its draft as already in view. A layout effect,
 * so opening a thread never paints its summary's marker for a frame. */
export declare function useShowingDraft(scope: string, key: string, shown: boolean): void;
/** A thread draft that no open composer already shows. */
export declare function useThreadDraft(session: Session | undefined, channelId: string, threadRootId: string): boolean;
export {};
