import { type RefObject } from "react";
type Point = Readonly<{
    x: number;
    y: number;
}>;
export declare const MIN_ZOOM = 0.5;
export declare function useImageViewport(stage: RefObject<HTMLDivElement | null>, image: RefObject<HTMLImageElement | null>, source: string | undefined): {
    zoom: number;
    offset: Point;
    maxZoom: number;
    zoomTo: (value: number, anchor?: Point) => void;
    toggleZoomAt: (clientX: number, clientY: number) => void;
    panTo: (offset: Point) => void;
    constrain: () => void;
};
export {};
