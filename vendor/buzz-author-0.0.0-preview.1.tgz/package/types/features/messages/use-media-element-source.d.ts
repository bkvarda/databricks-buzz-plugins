/** A media element's `src` for `source`. A native relay source waits for the
 * listener's address; without a listener it is `unavailable`, which callers
 * show as failed playback. `buzz-media` is no fallback: its reads cannot be
 * cancelled when the player closes, so they would keep spools alive. */
export declare function useMediaElementSource(source: string | undefined): {
    src: string | undefined;
    unavailable: boolean;
};
