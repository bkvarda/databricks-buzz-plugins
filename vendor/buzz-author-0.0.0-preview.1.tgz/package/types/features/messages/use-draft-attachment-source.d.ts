import type { DraftAttachment } from "./attachment-draft";
/** Each mounted preview owns its local URL; uploaded metadata is authoritative. */
export declare function useDraftAttachmentSource(item: DraftAttachment, media: (url: string) => string | undefined): {
    source: string | undefined;
    type: string;
    image: boolean;
    video: boolean;
};
export declare function draftAttachmentMedia(item: DraftAttachment): {
    type: string;
    image: boolean;
    video: boolean;
};
