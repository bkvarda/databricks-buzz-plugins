/** `request` until the user clicks or presses a key, so a request whose target
 * is still loading never takes focus from wherever they have moved it. */
export declare function usePendingRequest(request: number | undefined): number | undefined;
