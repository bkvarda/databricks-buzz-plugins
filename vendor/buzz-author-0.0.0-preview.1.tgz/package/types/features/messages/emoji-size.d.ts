import type { CustomEmoji } from "../relay/emoji";
export declare function isUnicodeEmojiOnly(value: string): boolean;
export declare const isEmojiOnly: (value: string, entries?: readonly CustomEmoji[]) => boolean;
export declare function usesLargeEmojiPresentation(value: string, entries?: readonly CustomEmoji[]): boolean;
