/** The host validates the URL again and owns the destination; never navigate the webview. */
export declare function downloadNativeMedia(source: string, name?: string): Promise<void>;
/** Saves a file the app built to Downloads the way media is saved, and resolves
 * with its path; WKWebView logs a sandbox failure for a `blob:` download. */
export declare function downloadNativeFile(file: Blob, name: string): Promise<string>;
