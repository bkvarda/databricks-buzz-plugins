import { type CurrentActivity } from "../agents/current-activity";
import { type LocalWork } from "../agents/local-activity";
import type { RelaySession } from "../relay/session";
import type { ComposerSession } from "./composer-session";
import type { MessageLinkOrigin } from "./MessageRow";
type AgentSession = ComposerSession & Partial<Pick<RelaySession, "agentActivity">>;
/** The working agents' keys only, for hosts that do not show their details:
 * re-render when that list changes, not on every typing or profile update. */
export declare function useLiveConversationAgents(session: AgentSession, channelId: string, threadRootId: string | undefined, includeThreads?: boolean): readonly string[];
/** Agents working in one conversation, over existing stores; no reads or capture. */
export declare function useConversationAgents(session: AgentSession, channelId: string, threadRootId: string | undefined, includeThreads?: boolean): {
    activity: Readonly<{
        status: "unavailable" | "disabled" | "connecting" | "listening" | "interrupted";
        records: readonly (Readonly<{
            id: string;
            agent: string;
            createdAt: number;
            plaintext: string;
            envelope?: import("../relay/events").RelayEvent;
        }> & Readonly<{
            receivedAt: number;
            kind: string;
            channelIds: readonly string[];
        }>)[];
        turns: readonly import("../agents/activity").ActivityTurn[];
        local?: readonly LocalWork[];
        typing: readonly {
            readonly agent: string;
            readonly channelId: string;
            readonly threadRootId: string | undefined;
            readonly startedAt: number;
            readonly working: boolean;
        }[];
        trimmed: number;
    }> | undefined;
    details: ReadonlyMap<string, CurrentActivity>;
    entries: readonly Readonly<{
        channelId: string;
        threadRootId?: string;
        pubkey: string;
    }>[];
    replaced: ReadonlySet<string>;
    agents: string[];
    knownAgents: Set<string>;
};
/** Incoming conversation activity over existing stores; no reads or capture. */
export declare function TypingIndicator({ session, channelId, threadRootId, canOpenActivity, openActivity, previousAuthor, inFlow, audience, }: {
    audience?: "all" | "humans" | "agents";
    previousAuthor?: string | undefined;
    inFlow?: boolean;
    session: ComposerSession & Partial<Pick<RelaySession, "agentActivity">>;
    channelId: string;
    threadRootId?: string | undefined;
    canOpenActivity?: ((target: string) => boolean) | undefined;
    openActivity?: ((target: string, origin?: MessageLinkOrigin) => boolean) | undefined;
}): import("react").JSX.Element;
export {};
