import { type ReactNode } from "react";
/** Plain text of rendered Markdown children, such as a formatted link label. */
export declare const labelText: (children: ReactNode) => string;
