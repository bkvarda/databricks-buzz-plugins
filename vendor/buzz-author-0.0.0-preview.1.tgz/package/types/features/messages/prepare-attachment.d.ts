/** Prepare pixels before the byte-exact upload contract; the relay still validates. */
export declare function prepareAttachment(file: File, signal: AbortSignal, stripSnapshotMetadata?: boolean): Promise<File>;
