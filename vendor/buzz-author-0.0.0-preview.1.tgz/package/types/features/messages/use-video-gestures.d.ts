import { type RefObject } from "react";
type FeedbackKind = "play" | "pause" | "forward" | "backward" | "speed";
export declare function seekVideoBy(element: HTMLVideoElement, seconds: number): void;
/** Picture gestures never intercept the separate playback controls. */
export declare function useVideoGestures(video: RefObject<HTMLVideoElement | null>, source: string): {
    handlers: {
        onClick(event: React.MouseEvent<HTMLVideoElement>): void;
        onDoubleClick(event: React.MouseEvent<HTMLVideoElement>): void;
        onPointerDown(event: React.PointerEvent<HTMLVideoElement>): void;
        onPointerUp: () => void;
        onPointerLeave: () => void;
        onPointerCancel: () => void;
    };
    feedback: {
        kind: FeedbackKind;
        id: number;
    } | undefined;
};
export {};
