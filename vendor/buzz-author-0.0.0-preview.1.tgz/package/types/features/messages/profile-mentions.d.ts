import type { AgentLibrary } from "../agents/library";
import type { ChannelMessage, Profile } from "../relay/contracts";
type Part = {
    text: string;
    target?: string | undefined;
};
/** Display only: signed recipients bound by an unedited body's exact known names.
 * This does not infer notification intent or resolve a name against a directory. */
export declare function profileMentionParts(row: Pick<ChannelMessage, "content" | "edited" | "attachmentSeams" | "mentions" | "mentionReferences">, profiles: ReadonlyMap<string, Profile> | undefined, agents?: AgentLibrary["identities"]): Part[];
export {};
