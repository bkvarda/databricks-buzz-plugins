import type { AgentLibrary } from "../agents/library";
import type { ChannelMessage, Profile } from "../relay/contracts";
/** The names a person's signed prose mention binds by: their shown name and,
 * when verified, both verified names, so prose written under either name
 * preference stays a mention. Renderers key their caches on the same list. */
export declare function profileMentionNames(profile: Profile | undefined): (string | undefined)[];
type Part = {
    text: string;
    target?: string | undefined;
};
/** Display only: signed recipients bound by an unedited body's exact known names.
 * This does not infer notification intent or resolve a name against a directory. */
export declare function profileMentionParts(row: Pick<ChannelMessage, "content" | "edited" | "attachmentSeams" | "mentions" | "mentionReferences">, profiles: ReadonlyMap<string, Profile> | undefined, agents?: AgentLibrary["identities"]): Part[];
export {};
