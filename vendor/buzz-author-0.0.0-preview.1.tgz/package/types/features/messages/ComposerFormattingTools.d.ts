import { type ReactNode } from "react";
import { type ComposerFormat } from "./composer-dom";
/** Toolbar controls share the editor commands and active state. */
export declare function ComposerFormattingTools({ children, disabled, singleRow, activeFormats, toggleFormat, editLink, trailing, }: {
    children: ReactNode;
    /** Conversation controls that follow the tools on the same row. */
    trailing?: ReactNode;
    disabled: boolean;
    singleRow?: boolean;
    activeFormats: readonly ComposerFormat[];
    toggleFormat(format: ComposerFormat): void;
    editLink(): void;
}): import("react").JSX.Element;
