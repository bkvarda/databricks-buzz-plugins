export type MediaTimeAnchor = Readonly<{
    type: "time";
    seconds: number;
}>;
export declare function formatMediaTime(seconds: number): string;
export declare function mediaTimeReply(seconds: number, content: string): string;
export declare function parseMediaTimeReply(content: string): Readonly<{
    anchor: MediaTimeAnchor;
    label: string;
    content: string;
}> | undefined;
