export type ModelPicksTransaction = {
    revision(key: string): string | null;
    version(key: string): string;
    write(key: string, value: unknown): string;
};
/** IDB, not a page's localStorage cache, owns read/merge/compare/write. */
export declare function transactModelPicks<T>(scope: string, keys: readonly string[], change: (transaction: ModelPicksTransaction) => T): Promise<T>;
export declare function subscribeModelPicks(scope: string, listener: () => void): () => void;
/** Notifications carry no snapshot; readers always reread committed IDB state. */
export declare function publishModelPicks(scope: string): void;
export declare function purgeSoloModelPicks(scope: string): Promise<void>;
