import { type RefObject } from "react";
import { type DialogProps } from "../../shared/design-system/ui/Dialog";
import type { ComposerInputElement, ComposerLinkEdit } from "./composer-dom";
export declare function ComposerLinkDialog({ edit, input, finalFocus, disabled, close, }: {
    edit: ComposerLinkEdit;
    input: RefObject<ComposerInputElement | null>;
    finalFocus?: DialogProps["finalFocus"];
    disabled: boolean;
    close(): void;
}): import("react").JSX.Element;
