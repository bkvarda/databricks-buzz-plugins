import type { MentionDraft, MentionRecipient } from "./mention-draft";
import type { ComposerResource } from "../conversation/contracts";
export declare const inlineFormats: readonly [{
    readonly mark: "bold";
    readonly label: "Bold";
    readonly inputType: "formatBold";
    readonly binding: {
        readonly key: "b";
        readonly mod: true;
        readonly shift: false;
    };
}, {
    readonly mark: "italic";
    readonly label: "Italic";
    readonly inputType: "formatItalic";
    readonly binding: {
        readonly key: "i";
        readonly mod: true;
        readonly shift: false;
    };
}, {
    readonly mark: "strike";
    readonly label: "Strikethrough";
    readonly inputType: "formatStrikeThrough";
    readonly binding: {
        readonly key: "x";
        readonly mod: true;
        readonly shift: true;
    };
}, {
    readonly mark: "spoiler";
    readonly label: "Spoiler";
    readonly inputType: "formatSpoiler";
    readonly binding: {
        readonly key: "p";
        readonly mod: true;
        readonly shift: true;
    };
}, {
    readonly mark: "code";
    readonly label: "Code";
    readonly inputType: "formatInlineCode";
    readonly binding: {
        readonly key: "e";
        readonly mod: true;
        readonly shift: false;
    };
    readonly aliases: readonly [{
        readonly key: "c";
        readonly mod: true;
        readonly shift: true;
    }];
}];
export type InlineFormat = (typeof inlineFormats)[number]["mark"];
export declare const blockFormats: readonly [{
    readonly mark: "code_block";
    readonly label: "Code block";
    readonly binding: {
        readonly key: "c";
        readonly mod: true;
        readonly alt: true;
        readonly shift: false;
    };
    readonly aliases: readonly [{
        readonly key: "c";
        readonly mod: true;
        readonly alt: true;
        readonly shift: true;
    }];
}, {
    readonly mark: "bullet_list";
    readonly label: "Bullet list";
    readonly binding: {
        readonly key: "8";
        readonly mod: true;
        readonly shift: true;
    };
}, {
    readonly mark: "ordered_list";
    readonly label: "Ordered list";
    readonly binding: {
        readonly key: "7";
        readonly mod: true;
        readonly shift: true;
    };
}, {
    readonly mark: "blockquote";
    readonly label: "Quote";
    readonly binding: {
        readonly key: "b";
        readonly mod: true;
        readonly shift: true;
    };
    readonly aliases: readonly [{
        readonly key: "9";
        readonly mod: true;
        readonly shift: true;
    }];
}];
export type BlockFormat = (typeof blockFormats)[number]["mark"];
export type ComposerFormat = InlineFormat | BlockFormat;
export declare const composerFormats: ({
    readonly mark: "bold";
    readonly label: "Bold";
    readonly inputType: "formatBold";
    readonly binding: {
        readonly key: "b";
        readonly mod: true;
        readonly shift: false;
    };
} | {
    readonly mark: "italic";
    readonly label: "Italic";
    readonly inputType: "formatItalic";
    readonly binding: {
        readonly key: "i";
        readonly mod: true;
        readonly shift: false;
    };
} | {
    readonly mark: "strike";
    readonly label: "Strikethrough";
    readonly inputType: "formatStrikeThrough";
    readonly binding: {
        readonly key: "x";
        readonly mod: true;
        readonly shift: true;
    };
} | {
    readonly mark: "spoiler";
    readonly label: "Spoiler";
    readonly inputType: "formatSpoiler";
    readonly binding: {
        readonly key: "p";
        readonly mod: true;
        readonly shift: true;
    };
} | {
    readonly mark: "code";
    readonly label: "Code";
    readonly inputType: "formatInlineCode";
    readonly binding: {
        readonly key: "e";
        readonly mod: true;
        readonly shift: false;
    };
    readonly aliases: readonly [{
        readonly key: "c";
        readonly mod: true;
        readonly shift: true;
    }];
} | {
    readonly mark: "code_block";
    readonly label: "Code block";
    readonly binding: {
        readonly key: "c";
        readonly mod: true;
        readonly alt: true;
        readonly shift: false;
    };
    readonly aliases: readonly [{
        readonly key: "c";
        readonly mod: true;
        readonly alt: true;
        readonly shift: true;
    }];
} | {
    readonly mark: "bullet_list";
    readonly label: "Bullet list";
    readonly binding: {
        readonly key: "8";
        readonly mod: true;
        readonly shift: true;
    };
} | {
    readonly mark: "ordered_list";
    readonly label: "Ordered list";
    readonly binding: {
        readonly key: "7";
        readonly mod: true;
        readonly shift: true;
    };
} | {
    readonly mark: "blockquote";
    readonly label: "Quote";
    readonly binding: {
        readonly key: "b";
        readonly mod: true;
        readonly shift: true;
    };
    readonly aliases: readonly [{
        readonly key: "9";
        readonly mod: true;
        readonly shift: true;
    }];
})[];
export type ComposerFormatBinding = Readonly<{
    key: string;
    mod: true;
    shift: boolean;
    alt?: boolean;
}>;
/** Every chord a format answers to; the first is the one hints show. */
export declare function formatBindings(format: (typeof composerFormats)[number]): readonly ComposerFormatBinding[];
/** Add or edit a link around the selection: Buzz's ⌘K, then Slack's ⌘⇧U. */
export declare const linkBindings: readonly ComposerFormatBinding[];
export type ComposerLinkEdit = {
    text: string;
    href: string;
    existing: boolean;
    save(text: string, href: string): boolean;
    remove(): boolean;
};
/** Public commands remain in authored-source offsets. Only the editor adapter
 * translates them into document positions; callers never manipulate its DOM. */
export type ComposerInputElement = HTMLDivElement & {
    value: string;
    selectionStart: number;
    selectionEnd: number;
    selectionDirection: "forward" | "backward" | "none";
    disabled: boolean;
    readOnly: boolean;
    setSelectionRange(start: number, end: number, direction?: string): void;
    insertText(text: string, recipient?: MentionRecipient | readonly MentionRecipient[], range?: {
        start: number;
        end: number;
    }, 
    /** The key typed to end the query. A closing colon is recorded before
     * conversion for one-step undo; after recipients, it takes the place of
     * the space that follows each one. */
    terminator?: string, 
    /** Automatic edits preserve focus and the current selection. */
    focus?: boolean): boolean;
    replaceRecipients(recipients: readonly MentionRecipient[]): boolean;
    /** Replace the typed `@name` with a chip the host is still resolving,
     * followed by the key that ended it (a space by default); the returned id
     * names it until `settlePendingMention`. One undo step. */
    insertPendingMention(name: string, range: {
        start: number;
        end: number;
    }, terminator?: string): string | false;
    /** Turn a pending chip into its recipient, or back into its typed text.
     * Outside undo history and allowed while sending; false once the chip is
     * gone. Under an IME composition the settle is held until it ends, and the
     * promise is the replay's outcome. */
    settlePendingMention(id: string, recipient: MentionRecipient | null): boolean | Promise<boolean>;
    /** Extend a pending chip over `remainder`, the text right after it, into one
     * chip named by both: the host matched the words typed after the chip to a
     * longer known name. Outside undo history and allowed while sending, held
     * under an IME composition like a settle; false once the chip is gone or the
     * text after it no longer begins with `remainder`. */
    extendPendingMention(id: string, remainder: string): boolean | Promise<boolean>;
    /** Host-owned inline link atom at the caret; a string is the rejection reason. */
    insertResource(resource: ComposerResource): true | string;
    toggleFormat(format: ComposerFormat): void;
    insertLineBreak(): boolean;
    editLink(): ComposerLinkEdit | null;
    removeRecipient(pubkey: string): void;
    undo(redo: boolean): void;
    reset(draft: MentionDraft): void;
    /** Retain this editor's document, selection and undo state across a temporary edit. */
    checkpoint(): () => void;
};
