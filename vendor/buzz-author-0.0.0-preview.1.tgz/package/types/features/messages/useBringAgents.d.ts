import type { ComposerSession } from "./composer-session";
import type { Agent, Agents } from "../agents/service";
/**
 * One consent decision before a send brings the owner's agents from their other
 * communities into this one. Declining or closing sends nothing; the draft and
 * its mention stay. Resolves with the keys added to the channel, or null.
 */
export declare function useBringAgents(session: ComposerSession, agents: Agents | undefined, channelId: string, restoreFocus: () => void): {
    prepare(people: readonly Agent[], signal: AbortSignal, current: () => boolean): Promise<readonly string[] | null>;
    dialog: import("react").JSX.Element;
};
