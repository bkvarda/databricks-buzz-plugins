import { Fragment, type Mark } from "prosemirror-model";
/** Adopt a source link only when explicitly editing it; preserve its label marks. */
export declare function composerLinkLabel(source: string, marks: readonly Mark[]): Fragment;
