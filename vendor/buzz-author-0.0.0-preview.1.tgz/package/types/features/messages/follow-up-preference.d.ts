export type FollowUpBehavior = "immediate" | "queue";
/** Device-local Solo follow-up behavior; immediate sending remains the default. */
export declare function followUpBehaviorPreference(): FollowUpBehavior;
export declare function useFollowUpBehaviorPreference(): {
    behavior: FollowUpBehavior;
    unsaved: boolean;
};
export declare function setFollowUpBehaviorPreference(value: FollowUpBehavior): void;
