export declare function reactionName(content: string): string;
