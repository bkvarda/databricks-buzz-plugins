import type { ChannelMessage } from "../relay/contracts";
import type { ComposerSession } from "./composer-session";
export declare function lastEditableMessage(session: ComposerSession, rows: readonly ChannelMessage[]): ChannelMessage | undefined;
/** Edit delivery uses the session outbox; the composer owns input and draft restoration. */
export declare function useMessageEdit(session: ComposerSession, restore: () => void): {
    target: Readonly<{
        id: string;
        channelId: string;
        delivery?: import("../relay/outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("../relay/contracts").MembershipChange;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("../relay/contracts").Attachment[];
        emoji?: readonly import("../relay/emoji").CustomEmoji[];
        reactions: readonly import("../relay/contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }> | undefined;
    busy: boolean;
    locked: boolean;
    retryable: boolean;
    error: string | undefined;
    close: () => void;
    clearError: () => void;
    start(row: ChannelMessage, normalize?: (body: string) => string): string;
    save(body: string, current: ChannelMessage | undefined): void;
    retry(): void;
};
