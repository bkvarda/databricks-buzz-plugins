import type { ChannelLifecycleCapability } from "../relay/channel-lifecycle";
/** Archived and read-only channels share the public preview's lower notice.
 * Member-default public previews offer Join; confirmed membership enables composition.
 * Confirmed membership can unmount this notice before its run settles, so the
 * page records the join intent when the run starts, not when it resolves. */
export declare function ChannelJoinNotice({ channelId, ready, lifecycle, joinable, guest, archived, place, joinRole, onJoin, onHeightChange, }: {
    channelId: string;
    ready?: boolean;
    lifecycle?: ChannelLifecycleCapability | undefined;
    joinable: boolean;
    guest?: boolean;
    archived?: boolean;
    place?: "chat" | "channel";
    joinRole?: "member" | "guest" | undefined;
    onJoin(): void;
    onHeightChange?(height: number): void;
}): import("react").JSX.Element;
