import { type RefObject, type MouseEvent } from "react";
type Bounds = Pick<DOMRect, "left" | "top" | "width" | "height">;
type ReviewOrigin = Bounds & {
    aspect: number;
    preview: Element;
    previewBounds: Bounds;
    radius: string;
    smooth: boolean;
    poster?: string | undefined;
};
export declare function prepareReviewEntrance(event: MouseEvent<HTMLElement>): void;
export declare function readReviewOrigin(opener: HTMLElement | null): ReviewOrigin | undefined;
/** Animate the live media into the final viewer layout, with chrome following. */
export declare function useReviewEntrance(frame: RefObject<HTMLElement | null>, origin: ReviewOrigin | undefined, close: () => void, returnToOrigin: boolean, returnOrigin?: () => ReviewOrigin | undefined): {
    dismiss: (pointer: boolean) => void;
};
export {};
