/** Match message navigation policy; never put an unchecked href in the editor. */
export declare function composerLinkUrl(value: string): string | undefined;
