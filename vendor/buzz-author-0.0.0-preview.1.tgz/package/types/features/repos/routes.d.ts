import type { NavigationScope, OpenTarget } from "../navigation/targets.ts";
export declare const entityTabs: readonly ["files", "commits", "issues", "prs", "contributors", "channels"];
export type EntityTab = (typeof entityTabs)[number];
export type EntityRoute = {
    type: "repo";
    owner: string;
    dtag: string;
    tab?: EntityTab;
    commit?: string;
} | {
    type: "pr" | "issue";
    owner: string;
    dtag: string;
    id: string;
};
export declare const entityHex: RegExp;
export declare const gitHash: RegExp;
export declare function entityDtag(value: string): boolean;
/** Canonical Buzz entity forms shared by OS ingress, message links and page routes. */
export declare function parseEntityLink(url: URL): EntityRoute | null;
export declare function parseEntityRoute(value: unknown): EntityRoute | null;
export declare function entityTarget(route: EntityRoute, scope: NavigationScope): OpenTarget;
export declare function entityHref(route: EntityRoute): string;
