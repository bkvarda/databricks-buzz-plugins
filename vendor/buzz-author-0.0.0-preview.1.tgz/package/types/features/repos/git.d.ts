export type GitRead = {
    owner: string;
    dtag: string;
    commit?: string;
    path?: string;
};
export type GitCommit = {
    hash: string;
    author: string;
    date: number;
    subject: string;
};
export type GitSnapshot = {
    head: string | null;
    commits: GitCommit[];
    files: {
        path: string;
        hash: string;
        size: number;
    }[];
    readme: string | null;
    file: {
        path: string;
        content: string | null;
        size: number;
    } | null;
    diff: string | null;
};
export interface RepoGit {
    read(input: GitRead, signal: AbortSignal): Promise<GitSnapshot>;
}
export declare const GIT_READ_BYTES: number;
/** The canonical URL of a Buzz git repository hosted by this community, or null for any
 * other URL. `origin` is the community's https origin. Hosts re-validate before signing. */
export declare function communityGitRepository(origin: string, input: string): string | null;
export declare function parseGitRead(input: unknown): GitRead;
/** Byte-bound before JSON parsing, on both sides of the development bridge. */
export declare function gitReadText(response: Response): Promise<string>;
export declare function repoGitHost(request: (body: GitRead, signal: AbortSignal) => Promise<Response>): RepoGit;
