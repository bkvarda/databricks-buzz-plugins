import type { Presence, PresenceStatus } from "./presence";
export declare function usePresenceStatus(presence: Presence | undefined, pubkey: string | undefined, profile?: boolean): PresenceStatus;
/** Text and distinct symbols keep presence readable without color perception. */
export declare function PresenceIndicator({ presence, pubkey, profile, }: {
    presence: Presence;
    pubkey: string;
    profile?: boolean;
}): import("react").JSX.Element | null;
