import { type EventData, type ReadFilter } from "../relay/events";
import type { PresenceActivity } from "./activity";
import type { Presence } from "./presence";
type Deps = {
    /** The verified NIP-OA owner of an agent's winning kind 0, if any. */
    owner(pubkey: string): string | undefined;
    /** Notifies when profile heads, and so owners, change. */
    subscribeOwners(listener: () => void): () => void;
    /** Whether observed presence holds a shown subject past its demand limit.
     * Such an agent is neither read nor marked, so the limit stays one. */
    limited(pubkey: string): boolean;
    /** Notifies when demand moves subjects within or past that limit. */
    subscribeSelection(listener: () => void): () => void;
    /** App visibility. No read starts while hidden; absent, the app is shown. */
    activity?: PresenceActivity | undefined;
    read(filters: readonly ReadFilter[], signal: AbortSignal): Promise<readonly EventData[]>;
    notify(listener: () => void): void;
};
/** Agents a remote runtime runs. They wake on mentions and hold no socket, so
 * relay presence cannot show them; the owner's record is the evidence. Only a
 * record signed by the owner the agent's own profile attests counts. Display
 * only: it grants nothing and does not prove the agent is running. */
export declare function createHostedAgents(deps: Deps): {
    hosted: (key: string) => boolean;
    /** The runtimes, by agent type key, that run agents remotely. */
    remoteRuntimes(keys: Iterable<string>): void;
    subscribe(key: string, listener: () => void): () => void;
    connected(value: boolean): void;
    /** Drops evidence read under earlier access and reads again. */
    clear(): void;
    dispose(): void;
};
export type HostedAgents = ReturnType<typeof createHostedAgents>;
/** Presence that shows hosted agents online whatever the relay reports. Every
 * other subject, the viewer included, keeps its observed status. `limited`
 * passes through: an agent past the demand limit is neither read nor marked. */
export declare function withHostedAgents(presence: Presence, hosted: HostedAgents): HostedPresence;
/** Presence that can learn which runtimes are remote; absent in test doubles. */
export type HostedPresence = Presence & {
    remoteRuntimes?(keys: Iterable<string>): void;
};
export {};
