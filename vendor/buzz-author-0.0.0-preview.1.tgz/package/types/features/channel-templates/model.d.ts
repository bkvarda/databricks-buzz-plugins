import { type TeamPayload, type TeamManifest } from "./team-payload.ts";
/** Private, community-scoped recipes. Never an OG channel-sections writer. */
export declare const KIT_TAG = "buzz-channel-kit-v1";
/** Separate discovery prevents older clients from rejecting the whole catalog. */
export declare const ME_KIT_TAG = "buzz-me-kit-v1";
export declare const KIT_RECORD_BYTES: number;
/** Canvas content a channel template may carry. */
export declare const TEMPLATE_CANVAS_BYTES: number;
export { LIVE_CANVAS_BYTES, LIVE_CANVAS_LIMIT } from "./canvas-limits.ts";
export type Lineup = {
    teamIds: string[];
    agents: string[];
    canvas: string;
};
export type Team = {
    type: "team";
    id: string;
    name: string;
    agents: string[];
    portable?: TeamManifest;
};
export type Template = Lineup & {
    type: "template";
    id: string;
    name: string;
    description: string;
};
export type Group = {
    id: string;
    name: string;
    defaultTemplateId: string;
};
export type Groups = {
    type: "groups";
    id: "me";
    groups: Group[];
    /** Project filing only; the channel's Solo label decides what is Solo. */
    assignments: Record<string, string>;
};
export type KitValue = Team | Template | Groups;
export type PayloadRecord = {
    version: 1;
    community: string;
    deleted: false;
    value: TeamPayload & {
        type: "team-payload";
        id: string;
    };
};
/** A team's shared instructions, kept apart from its v1/v2 team record so
 * older builds that only read team records never see it. */
export declare const TEAM_TEXT_TAG = "buzz-team-text-v1";
export type TextRecord = {
    version: 1;
    community: string;
    deleted: boolean;
    value: {
        type: "team-text";
        id: string;
        owner: string;
        manifest: TeamManifest | null;
    };
};
export type PrivateRecord = KitRecord | PayloadRecord | TextRecord;
export type KitRecord = {
    version: 1 | 2;
    community: string;
    deleted: boolean;
    value: KitValue;
};
export type KitEntry = {
    record: KitRecord;
    eventId: string;
    createdAt: number;
};
export type AgentChoice = {
    pubkey: string;
    name: string;
    avatar?: string | undefined;
};
export declare const emptyLineup: () => Lineup;
export declare function object(value: unknown): Record<string, unknown>;
export declare function parseLineup(raw: unknown): Lineup;
export declare function kitRecordFits(record: KitRecord): boolean;
export declare const soloCapacityMessage = "Solo workspace storage is full. Remove a chat from a workspace, then try again.";
export declare function parseKitRecord(raw: unknown, community: string): KitRecord;
export declare function kitTag(record: KitRecord): "buzz-channel-kit-v1" | "buzz-channel-kit-v2" | "buzz-me-kit-v1";
export declare function coordinate(record: KitRecord): string;
export declare function resolveLineup(lineup: Lineup, entries: readonly KitEntry[], agents: readonly AgentChoice[]): AgentChoice[];
export declare function parsePayloadRecord(raw: unknown, community: string): PayloadRecord;
export declare function parseTextRecord(raw: unknown, community: string): TextRecord;
export declare function textCoordinate(community: string, owner: string, teamId: string): string;
export declare function parsePrivateRecord(raw: unknown, community: string): PrivateRecord;
export declare function privateCoordinate(record: PrivateRecord): string;
export declare function privateTag(record: PrivateRecord): "buzz-channel-kit-v1" | "buzz-channel-kit-v2" | "buzz-me-kit-v1" | "buzz-team-payload-v1" | "buzz-team-text-v1";
