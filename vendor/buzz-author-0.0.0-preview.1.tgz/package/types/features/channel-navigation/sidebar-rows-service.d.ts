import { Service, type Context } from "@deepseek-ai/cordis";
import type { ReactElement } from "react";
import type { ChannelSummary } from "../relay/contracts";
import type { UnreadSnapshot } from "../relay/unread";
import { type Contribution } from "../../plugins/contributions";
import { type SidebarSortMode } from "../relay/sidebar-sort";
export type SidebarRow = Readonly<{
    id: string;
    kind: "team" | "dm";
    label: string;
    sectionKey: string;
    channel: ChannelSummary;
    unread: UnreadSnapshot;
}>;
export type SidebarRowSortMode = Readonly<{
    id: string;
    label: string;
    compare: (a: SidebarRow, b: SidebarRow) => number;
}>;
export type SidebarRowContribution = Readonly<{
    version: 1;
    id: string;
    render?: (row: SidebarRow, Default: ReactElement | null) => ReactElement | null;
    sortModes?: readonly SidebarRowSortMode[];
}>;
export type RegisteredSidebarRows = Contribution<SidebarRowContribution>;
export type SidebarRows = Readonly<{
    version: 1;
    snapshot: () => readonly RegisteredSidebarRows[];
    subscribe: (listener: () => void) => () => void;
    settled?: () => boolean;
    register: (contribution: SidebarRowContribution) => void;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        /** Read through reflect for compatibility with hosts without row contributions. */
        sidebarRows?: SidebarRows;
    }
}
export declare class SidebarRowsService extends Service implements SidebarRows {
    readonly version: 1;
    private readonly contributions;
    private source;
    private ordered;
    constructor(ctx: Context);
    snapshot: () => readonly Readonly<Readonly<{
        version: 1;
        id: string;
        render?: (row: SidebarRow, Default: ReactElement | null) => ReactElement | null;
        sortModes?: readonly SidebarRowSortMode[];
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    settled: () => boolean;
    subscribe: (listener: () => void) => () => void;
    register(value: SidebarRowContribution): void;
}
export declare function sidebarRow(channel: ChannelSummary, sectionKey: string, unread: UnreadSnapshot): SidebarRow;
export declare function sidebarRowSortModes(entries: readonly RegisteredSidebarRows[]): {
    label: string;
    compare: (a: SidebarRow, b: SidebarRow) => number;
    id: SidebarSortMode;
}[];
export declare function sortSidebarRows<T>(rows: readonly T[], mode: SidebarRowSortMode | undefined, data: (row: T) => SidebarRow): readonly T[];
