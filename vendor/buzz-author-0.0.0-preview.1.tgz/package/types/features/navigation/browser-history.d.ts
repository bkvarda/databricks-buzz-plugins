import { type NavigationHistory } from "./history";
/** One browser session-history driver: toolbar/shortcuts call go; popstate never pushes. */
export declare function createBrowserHistory(host: Window): NavigationHistory;
