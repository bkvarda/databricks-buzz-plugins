import { type EntityRoute } from "../repos/routes";
import { type GitPluginSource, type NavigationScope } from "./targets";
type BuzzLink = {
    format: "plugin-install";
    source: GitPluginSource;
} | {
    format: "removed";
} | {
    format: "entity";
    route: EntityRoute;
} | {
    format: "plugin";
    pluginId: string;
    pageId?: string;
    params?: Readonly<Record<string, string>>;
} | {
    format: "legacy";
    channelId: string;
    messageId?: string;
    threadRootId?: string;
};
/** True for any `buzz:` scheme link, regardless of case. Classification must
 * match `parseBuzzLink`, which normalizes the scheme via `URL`; a lowercase-only
 * `startsWith` check would misroute `BUZZ://…` to external handling. */
export declare function isBuzzLink(href: string): boolean;
/** Legacy links are relative to the receiving conversation's community, never an access grant. */
export declare function parseBuzzLink(href: string): BuzzLink | null;
export declare function buzzLinkKind(href: string): "buzz" | "channel" | "message" | "thread" | null;
export declare function buzzLinkTarget(href: string, scope: NavigationScope): import("./targets").OpenTarget | null;
export {};
