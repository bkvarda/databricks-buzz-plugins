import { type ReactNode } from "react";
/** Layout owns overlay breakpoints; CSS owns motion and input preferences.
 * Retain closing content only until its own transitions finish, without timers.
 * Selection, focus restoration, and page lifetime remain with the callers. */
export declare function PanelDock({ open, className, children, resizeHandle, keepMounted, }: {
    open: boolean;
    className: string | undefined;
    children: ReactNode;
    resizeHandle?: ReactNode;
    /** A collapsible workspace keeps its tab contents and local view state. */
    keepMounted?: boolean;
}): import("react").JSX.Element | null;
