import type { PanelProps, RegisteredPanel } from "./service";
export declare function PanelView({ panel, ...props }: PanelProps & {
    panel: RegisteredPanel;
}): import("react").JSX.Element;
