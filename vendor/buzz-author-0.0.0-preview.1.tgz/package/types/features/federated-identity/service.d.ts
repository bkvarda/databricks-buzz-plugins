import { Service, type Context } from "@deepseek-ai/cordis";
import type { HostResponse } from "../host/service";
export type SessionSnapshot = Readonly<{
    status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
    authority: Readonly<{
        id: string;
        identityOrigin: string;
        apiBasePath: string;
        /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
        signIn: "on-demand" | "at-launch";
        /** Display name for sign-in copy, such as "Block". */
        organization: string | null;
    }> | null;
    revision: string;
    email: string | null;
    failure: string | null;
    /** When the signed-in session ends (RFC 3339). */
    expiresAt: string | null;
    /** The session ends soon; signing in again now keeps the app open. */
    expiring: boolean;
}>;
export type AuthenticatedRequest = Readonly<{
    path: string;
    method?: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
    headers?: Readonly<Record<string, string>>;
    body?: string;
}>;
export interface FederatedIdentity {
    /** Granted routes are forwarded natively with the session as a Bearer token. */
    readonly apiAvailable: boolean;
    snapshot(): SessionSnapshot;
    subscribe(listener: () => void): () => void;
    signIn(): Promise<SessionSnapshot>;
    cancelSignIn(): Promise<void>;
    signOut(): Promise<void>;
    request(input: AuthenticatedRequest): Promise<HostResponse>;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        federatedIdentity: FederatedIdentity;
    }
}
export declare class FederatedIdentityService extends Service implements FederatedIdentity {
    readonly apiAvailable: boolean;
    private readonly shared;
    constructor(ctx: Context);
    private accept;
    snapshot: () => Readonly<{
        status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
        authority: Readonly<{
            id: string;
            identityOrigin: string;
            apiBasePath: string;
            /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
            signIn: "on-demand" | "at-launch";
            /** Display name for sign-in copy, such as "Block". */
            organization: string | null;
        }> | null;
        revision: string;
        email: string | null;
        failure: string | null;
        /** When the signed-in session ends (RFC 3339). */
        expiresAt: string | null;
        /** The session ends soon; signing in again now keeps the app open. */
        expiring: boolean;
    }>;
    subscribe: (listener: () => void) => () => void;
    private operation;
    signIn(): Promise<Readonly<{
        status: "unconfigured" | "signed-out" | "signing-in" | "restoring" | "signed-in" | "reauthentication-required" | "unavailable";
        authority: Readonly<{
            id: string;
            identityOrigin: string;
            apiBasePath: string;
            /** `at-launch` builds sign in before the app opens; see LaunchSignIn. */
            signIn: "on-demand" | "at-launch";
            /** Display name for sign-in copy, such as "Block". */
            organization: string | null;
        }> | null;
        revision: string;
        email: string | null;
        failure: string | null;
        /** When the signed-in session ends (RFC 3339). */
        expiresAt: string | null;
        /** The session ends soon; signing in again now keeps the app open. */
        expiring: boolean;
    }>>;
    signOut(): Promise<void>;
    cancelSignIn(): Promise<void>;
    request(request: AuthenticatedRequest): Promise<HostResponse>;
    private registration;
}
/** Calls `reauthorize` when the session becomes signed in or changes account,
 * so every relay read it refused retries at once instead of waiting for a
 * manual Retry. Startup restore is not a change: nothing was refused for it. */
export declare function onSignedIn(identity: FederatedIdentity, reauthorize: () => void): () => void;
