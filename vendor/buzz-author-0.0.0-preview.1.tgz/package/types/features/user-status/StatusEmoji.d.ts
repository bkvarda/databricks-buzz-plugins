import type { RelaySession } from "../relay/session";
export declare function StatusEmoji({ value, url, session, decorative, fallback, }: {
    value: string;
    /** The status event's own image URL; the catalog is the fallback. */
    url?: string | undefined;
    session: RelaySession;
    decorative?: boolean;
    /** Icon-sized slots show this glyph for an empty or unresolved value. */
    fallback?: string;
}): import("react").JSX.Element | null;
