import type { RelaySession } from "../relay/session";
/** An emoji's `:name:`. A custom code names itself; Unicode names load with the
 * reaction table, once, when a named emoji mounts. Free text has no name. */
export declare function useEmojiName(value: string): string | undefined;
export declare function StatusEmoji({ value, url, session, decorative, fallback, hint, }: {
    value: string;
    /** The status event's own image URL; the catalog is the fallback. */
    url?: string | undefined;
    session: RelaySession;
    decorative?: boolean;
    /** Icon-sized slots show this glyph for an empty or unresolved value. */
    fallback?: string;
    /** Name the emoji on hover where the full status is already displayed. */
    hint?: boolean;
}): import("react").JSX.Element | null;
