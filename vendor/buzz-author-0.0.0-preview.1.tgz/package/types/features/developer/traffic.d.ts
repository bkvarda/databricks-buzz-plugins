/** Traffic logs are allowlists, never truncated payload dumps. */
export declare function relayLabel(url: string): string;
export declare function httpLabel(path: string): string;
export declare function filterSummary(filters: unknown): string;
/** Negative OK text is untrusted. Preserve only fixed public protocol reasons. */
export declare function publicationRefusal(reason: string): string;
export declare function logSocketFrame(peer: string, direction: "→" | "←", raw: unknown, frame?: unknown): void;
