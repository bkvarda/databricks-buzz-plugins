import "./MatchedLabel.css";
/** A label with its matched letters underlined. The text stays whole, so the
 * row's accessible name does not change. */
export declare function MatchedLabel({ label, positions, }: {
    label: string;
    positions: readonly number[] | undefined;
}): string | (string | import("react").JSX.Element)[];
