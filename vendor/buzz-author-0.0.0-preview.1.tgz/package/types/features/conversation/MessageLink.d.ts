import { type ReactNode } from "react";
import { type Contribution } from "../../plugins/contributions";
import type { ContributionReader, LinkRenderer } from "./contracts";
import type { RelaySession } from "../relay/session";
import { type ComposerSession } from "../messages/composer-session";
/** Lowest `order` among active matches wins, like panels; a broken matcher
 * leaves other candidates eligible and never prevents opening a link. */
export declare const resolveLink: (url: string, renderers: readonly Contribution<LinkRenderer>[]) => Readonly<Readonly<{
    id: string;
    title: string;
    matches(url: string): boolean;
    order?: import("../../plugins/contributions").MatchOrder | undefined;
    className?: string | undefined;
    component: import("react").ComponentType<{
        url: string;
    }>;
}> & {
    key: string;
    pluginId: string;
    revision: string;
}> | undefined;
export declare function MessageLink({ url, children, registry, onOpenLink, canOpenLink, label, directoryLabel, session, scope, interactive, channelPrivate, }: {
    url: string;
    children?: ReactNode;
    registry: ContributionReader<LinkRenderer> | undefined;
    onOpenLink(url: string): boolean;
    canOpenLink?: ((url: string) => boolean) | undefined;
    label?: string | undefined;
    /** The receiving community's name for a raw destination. Display only: a raw
     * link copies as its URL. */
    directoryLabel?: string | undefined;
    session?: RelaySession | ComposerSession | undefined;
    scope?: string | undefined;
    interactive?: boolean;
    channelPrivate?: boolean;
}): import("react").JSX.Element;
