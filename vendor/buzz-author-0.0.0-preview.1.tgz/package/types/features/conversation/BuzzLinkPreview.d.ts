import type { RelaySession } from "../relay/session";
import type { ChannelReference } from "../relay/contracts";
/** Why a message link's preview can't be shown. Surfaces that report a failed
 * message link use these words too. */
export declare const previewFailures: {
    readonly withheld: "Private channel. You aren’t a member, it no longer exists, or the link is from another community.";
    readonly "not-found": "This message isn’t available. It may have been deleted.";
    readonly unavailable: "Couldn’t load this preview.";
};
type FoundChannel = Extract<ChannelReference, {
    state: "found";
}>;
/** Mounted only while a preview is open. The session owns access, edits and
 * deletion. Like a click, the card looks the channel up before trusting a
 * refused read: an unjoined public channel is readable once found, and one
 * the viewer left once a lookup confirms it is still open. */
export declare function BuzzLinkPreview({ session, channelId, messageId, }: {
    session: RelaySession;
    channelId: string;
    messageId: string;
}): import("react").JSX.Element;
/** Hover card for a channel-only link. The store supplies what the reader
 * may see; a nonmember sees an open channel's public metadata, never its
 * roster. */
export declare function ChannelLinkPreview({ channel }: {
    channel: FoundChannel;
}): import("react").JSX.Element;
export {};
