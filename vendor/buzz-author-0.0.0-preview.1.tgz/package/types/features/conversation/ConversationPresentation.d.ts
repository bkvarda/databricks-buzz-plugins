/** Presentation only: retained readers/editors keep their data and effects. */
export declare const ConversationPresentation: import("react").Context<boolean>;
export declare const useConversationPresentation: () => boolean;
