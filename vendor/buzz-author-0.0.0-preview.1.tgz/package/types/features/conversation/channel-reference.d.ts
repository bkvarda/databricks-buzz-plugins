import type { ChannelQueries, ChannelReference } from "../relay/contracts";
/**
 * What a link can show about a channel the reader may not have joined. The
 * store owns the lookup, its batching, expiry and retry; this hook only
 * demands the channel while the list is ready. The store looks up only an
 * answer that isn't a readable `found`, because discovery owns access.
 */
export declare function useChannelReference(queries: ChannelQueries | undefined, channelId: string | undefined): ChannelReference;
/** A found channel that a link presents as a channel. DMs and Solo chats keep
 * their own presentation. */
export declare function namedChannel(reference: ChannelReference): Readonly<{
    state: "found";
    name: string;
    description?: string;
    channelType?: import("../relay/contracts").ChannelSummary["channelType"];
    private: boolean;
    hidden: boolean;
    archived: boolean;
    joined: boolean;
    members?: number;
    readable?: false;
    looking?: true;
}> | undefined;
