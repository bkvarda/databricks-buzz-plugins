import { type ReactNode } from "react";
/** Optional host-resolved display label; presentation never resolves a destination. */
export declare const LinkLabelContext: import("react").Context<string | undefined>;
/** Authored Markdown formatting stays inside the host anchor. */
export declare const LinkContentContext: import("react").Context<ReactNode>;
/** Host-resolved visibility for channel links rendered by a shared link renderer. */
export declare const LinkChannelPrivateContext: import("react").Context<boolean>;
/** Whether the link is live in a message, rather than a composer decoration or
 * preview: a renderer that reads anything for its link does so only then. */
export declare const LinkInteractiveContext: import("react").Context<boolean>;
/** Sets the host anchor's description, such as a pull request's state, so a
 * renderer's status reaches assistive technology without joining the link's
 * name. Undefined when there is no anchor to describe. */
export declare const LinkDescriptionContext: import("react").Context<((description: string | undefined) => void) | undefined>;
/** Host workspace opener for a message link's thread tab; false when it cannot. */
export declare const LinkThreadTabContext: import("react").Context<((channelId: string, messageId: string, rootId: string) => boolean) | undefined>;
