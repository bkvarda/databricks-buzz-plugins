import type { RelaySession } from "../relay/session";
import type { ThreadSnapshot } from "../relay/threads";
/** The linked message in an exact thread view. Only reconciled content is
 * ready: a ready exact target is independent of its thread root, while an
 * idle/loading root seed is still the raw event. A terminal state (read error,
 * denied/interrupted purge, or an exhausted read that never found the target)
 * stops instead of loading forever. */
export declare function linkedMessage(snapshot: ThreadSnapshot, messageId: string): {
    message: Readonly<{
        id: string;
        channelId: string;
        delivery?: import("../relay/outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("../relay/contracts").MembershipChange;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("../relay/contracts").Attachment[];
        emoji?: readonly import("../relay/emoji").CustomEmoji[];
        reactions: readonly import("../relay/contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }> | undefined;
    ready: boolean;
    stopped: boolean;
};
/** "<author> in #<channel>" for a link to a message in a listed channel, once
 * the session knows who wrote it and that author has a name. Undefined while
 * that is unknown, while the channel's membership awaits relay confirmation,
 * and for DMs and Solo chats, which keep their existing presentation. */
export declare function useLinkedMessageByline(session: RelaySession | undefined, channelId: string | undefined, messageId: string | undefined): string | undefined;
