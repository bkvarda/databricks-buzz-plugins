import { Component, type ReactNode } from "react";
export declare function contributionKey(entry: object): number;
export declare class ContributionBoundary extends Component<{
    children: ReactNode;
    fallback: ReactNode;
    resetIdentity?: unknown;
    /** True when the fallback replaces the children; false when a failed boundary unmounts. */
    onFailedChange?: ((failed: boolean) => void) | undefined;
}, {
    failed: boolean;
    resetIdentity?: unknown;
}> {
    state: {
        failed: boolean;
        resetIdentity: unknown;
    };
    static getDerivedStateFromProps(props: ContributionBoundary["props"], state: ContributionBoundary["state"]): {
        failed: boolean;
        resetIdentity: unknown;
    } | null;
    static getDerivedStateFromError(): {
        failed: boolean;
    };
    componentDidCatch(): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): ReactNode;
}
