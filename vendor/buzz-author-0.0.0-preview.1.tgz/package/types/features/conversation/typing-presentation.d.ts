import { type ReactNode } from "react";
import type { RelaySession } from "../relay/session";
type Replacement = Readonly<{
    session: RelaySession;
    channelId: string;
    threadRootId: string | undefined;
    pubkey: string;
    requestId?: string | undefined;
}>;
/** Mounted conversation presentation only; no data, timers, or plugin identity checks. */
export declare function TypingPresentation({ active, children, }: {
    active: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useTypingReplacement(value: Replacement | undefined, enabled: boolean): void;
export declare function ActivityIndicatorPresentation({ children, }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useActivityTypingReplacement(value: Replacement | undefined, enabled: boolean, participants?: readonly string[]): void;
export declare function useReplacedTypers(session: object | undefined, channelId: string, threadRootId: string | undefined): ReadonlySet<string>;
/** Recorded history owns request controls only while that history is mounted. */
export declare function useRecordedActivityAgents(session: object, channelId: string, requestId: string | undefined): ReadonlySet<string>;
export {};
