import { type ComponentType, type ReactNode } from "react";
import type { Contribution } from "../../plugins/contributions";
import type { ContributionReader, TargetOpener } from "./contracts";
/**
 * The conversation host that decides where a plugin target opens, such as a
 * channel's side-pane tabs. Outside a provider, nothing opens.
 */
export declare function TargetOpenerProvider({ canOpen, open, children, }: {
    canOpen?: ((target: string) => boolean) | undefined;
    open?: ((target: string) => boolean) | undefined;
    children: ReactNode;
}): import("react").JSX.Element;
/** Revoked when this mount retires or its exact contribution is removed. */
export declare function useTargetOpener<T>(registry: ContributionReader<T>, entry: Contribution<T>): TargetOpener;
/** Renders a contribution with the host's opener added to its props. */
export declare function WithTargetOpener<P extends object, T>({ component: Component, props, registry, entry, }: {
    component: ComponentType<P & TargetOpener>;
    props: P;
    registry: ContributionReader<T>;
    entry: Contribution<T>;
}): import("react").JSX.Element;
