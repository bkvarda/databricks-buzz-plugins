import type { ThreadPanelProps } from "../messages/ThreadPanel";
import type { ConversationHostServices } from "./ConversationHost";
/** The host owns conversation behavior; the page owns its task and placement. */
export type EmbeddedThreadProps = Pick<ThreadPanelProps, "session" | "scope" | "channelId" | "channelName" | "messageId">;
type Props = EmbeddedThreadProps & {
    host: ConversationHostServices;
    extensions: NonNullable<ThreadPanelProps["extensions"]>;
};
/** Channel visits and recovery span threads; overlays belong to one thread. */
export declare function EmbeddedThread({ session, scope, channelId, channelName, messageId, host, extensions, }: Props): import("react").JSX.Element;
export {};
