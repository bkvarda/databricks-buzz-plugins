import { type ReactNode } from "react";
import type { ThreadPanelProps } from "../messages/ThreadPanel";
import type { ConversationHostServices, ConversationInteractions } from "./ConversationHost";
/** The host owns conversation behavior; the page owns its task and placement. */
export type EmbeddedThreadProps = Pick<ThreadPanelProps, "session" | "scope" | "channelId" | "channelName" | "messageId">;
/** One channel's host behavior for a page's own rows and composer, without a visit. */
export type EmbeddedConversationProps = Pick<ThreadPanelProps, "session" | "scope" | "channelId"> & {
    channelName?: string | undefined;
    /** The thread a card shows; panels opened from it stay in that thread. */
    threadId?: string | undefined;
    children(interactions: ConversationInteractions): ReactNode;
};
type Hosted = {
    host: ConversationHostServices;
    extensions: NonNullable<ThreadPanelProps["extensions"]>;
};
/** Channel visits and recovery span threads; overlays belong to one thread. */
export declare function EmbeddedThread({ messageId, ...props }: EmbeddedThreadProps & Hosted): import("react").JSX.Element;
/** Rows and composer act as in Channels; nothing marks the channel read or follows it. */
export declare function EmbeddedConversation({ children, ...props }: EmbeddedConversationProps & Hosted): import("react").JSX.Element;
export {};
