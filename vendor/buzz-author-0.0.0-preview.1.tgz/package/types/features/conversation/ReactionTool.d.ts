import type { RelaySession } from "../relay/session";
import type { EventData } from "../relay/events";
import type { ComposerTool, ContributionReader } from "./contracts";
import type { Contribution } from "../../plugins/contributions";
export declare function selectReactionTool(tools: readonly Contribution<ComposerTool>[]): Readonly<Readonly<{
    id: string;
    title: string;
    order?: number;
    component: import("react").ComponentType<import("./contracts").ComposerToolProps>;
    reactionComponent?: import("react").ComponentType<import("./contracts").ReactionToolProps>;
}> & {
    key: string;
    pluginId: string;
    revision: string;
}> | undefined;
export declare function ReactionTool({ registry, ...props }: {
    registry: ContributionReader<ComposerTool>;
    session: RelaySession;
    scope: string;
    messageId: string;
    disabled: boolean;
    select?: (emoji: string) => boolean;
    showDelivery?: boolean;
}): import("react").JSX.Element | null;
export declare function reactionTarget(event: Pick<EventData, "kind" | "tags">): string | undefined;
export declare function ReactionDelivery({ session, messageId, }: {
    session: RelaySession;
    messageId: string;
}): import("react").JSX.Element | null;
