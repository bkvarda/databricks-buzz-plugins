import type { Membership } from "./service";
/** Keep untrusted relay metadata out of executable URL schemes and huge data URLs. */
export declare function communityIcon(value: unknown): string | undefined;
/** Existing optional NIP-11 discovery, without join policy or a relay session. */
export declare function fetchCommunityPresentation(id: string, signal: AbortSignal): Promise<{
    publishedName: string | undefined;
    publishedIcon: string | undefined;
}>;
/** Resolve display-only metadata without acquiring a community session. */
export declare function communityPresentation(origin: string, memberships?: readonly Membership[]): {
    id: string;
    name: string;
    src: string | undefined;
};
