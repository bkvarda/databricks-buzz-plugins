export declare function registerCommunity(id: string, signal?: AbortSignal): Promise<void>;
export declare function connectCommunityTransport(id: string, signal?: AbortSignal): Promise<import("../relay/transport").ReadTransport>;
