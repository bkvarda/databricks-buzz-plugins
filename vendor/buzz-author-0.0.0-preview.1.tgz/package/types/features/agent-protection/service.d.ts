import { Service, type Context } from "@deepseek-ai/cordis";
import type { Agent, RegisteredAgentType } from "../agents/service";
import type { ProcessProtection } from "../host/service";
import type { ReviewPrompt, ReviewModel, ReviewModelProvider, ProtectedSpawn } from "./models";
export type ProtectionBinding = Readonly<{
    provider: string;
    policy: unknown;
}>;
export type ProtectionAction = Readonly<{
    kind: "context" | "tool" | "tool-result";
    session: string;
    content: unknown;
    command?: string;
}>;
export type ProtectionPhases = Readonly<Record<ProtectionAction["kind"], boolean>>;
export declare const ALL_PHASES: ProtectionPhases;
export type ProtectionRequest = ProtectionAction & Readonly<{
    agent: Readonly<{
        id: string;
        pubkey: string;
        name: string;
    }>;
    relay: string;
    runtime: string;
    policy: unknown;
}>;
/** A denial its provider explained, for Buzz to show people. */
export type ProtectionDenial = Readonly<{
    allowed: false;
    reason: string;
}>;
export type ProtectionProvider = Readonly<{
    phases?(policy: unknown): ProtectionPhases;
    /** Checks one immutable action. Failure, removal and cancellation deny it. */
    check(request: ProtectionRequest, signal: AbortSignal): Promise<boolean | ProtectionDenial>;
    processProtection: ProcessProtection;
    /** Runtime owner to a process declared by this protection plugin. */
    runtimeProcesses?: Readonly<Record<string, string>>;
}>;
export type AgentProtection = Readonly<{
    phases?: ProtectionPhases;
    /** Changes when the saved policy or registered provider changes. */
    key: string;
    /** Stable native policy revision, for isolated durable runtime state. */
    stateKey: string;
    processProtection: ProcessProtection;
    /** Starts this agent's plugin-supplied engine under its captured containment. */
    spawn: ProtectedSpawn;
    assertAvailable(): void;
    check(action: ProtectionAction, signal: AbortSignal): Promise<void>;
}>;
/** Its message is all the agent sees; `reason` is the provider's explanation,
 * for people. */
export declare class ProtectionDenied extends Error {
    readonly reason: string | undefined;
    constructor(reason?: string);
}
export type ProtectionDefaults = {
    revision: number;
    defaults: ProtectionBinding | null;
};
export declare class AgentProtectionService extends Service {
    private current;
    private native;
    readonly available = true;
    readonly version = 3;
    private providers;
    private epoch;
    private modelProviders;
    constructor(ctx: Context, current: () => {
        owner: string | undefined;
        agents: readonly Agent[];
        types?: readonly Pick<RegisteredAgentType, "key" | "protection" | "protectionUnavailable">[];
    }, native: {
        read(owner: string): Promise<ProtectionDefaults>;
        save(owner: string, revision: number, provider: string, policy: unknown | null): Promise<void>;
        update(pubkey: string, revision: number, provider: string, policy: unknown | null): Promise<void>;
    });
    private owner;
    private plugin;
    /** Each runtime retains credential and provider ownership. */
    registerModels(provider: ReviewModelProvider): import("@deepseek-ai/cordis").Disposable<Promise<void>>;
    modelChoices(): Promise<{
        runtime: string;
        label: string;
        models: never[] | readonly Readonly<{
            provider?: string;
            id: string;
            label: string;
        }>[];
    }[]>;
    /** Bounded, tool-free inference; the calling plugin owns prompts and parsing. */
    complete(model: ReviewModel, prompt: ReviewPrompt, signal: AbortSignal, requester?: Readonly<{
        agent: Readonly<{
            pubkey: string;
        }>;
        relay: string;
    }>): Promise<{
        text: string;
        model: {
            provider?: string;
            id: string;
            runtime: string;
        };
    }>;
    snapshot(): Promise<{
        revision: number;
        defaults: Readonly<{
            provider: string;
            policy: unknown;
        }> | null;
        agents: {
            id: string;
            pubkey: string;
            name: string;
            type: string;
            revision: number;
            binding: Readonly<{
                provider: string;
                policy: unknown;
            }> | null;
            coverage: {
                supported: boolean;
                reason?: never;
            } | {
                supported: boolean;
                reason: string;
            };
        }[];
    }>;
    register(value: ProtectionProvider): {
        dispose: () => void;
    };
    private runtimeSpawn;
    saveDefaults(revision: number, policy: unknown | null): Promise<void>;
    saveAgent(pubkey: string, revision: number, policy: unknown | null): Promise<void>;
    bind(agent: Pick<Agent, "pubkey" | "key" | "owner" | "name" | "type" | "relay" | "protection" | "protectionRevision">): AgentProtection | undefined;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        agentProtection: AgentProtectionService;
    }
}
