import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType, ReactNode } from "react";
import { type Contribution } from "../../plugins/contributions.ts";
export type PageProps = {
    companion?: ReactNode | undefined;
    /** Opaque identity for the current shell-owned companion opening. */
    companionOpening?: object | undefined;
    navigation?: import("../navigation/service").PageNavigation | undefined;
};
/** Props for a page-owned replacement in the shell's sidebar slot. */
export type PageSidebarProps = {
    target: import("../navigation/targets").OpenTarget;
    /** Shell-generated primary Pages navigation, when available. */
    children?: ReactNode | undefined;
};
export type Page = Readonly<{
    id: string;
    title: string;
    component: ComponentType<PageProps>;
    /** Replace the conversation sidebar while this page is selected. */
    sidebar?: ComponentType<PageSidebarProps>;
    layout?: "document" | "workspace";
    companion?: boolean;
    /** Opt in to versioned page routes. Validation is synchronous and side-effect-free. */
    route?: Readonly<{
        version: number;
        validate(params: import("../navigation/targets").JsonValue): boolean;
    }>;
    /** This page acknowledges its own domain reveal rather than just successful mounting. */
    handlesNavigation?: boolean;
    /**
     * Opt in to the shell's page navigation. Every active page stays
     * listed in search and reachable by deep link or from another page.
     */
    primary?: boolean;
    /** Preferred navigation location for a primary page; omitted means sidebar.
     * The host may move header entries into an overflow menu when space is tight.
     */
    placement?: "sidebar" | "topbar" | "toolbar";
    /**
     * A `data:image/<subtype>[;params],<payload>` URL shown beside the page in
     * search and primary navigation. Any other value is dropped with a warning,
     * and a missing or unloadable image shows the generic page icon. Bundled
     * pages keep their host icons.
     */
    icon?: string;
    /** Plugin-owned navigation count or mark. Toolbar icons constrain this to a
     * compact corner badge; prefer a short count or dot there.
     */
    badge?: ComponentType;
}>;
export type RegisteredPage = Contribution<Page>;
export type PagesReader = {
    snapshot: () => readonly RegisteredPage[];
    subscribe: (listener: () => void) => () => void;
};
export type Pages = PagesReader & {
    register(page: Page): void;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        pages: Pages;
    }
}
export declare class PagesService extends Service implements Pages {
    private readonly contributions;
    constructor(ctx: Context);
    snapshot: () => readonly Readonly<Readonly<{
        id: string;
        title: string;
        component: ComponentType<PageProps>;
        /** Replace the conversation sidebar while this page is selected. */
        sidebar?: ComponentType<PageSidebarProps>;
        layout?: "document" | "workspace";
        companion?: boolean;
        /** Opt in to versioned page routes. Validation is synchronous and side-effect-free. */
        route?: Readonly<{
            version: number;
            validate(params: import("../navigation/targets").JsonValue): boolean;
        }>;
        /** This page acknowledges its own domain reveal rather than just successful mounting. */
        handlesNavigation?: boolean;
        /**
         * Opt in to the shell's page navigation. Every active page stays
         * listed in search and reachable by deep link or from another page.
         */
        primary?: boolean;
        /** Preferred navigation location for a primary page; omitted means sidebar.
         * The host may move header entries into an overflow menu when space is tight.
         */
        placement?: "sidebar" | "topbar" | "toolbar";
        /**
         * A `data:image/<subtype>[;params],<payload>` URL shown beside the page in
         * search and primary navigation. Any other value is dropped with a warning,
         * and a missing or unloadable image shows the generic page icon. Bundled
         * pages keep their host icons.
         */
        icon?: string;
        /** Plugin-owned navigation count or mark. Toolbar icons constrain this to a
         * compact corner badge; prefer a short count or dot there.
         */
        badge?: ComponentType;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe: (listener: () => void) => () => void;
    register(page: Page): void;
    private withAcceptedPlacement;
    private withAcceptedIcon;
}
