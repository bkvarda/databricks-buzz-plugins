import type { createAgentActivity } from "./activity";
type Snapshot = ReturnType<ReturnType<typeof createAgentActivity>["queries"]["snapshot"]>;
/** Use the same request state as message bubbles. Pulses remain useful for
 * unassociated work, but cannot revive a request with known lifecycle evidence. */
export declare function threadWorkingAgents(activity: Snapshot | undefined, typing: readonly string[], channelId: string, rootId: string, represented?: {
    messageId: string;
    agents: ReadonlySet<string>;
}): readonly string[];
export {};
