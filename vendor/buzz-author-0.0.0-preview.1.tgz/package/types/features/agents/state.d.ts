import { type AgentStore } from "./store";
export { localStore, type AgentStore } from "./store";
/** The localStorage keys of agent state, moved into agent storage once. */
export declare function isAgentKey(key: string): boolean;
/** Agent storage, once `loadAgentStorage` has read it; localStorage before
 * that, and outside the desktop app. */
export declare function agentStorage(): AgentStore;
/** A window without native storage cannot know which agents are bound. */
export declare function executionStorage(fallback: AgentStore): AgentStore;
type Native = Readonly<{
    load(key?: string): Promise<Record<string, string>>;
    set(key: string, value: string | null): Promise<void>;
    /** Saves `value` only if no file holds `key`, in one step; resolves with
     * what the file held when one did, else null. */
    add?(key: string, value: string): Promise<string | null>;
}>;
/** Agent storage holds this key once every agent key in localStorage was
 * moved into it. */
export declare const MOVED_KEY = "buzz.agents.state-moved.v1";
/** Reads agent storage before the app starts. It moves agent state the app
 * kept in localStorage into it. Before the first move finishes, agent keys in
 * localStorage are the newer copy and replace what agent storage has. After
 * it, agent storage is the full copy: agent keys in localStorage come from a
 * start that could not use agent storage and began with none, so they fill
 * in only keys agent storage does not have. Agent keys leave localStorage
 * only once every one is saved; if agent storage cannot be read, a copy
 * fails, or this takes longer than `timeoutMs`, the app uses localStorage
 * until the next start. */
export declare function loadAgentStorage(local?: Storage, files?: Native | undefined, timeoutMs?: number): Promise<AgentStore>;
/** Agent storage holds a copy in memory and saves updates in order.
 * Atomic inserts wait only for writes to the same key. A failed write puts
 * back the saved value, so callers can retry it. */
export declare function fileStore(items: Map<string, string>, save: Native["set"], add?: NonNullable<Native["add"]>, read?: (key: string) => Promise<string | null>, scan?: AgentStore["scan"]): AgentStore;
