import { type AgentStore } from "./store";
export { localStore, type AgentStore } from "./store";
/** The localStorage keys of agent state, moved into agent storage once. */
export declare function isAgentKey(key: string): boolean;
/** Agent storage, once `loadAgentStorage` has read it; localStorage before
 * that, and outside the desktop app. */
export declare function agentStorage(): AgentStore;
type Native = Readonly<{
    load(): Promise<Record<string, string>>;
    set(key: string, value: string | null): Promise<void>;
    /** Saves `value` only if no file holds `key`, in one step; resolves with
     * what the file held when one did, else null. */
    add?(key: string, value: string): Promise<string | null>;
}>;
/** Agent storage holds this key once every agent key in localStorage was
 * moved into it. */
export declare const MOVED_KEY = "buzz.agents.state-moved.v1";
/** Reads agent storage before the app starts. It moves agent state the app
 * kept in localStorage into it. Before the first move finishes, agent keys in
 * localStorage are the newer copy and replace what agent storage has. After
 * it, agent storage is the full copy: agent keys in localStorage come from a
 * start that could not use agent storage and began with none, so they fill
 * in only keys agent storage does not have. Agent keys leave localStorage
 * only once every one is saved; if agent storage cannot be read, a copy
 * fails, or this takes longer than `timeoutMs`, the app uses localStorage
 * until the next start. */
export declare function loadAgentStorage(local?: Storage, files?: Native | undefined, timeoutMs?: number): Promise<AgentStore>;
/** Agent storage held in memory and saved through `save`, one write at a
 * time, in order. A failed write puts back the key's saved value, so the
 * copy never keeps what is not saved and the same value can be set again. */
export declare function fileStore(items: Map<string, string>, save: Native["set"], add?: NonNullable<Native["add"]>): AgentStore;
