import type { ComposerSession } from "../messages/composer-session";
/** Shared candidates only. Ordinary mentions observe legacy hints without loading
 * them; native inventory is still ensured through the app-owned controller.
 * Selectors that show `selectable` pass `archive` to demand archive evidence. */
export declare function useAgentChoices(session: ComposerSession, includeLegacy?: boolean, archive?: boolean): import("./choices").AgentChoicesSnapshot;
