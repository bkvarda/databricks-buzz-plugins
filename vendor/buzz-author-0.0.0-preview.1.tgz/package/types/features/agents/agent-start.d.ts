import { type AgentConfigStore, type ArtifactState, type SettingsSchema, type Subject } from "./agent-config";
import type { Team } from "./store";
export type Mode = "local" | "migrating" | "synced";
/** One team config channel that lists the agent as a member. */
export type TeamSource = Readonly<{
    id: string;
    lifecycle: "active" | "archived" | "unreadable";
    subject: Subject;
    members: readonly string[];
}>;
export type StartInput<C extends object> = Readonly<{
    store: AgentConfigStore;
    /** This device's row: the launch source in `local`/`migrating`, and the
     * only source of `workspace` and unsynced fields in every mode. */
    local: C;
    agentType: string;
    /** Absent while the agent has no config channel: the type is `local`. */
    settings?: Readonly<{
        mode: Mode;
        subject: Subject;
        schema: SettingsSchema;
        withSynced: (config: C, settings: Readonly<Record<string, string>>) => C;
    }>;
    instructions?: Readonly<{
        mode: Mode;
        subject: Subject;
    }>;
    /** Teams from the synced store; `undefined` while teams are still local. */
    teams?: readonly TeamSource[];
}>;
export type Start<C> = Readonly<{
    ok: true;
    config: C;
    teams?: readonly Team[];
    /** The synced revisions this start used. */
    revisions: readonly string[];
    /** The synced settings in `config`, which a launch refuses rather than
     * replace with a default when its runtime doesn't offer one. */
    synced?: Readonly<Record<string, string>>;
}> | Readonly<{
    ok: false;
    state: ArtifactState;
    reason: string;
}>;
/** Whether a side launches from its synced copy: explicitly synced, or this
 * device has had a synced revision of it, so a stale mode can't fall back. */
export declare const isSynced: (store: AgentConfigStore, side: Readonly<{
    mode: Mode;
    subject: Subject;
}> | undefined) => boolean;
/** Pure over storage: never reads the relay. Once this device has had any
 * synced revision of a type, its local field is never a launch source again.
 * A transport failure never changes a stored state, so a confirmed `present`
 * head keeps serving while the relay is unreachable (offline rule, §4.4);
 * `invalid`, `deleted` and lost access block. */
export declare function resolveStart<C extends object>(input: StartInput<C>): Start<C>;
