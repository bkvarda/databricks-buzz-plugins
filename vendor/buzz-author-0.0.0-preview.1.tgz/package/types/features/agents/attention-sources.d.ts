import type { ComponentType } from "react";
import type { DefinedIcon } from "../../shared/design-system/icons";
import type { HostProcess, HostProcessOptions } from "../host/service";
import type { Agent } from "./service";
import type { AttentionObject, SourceWatch } from "./attention";
/** How Agent Attention shows a provider's watch, in place of its name. */
export type SourcePresentation = Readonly<{
    /** The kind of watch, such as "GitHub PR". */
    type: string;
    icon?: DefinedIcon;
    /** What it watches, shown beside its kind, with `subtitle` after it. */
    target?: string;
    subtitle?: string;
    /** Opens what it watches. */
    link?: Readonly<{
        href: string;
        title: string;
    }>;
    /** Replaces the name in its details. */
    details?: ComponentType;
}>;
export type AttentionSource = Readonly<{
    id: string;
    /** Discovery metadata for tools that configure this provider. */
    description?: string;
    configExample?: Readonly<Record<string, unknown>>;
    /** `title` is the watch's display name. */
    present?(watch: SourceWatch, title: string): SourcePresentation;
    run(input: Readonly<{
        /** Stable Attention object slug, unique within the agent. */
        id: string;
        /** The agent's membership key, as `Agents.wake` takes. */
        agent: string;
        watch: SourceWatch;
        signal: AbortSignal;
        /** Runs a declared process as this watch's agent and destination.
         * On macOS and Linux, only one instance of each declared process may run
         * per agent, provider and watch, including across Buzz builds. A concurrent
         * instance waits for its predecessor to stop. Await `process.exited` before respawning.
         * Buzz revokes access when this run returns, throws or is cancelled. */
        spawn(process: string, options: Omit<HostProcessOptions, "mcp">): Promise<HostProcess>;
        /** Empty output wakes nothing. Throws when delivery cannot be queued. */
        emit(text: string): void;
    }>): Promise<void>;
}>;
/** Host registration after binding the plugin's command capability. */
export type AttentionProducer = Omit<AttentionSource, "run"> & {
    run(input: Omit<Parameters<AttentionSource["run"]>[0], "spawn">): Promise<void>;
};
type SourceObject = AttentionObject & {
    value: SourceWatch;
};
export declare class AttentionSources {
    private host;
    private tails;
    private runs;
    constructor(host: {
        emit(agent: string, object: SourceObject, text: string, current: () => boolean): void;
        completed(agent: string, object: SourceObject): boolean;
        finish(agent: string, object: SourceObject): Promise<void>;
    }, tails?: Map<string, Promise<void>>);
    reconcile(provider: string, source: AttentionProducer, agents: readonly Agent[]): void;
    stop(): void;
}
export {};
