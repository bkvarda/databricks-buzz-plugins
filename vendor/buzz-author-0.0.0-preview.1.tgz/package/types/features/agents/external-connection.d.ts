import type { McpAuthorization } from "../host/service";
import type { AgentKey } from "./membership";
import type { Agents } from "./service";
export declare function externalMcpEnabled(community: string | null): any;
export type ExternalScope = "read" | "post";
export type ExternalAuthorization = McpAuthorization & Readonly<{
    version: 1;
    client: string;
    scope: readonly ExternalScope[];
    code_challenge_method: "S256";
}>;
export declare function parseExternalAuthorization(raw: string): ExternalAuthorization | null;
type Pending = Readonly<{
    request: ExternalAuthorization;
    viewer: string;
    expires: number;
}>;
type Grant = Readonly<{
    client: string;
    agent: AgentKey;
    phase: "starting" | "waiting" | "connected" | "ended";
}>;
type Host = {
    connect: Agents["connectExternal"];
    deny(request: McpAuthorization): Promise<void>;
};
/** The app owns consent; the bundled Agents plugin owns the native MCP permission. */
export declare function createExternalApps(): {
    snapshot: () => Readonly<{
        pending?: Pending | undefined;
        grant?: Grant | undefined;
        available: boolean;
        error?: string | undefined;
    }>;
    subscribe(listener: () => void): () => void;
    bind(next: Host): () => void;
    open(request: ExternalAuthorization, viewer: string): void;
    deny: () => Promise<void>;
    revoke: () => Promise<void>;
    clearError(): void;
    approve(agent: AgentKey): Promise<void>;
};
export type ExternalApps = ReturnType<typeof createExternalApps>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        externalApps: ExternalApps;
    }
}
export {};
