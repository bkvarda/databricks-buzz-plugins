import type { McpAuthorization, McpPairing } from "../host/service";
import type { AgentKey } from "./membership";
import type { Agents } from "./service";
export declare function externalMcpEnabled(community: string | null): any;
/** `agent` is full access as the selected agent. The narrow scopes belong to
 * older approvals and links: they parse, but grant no tools. */
export type ExternalScope = "read" | "post" | "create" | "agent";
export declare const fullAgentAccess: (scopes: readonly ExternalScope[]) => boolean;
export declare const legacyRequest = "This app asks for limited access, which Buzz no longer grants. Update the app, then start setup again.";
export type ExternalAuthorization = McpAuthorization & Readonly<{
    version: 1 | 2;
    client: string;
    scope: readonly ExternalScope[];
    code_challenge_method: "S256";
    resume?: Readonly<{
        id: string;
        counter: number;
        proof: string;
    }>;
}>;
export declare function parseExternalAuthorization(raw: string): ExternalAuthorization | null;
type Pending = Readonly<{
    request: ExternalAuthorization;
    viewer: string;
    expires: number;
}>;
type Grant = Readonly<{
    client: string;
    agent: AgentKey;
    phase: "starting" | "waiting" | "connected" | "ended";
}>;
type Host = {
    connect: Agents["connectExternal"];
    deny(request: McpAuthorization): Promise<void>;
    pairing?(operation: "get" | "resume" | "revoke", request?: McpAuthorization): Promise<McpPairing | null>;
};
/** The app owns consent; the bundled Agents plugin owns the native MCP permission. */
export declare function createExternalApps(): {
    snapshot: () => Readonly<{
        pending?: Pending | undefined;
        grant?: Grant | undefined;
        available: boolean;
        error?: string | undefined;
        pairing?: McpPairing | undefined;
    }>;
    subscribe(listener: () => void): () => void;
    bind(next: Host): () => void;
    open(request: ExternalAuthorization, viewer: string): void;
    deny: () => Promise<void>;
    revoke: () => Promise<void>;
    clearError(): void;
    approve(agent: AgentKey): Promise<void>;
};
export type ExternalApps = ReturnType<typeof createExternalApps>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        externalApps: ExternalApps;
    }
}
export {};
