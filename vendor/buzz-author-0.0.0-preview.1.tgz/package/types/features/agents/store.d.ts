import { type AttentionObject, type AttentionValue, type TimerState } from "./attention";
import { type AgentKey } from "./membership";
/** Agent state as every program that runs this machine's agents shares it.
 * Reads are synchronous, from this program's copy. Each write changes the
 * copy at once and returns a promise that settles once the write is saved.
 * It rejects when the write was not saved, and the copy then holds the saved
 * value again. A caller that must know a value is saved awaits the write. */
export type AgentStore = Readonly<{
    keys(): readonly string[];
    get(key: string): string | null;
    /** Saves `value` under `key`; null removes the key. */
    set(key: string, value: string | null): Promise<void>;
    /** Saves `value` only if no program saved a value under `key`. Resolves
     * with the value then kept: `value`, or what another program saved first. */
    add(key: string, value: string): Promise<string>;
}>;
/** `storage` as agent storage. Its writes save as they are made, so each
 * settles at once, or rejects when `storage` refused it. */
export declare function localStore(storage?: Storage): AgentStore;
/** An object a reader cannot apply, kept as it was stored so it can be fixed. */
export type SkippedObject = Readonly<{
    slug: string;
    value: unknown;
    modifiedAt: number;
    problem: string;
}>;
/** One event a watch woke its agent for, or one output of a source. */
export type AttentionEntry = Readonly<{
    /** The woken event's id, so it can show as that message. */
    id?: string | undefined;
    at: number;
    text: string;
    author?: string | undefined;
    channel?: string | undefined;
    /** Pubkeys its signed `p` tags name. */
    mentions?: readonly string[] | undefined;
    /** Pubkeys its signed two-field `mention` tags name. */
    mentionReferences?: readonly string[] | undefined;
}>;
export type AttentionHistory = Readonly<{
    lastWokeAt?: number;
    /** What a watch saved before it kept `events`. */
    output?: string;
    events?: readonly AttentionEntry[];
}>;
/** The latest valid `entries` a watch's history keeps, each clipped. */
export declare const recentEntries: (entries: readonly unknown[]) => Readonly<{
    /** The woken event's id, so it can show as that message. */
    id?: string | undefined;
    at: number;
    text: string;
    author?: string | undefined;
    channel?: string | undefined;
    /** Pubkeys its signed `p` tags name. */
    mentions?: readonly string[] | undefined;
    /** Pubkeys its signed two-field `mention` tags name. */
    mentionReferences?: readonly string[] | undefined;
}>[];
export type AgentRecord = Readonly<{
    /** Its membership's key (see `agentKey`): the agent's pubkey in its home
     * community. Saved as `pubkey`, which every record had before agents
     * joined more than one community. */
    pubkey: AgentKey;
    /** Keyed by slug (`interest/<id>` or `watch/<id>`). */
    attention: Readonly<Record<string, AttentionObject>>;
    /** Stored objects that are invalid or over a limit. They do nothing, and stay
     * stored until they are fixed or removed. */
    skipped?: Readonly<Record<string, SkippedObject>>;
    /** Plugin-owned config, shared by all its communities, so only the home
     * record keeps it. The host never reads it. */
    config: unknown;
    /** True when the owner turned attention on. Off, its watches and timers
     * stay stored but wake nothing, and the agent is not offered attention
     * tools. Absent means off, so an agent has no attention until its owner
     * turns it on. */
    attentionEnabled?: boolean;
    /** Run state of its timers, by slug. Not config, so it never leaves the device;
     * kept here so removing a timer or the agent removes its state with it. */
    timers?: Readonly<Record<string, TimerState>>;
    /** Terminal source runs, matched to the exact registration. */
    sourceRuns?: Readonly<Record<string, string>>;
    attentionHistory?: Readonly<Record<string, AttentionHistory>>;
}>;
/** Where records were kept, all in one value, before each had its own key. */
export declare const STORAGE_KEY = "buzz.agents.v1";
/** Each agent's record has its own key, so programs that run different
 * agents and share this storage never write over each other's records. */
export declare const RECORD_PREFIX = "buzz.agent.v1:";
export declare const recordKey: (key: AgentKey) => string;
/** Reads every record. An attention object a reader would not apply is skipped
 * and reported, never dropped. */
export declare function readRecords(storage: AgentStore): Record<string, AgentRecord>;
/** Moves records from the old value that held every agent into one key per
 * agent, then removes it. Only that move writes many records at once: after
 * it, each save writes only its own agent's key, so a program that runs
 * other agents from the same storage keeps its changes. */
export declare function splitLegacyRecords(storage: AgentStore, records: Readonly<Record<string, AgentRecord>>): Promise<void>;
/** Removes a membership's record. */
export declare function removeRecord(storage: AgentStore, key: AgentKey): Promise<void>;
/** Saves one record, when it changed. */
export declare function writeRecord(storage: AgentStore, record: AgentRecord): Promise<void>;
/** Replaces or deletes (`value: null`) one attention object, after validating it
 * and the count limits. A timer keeps its run state while its `armed_at` is
 * unchanged, as Janet's do: a new interval applies from its next run, and
 * enabling it again runs at most one overdue occurrence. A new `armed_at` (a
 * rearm) sets a new deadline, one interval after it, and keeps the occurrences
 * already used. Only a timer with no saved state counts what was already due.
 * `schedule` overrides that for a timer: `rearm` always sets the new deadline,
 * even at the same `armed_at`, and `restart` also gives it a fresh budget, as
 * the owner's "Run again" does. */
export declare function setAttention(record: AgentRecord, slug: string, value: AttentionValue | null, now?: number, schedule?: "rearm" | "restart"): AgentRecord;
/** What one timer pass saw and decided, by slug: `seen` is the run state it
 * read, absent when the timer had none, and `next` the state it keeps. */
export type TimerProgress = Readonly<Record<string, Readonly<{
    seen?: TimerState | undefined;
    next: TimerState;
}>>>;
/** `record` with a timer pass's progress, or undefined when that changes
 * nothing. A timer whose state is still what the pass saw takes the pass's
 * state. One whose state changed since, as a rearm or restart changes it,
 * keeps its new deadline, and the occurrences the pass used are added to it:
 * they ran, so they count. A timer that is gone takes nothing. */
export declare function withProgress(record: AgentRecord, progress: TimerProgress): AgentRecord | undefined;
/** A group of the owner's agents and the text its members share. Membership
 * lives only here: an agent records nothing about its teams. */
export type Team = Readonly<{
    id: string;
    name: string;
    instructions: string;
    /** Agent pubkeys, in the order shown. */
    members: readonly string[];
    /** A synced team's confirmed head, the base its editor revises. */
    revision?: string;
}>;
export declare const TEAMS_KEY = "buzz.agents.teams.v1";
/** Reads every team, skipping any that is not one. */
export declare function readTeams(storage: AgentStore): readonly Team[];
export declare function writeTeams(storage: AgentStore, teams: readonly Team[]): Promise<void>;
/** A hosted agent its provider made whose setup has not finished. Kept so
 * Finish setup continues it instead of the provider making another. */
export type Unfinished = Readonly<{
    pubkey: string;
    /** The agent type's key, `pluginId/typeId`. */
    type: string;
    name: string;
    /** Its `wss://` community. */
    relay: string;
    owner: string;
    /** The HTTPS image URL it was made with, listed once it is set up. */
    picture?: string;
    /** Provider-owned creation settings, retained only until setup succeeds. */
    config?: unknown;
}>;
export declare const UNFINISHED_KEY = "buzz.agents.unfinished.v1";
/** Reads every unfinished setup, skipping any that is not one. */
export declare function readUnfinished(storage: AgentStore): readonly Unfinished[];
export declare function writeUnfinished(storage: AgentStore, agents: readonly Unfinished[]): Promise<void>;
/** Agent memberships, by key, imported or added to their community where its
 * archive state could not be checked, so their settings keep offering Retry
 * across restarts until a check confirms it. */
export declare const ARCHIVE_UNCHECKED_KEY = "buzz.agents.archive-unchecked.v1";
export declare function readArchiveUnchecked(storage: AgentStore): Set<string>;
export declare function writeArchiveUnchecked(storage: AgentStore, agents: ReadonlySet<string>): Promise<void>;
