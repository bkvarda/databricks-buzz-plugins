export declare const avatarPacks: {
    id: string;
    label: string;
    coverAvatarId: string;
    avatarIds: string[];
}[];
export declare const agentAvatars: {
    id: string;
    label: string;
    collectionId: string;
    url: string;
    sha256: string;
    animations: {
        webm: {
            url: string;
            sha256: string;
            byteSize: number;
        };
        hevc: {
            url: string;
            sha256: string;
            byteSize: number;
        };
    };
    preview: string | undefined;
}[];
/** The bundled copy of pack art, which can be read back from a canvas: the
 * CDN sends no CORS header. */
export declare const bundledPoster: (src: string) => string | undefined;
/** Animations stream from the catalog's CDN; the bundled poster covers offline use. */
export declare function avatarAnimation(id: string): {
    webm: string | undefined;
    hevc: string | undefined;
};
export declare function randomAgentAvatar(): {
    id: string;
    label: string;
    collectionId: string;
    url: string;
    sha256: string;
    animations: {
        webm: {
            url: string;
            sha256: string;
            byteSize: number;
        };
        hevc: {
            url: string;
            sha256: string;
            byteSize: number;
        };
    };
    preview: string | undefined;
};
