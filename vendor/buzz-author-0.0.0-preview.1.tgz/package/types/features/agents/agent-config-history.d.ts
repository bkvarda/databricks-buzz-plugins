import type { EventData, RelayEvent } from "../relay/events";
import { type SettingsSchema } from "./agent-config";
import { type Expected, type SnapshotRead } from "./agent-config-artifacts";
/** Revisions per page: well under the relay's 1,000 so each "Load older"
 * stays a short list. The offset ceiling is the relay's (`buzz-core`
 * artifact.rs `MAX_OFFSET`), so at most `HISTORY_LIMIT` revisions load. */
export declare const HISTORY_PAGE = 100;
export declare const HISTORY_MAX_OFFSET = 10000;
export declare const HISTORY_LIMIT: number;
export type History = Readonly<{
    /** Deduplicated revisions in the relay's order, newest accepted first. */
    revisions: readonly RelayEvent[];
    next: number;
    done: boolean;
    failed: boolean;
}>;
export declare const emptyHistory: History;
/** Reads the next page. Revisions accepted since the last page shift offsets,
 * so repeats are dropped by event ID. A failed page keeps what was loaded.
 * Every page names the channel in `#h`: the relay leaves system channels out
 * of any read that doesn't (NIP-CL), members included. */
export declare function loadOlder(read: SnapshotRead, channel: string, d: string, history: History, signal?: AbortSignal): Promise<History>;
/** Why a segment's predecessor is missing. */
export type Gap = "unloaded" | "capped" | "failed" | "unavailable";
export type Segment = Readonly<{
    /** Newest first; each revision's `prev` is the one after it. */
    revisions: readonly RelayEvent[];
    /** Set when the oldest revision names a predecessor that wasn't returned. */
    gap?: Gap;
}>;
/** Every chain segment in the loaded revisions, newest segment first. A
 * segment starts at a revision no loaded revision names as `prev`. */
export declare function segments(history: History): Segment[];
export type LineChange = Readonly<{
    type: "same" | "added" | "removed";
    text: string;
}>;
/** Line diff by longest common subsequence after trimming the shared ends. */
export declare function lineDiff(before: string, after: string): LineChange[];
export type FieldChange = Readonly<{
    field: string;
    before?: unknown;
    after?: unknown;
}>;
/** Settings fields that differ between two `buzz.agent.settings` revisions. */
export declare function settingsDiff(before: string, after: string): FieldChange[];
/** The agent type and plugin schema a settings revision must fit to start. */
export type SettingsCheck = Readonly<{
    agentType: string;
    schema: SettingsSchema;
}>;
/** Why a revision isn't config this client could start, or undefined. A
 * settings revision without a schema to check it against is never valid. */
export declare function revisionProblem(expected: Expected, event: EventData, settings?: SettingsCheck): string | undefined;
/** Revert: a new revision whose content is `target`'s snapshot and whose
 * `prev` is the current head: `op=update`, or `op=restore` over a deleted
 * head. A team keeps its current name. Never redacts. Only a valid snapshot
 * is republished (NIP-AP); an invalid or deleted head is what a revert
 * repairs, so its name, title and client tags are kept only when the head
 * itself is valid. */
export declare function revertTemplate(expected: Expected, head: RelayEvent, target: RelayEvent, settings?: SettingsCheck): {
    kind: number;
    created_at: number;
    content: string;
    tags: string[][];
};
