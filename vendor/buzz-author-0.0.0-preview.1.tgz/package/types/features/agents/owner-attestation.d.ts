import type { ProfileQueries } from "../relay/profile-directory";
import { type EventData } from "../relay/events";
import type { AgentReads } from "./reads";
/** NIP-OA owner of a signature-verified event, or undefined. Provenance only:
 * the event stays authored by `event.pubkey`; the owner is never an author. */
export declare function attestedOwner(event: Pick<EventData, "pubkey" | "kind" | "created_at"> & Readonly<{
    tags: readonly (readonly string[])[];
}>): Promise<string | undefined>;
/** NIP-IA ownership: exact tag shape, clause syntax, target binding and signature.
 * Clauses are not evaluated here; archive requests check time bounds separately. */
export declare function authTagOwner(target: string, tag: readonly string[]): Promise<string | undefined>;
/** NIP-IA request bounds: only created_at clauses apply to the request time. */
export declare function withinTimeBounds(conditions: string, createdAt: number): boolean;
/** Whether this build keeps workflow messages from authorizing local agent
 * requests in `community`. The build flag lists exact canonical origins; with
 * any listed, an unknown or unreadable community is restricted too. */
export declare function workflowRequestsRestricted(community: string | undefined): any;
/** How a mention from a relay workflow is checked: the agent's community, the
 * community's workflow key, and its creators' profiles. */
export type WorkflowCheck = {
    community?: string | undefined;
    authority: string | undefined;
    agent: string;
    profiles?: Pick<ProfileQueries, "ensure" | "event"> | undefined;
};
/** The workflow check of an agent's community reads, if they can be read. */
export declare function workflowOf(reads: AgentReads | undefined, agent: string): WorkflowCheck;
/** Owner prompts, attested siblings, and verified relay workflow mentions
 * delegated by the owner or a profile-verified sibling to this particular agent.
 * Where the build restricts workflow requests, no workflow-marked message
 * authorizes one: its rendered text is not bound to the owner's template. */
export declare function fromOwner(event: EventData, owner: string, workflow?: WorkflowCheck): Promise<boolean>;
