import { type TranscriptTurn } from "./activity-transcript";
import type { AgentKey } from "./membership";
import type { AgentStore } from "./store";
/** One piece of what Buzz sent, labeled by where it came from. */
export type PromptPart = Readonly<{
    label: string;
    text: string;
}>;
export declare const PROMPTS_PREFIX = "buzz.session-prompts.v1:";
/** Each agent's value is kept under this many UTF-8 bytes, the oldest
 * sessions dropped first. Agent storage takes 4 MiB a value, and the app
 * reads all of it at startup. */
export declare const PROMPTS_BUDGET = 1000000;
/** When a session started, the title it was given, and the conversation it
 * started for: its key, or null for one started outside any, such as a
 * watch's or timer's turn. Starts saved before that was kept have none. */
export type SessionStart = Readonly<{
    at: number;
    title: string;
    conversation?: string | null;
}>;
/** Removes a membership's saved prompts, of every agent type. */
export declare function removeSessionPrompts(storage: AgentStore, agent: AgentKey): Promise<void>;
/** The saved prompts of one agent's sessions of one agent type. */
export declare function sessionPrompts(storage: AgentStore, type: string, agent: AgentKey): {
    get: (session: string) => readonly Readonly<{
        label: string;
        text: string;
    }>[] | null | undefined;
    /** The sessions kept, oldest first, with how each started when that was
     * kept. */
    sessions: () => {
        at?: number;
        title?: string;
        conversation?: string | null;
        id: string;
    }[];
    /** Keeps what a new session was sent, unless one is kept for it already:
     * the first save wins. Only a runtime's new-session path calls this, so a
     * resumed or dropped session is never filled in. A failed save is
     * logged, never thrown, so the agent keeps working. */
    save(session: string, parts: readonly PromptPart[], start?: SessionStart): Promise<void>;
    /** `turns` with each shown session's saved prompt at its top. */
    shown: (turns: readonly TranscriptTurn[]) => TranscriptTurn[];
};
/** The label of a piece sent with each turn rather than once; a session
 * keeps its first turn's copy. */
export declare const EACH_TURN = "each-turn";
/** `turns`, already cut to the shown window, with each session's prompt at
 * the top of its first shown turn. A session whose start is not shown is
 * marked continued; whether a turn starts a session never depends on whether
 * its prompt was kept. */
export declare function withSessionPrompts(turns: readonly TranscriptTurn[], prompt: (session: string) => readonly PromptPart[] | null | undefined): TranscriptTurn[];
