import type { Memories } from "../../buzz-mcp/client";
import type { EventData, ReadFilter, RelayEvent } from "../relay/events";
import type { RelayData } from "../relay/service";
import type { ChannelLabel } from "../channels/channel-icon";
/** The agent's memory entries, deleted entries' tombstones, and whether
 * some may be missing. */
export type MemoryListing = Memories;
/** What a turn needs to know of its channel. */
export type ChannelFacts = Readonly<{
    name?: string;
    dm: boolean;
    members: readonly string[];
    /** The owner's device is still creating it, so it has nothing to read yet. */
    starting?: true;
}>;
export type AgentReads = Readonly<{
    /** The connection these reads go through. A new one, even to the same
     * community, may read as someone else, so nothing read through an old one
     * carries over. */
    connection: object;
    /** The community these reads are of; it changes when the agent's does. */
    scope: string;
    /** The channel as the community lists it, or undefined when unknown. */
    channel(id: string): Promise<ChannelFacts | undefined>;
    read(filters: readonly ReadFilter[], signal: AbortSignal): Promise<readonly EventData[]>;
    /** Asks for these people's profiles, so `name` can name them. */
    profiles(pubkeys: readonly string[]): Promise<void>;
    /** A person's name, as the channel with these members shows it when
     * given; if known yet. */
    name(pubkey: string, members?: readonly string[]): string | undefined;
    /** A person's signature-verified profile event, once `profiles` read it. */
    profile(pubkey: string): RelayEvent | undefined;
    /** The community's name and kind for a channel, if it lists the channel now. */
    channelLabel(id: string): ChannelLabel | undefined;
    /** Tells `listener` when the community's channel list changes, so
     * `channelLabel` may answer differently. */
    subscribeChannels(listener: () => void): () => void;
    /** The key the community signs workflow messages with, if known. */
    workflowAuthority(): string | undefined;
    /** The connected relay signing its channel metadata. */
    relayAuthor?(): string | undefined;
    /** The agent's memory, or only entry `slug` when given; `partial` when the
     * entries may be incomplete. `signal` stops the read. */
    memoryListing(signal: AbortSignal, slug?: string): Promise<MemoryListing>;
    /** The channel's current Canvas text when `owner`, or an agent they
     * attest, wrote it; undefined when it has none, someone else wrote it, or
     * the reader cannot read Canvas. */
    canvas?(channelId: string, owner: string): Promise<string | undefined>;
    /** Whether a mention in this channel continues `owner`'s Solo chat. Only the
     * owner's own connection can tell; other readers answer false. */
    soloChat(owner: string, channelId: string, signal: AbortSignal): Promise<boolean>;
}>;
/** The reads of the owner's connection to the agent's community, while it is
 * ready; undefined otherwise. Memory is encrypted to the owner, so the owner's
 * session reads it without the agent's key. */
export declare function ownerReads(relay: RelayData | undefined, pubkey: string): AgentReads | undefined;
