/** A display-only projection of the local and owner-authored relay inventory, not proof of
 * ownership, membership, custody or running state. No prompts/configuration. */
export type AgentLibrary = Readonly<{
    definitions: readonly Readonly<{
        id: string;
        name: string;
        avatar?: string;
    }>[];
    identities: readonly Readonly<{
        pubkey: string;
        name: string;
        avatar?: string;
        definitionId?: string;
    }>[];
}>;
export type AgentLibraryReader = (signal: AbortSignal) => Promise<AgentLibrary>;
export type AgentLibrarySnapshot = AgentLibrary & Readonly<{
    status: "unavailable" | "idle" | "loading" | "ready" | "error";
    error?: string;
}>;
/** One artwork rule for every agent surface: an identity without its own art
 * shows its linked definition's art. Applied once where the snapshot is made. */
export declare function inheritDefinitionAvatars<T extends AgentLibrary>(library: T): T;
export declare function createAgentLibrary(read: AgentLibraryReader | undefined, notify?: (listener: () => void) => void): {
    queries: Readonly<{
        snapshot: () => AgentLibrarySnapshot;
        refresh: ({ fresh }?: {
            fresh?: boolean | undefined;
        }) => Promise<void>;
        retain({ refresh: refreshOnRetain }?: {
            refresh?: boolean | undefined;
        }): () => void;
        subscribe(listener: () => void): () => void;
    }>;
    clear: () => void;
    reconnect(): void;
    dispose(): void;
};
