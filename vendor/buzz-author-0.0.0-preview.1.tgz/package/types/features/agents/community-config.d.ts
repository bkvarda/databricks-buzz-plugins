import type { RelayEvent } from "../relay/events";
import type { RelaySession } from "../relay/session";
import { type AgentConfigStore, type SettingsSchema, type Subject } from "./agent-config";
import { type ArtifactType, type artifactTemplate, type SnapshotRead } from "./agent-config-artifacts";
import type { Mode } from "./agent-start";
import { type ConfigChannels } from "./config-channels";
import { type ConfigFeed, type ConfigSync } from "./config-sync";
import { type ConfigWriter, type Saved } from "./config-writes";
import { type SyncedTeams } from "./team-config";
import { type TeamEdit } from "./team-ops";
/** One agent this device runs. Hosted agents never get a config channel. */
export type ConfigAgent = Readonly<{
    pubkey: string;
    name: string;
    type: string;
    config: object;
    /** The type's synced settings allowlist; without it settings stay local. */
    schema?: SettingsSchema | undefined;
}>;
export type Side = "settings" | "instructions";
export declare const SIDES: readonly Side[];
export declare const SIDE_TYPE: Record<Side, ArtifactType>;
/** The fields a side publishes from a config. Settings this client doesn't
 * know stay as the head had them (NIP-AP "Editing"). */
export declare function fields(side: Side, agent: ConfigAgent, config: object, head?: RelayEvent): Record<string, unknown>;
/** Whether saving `config` would change the side's head. */
export declare function changes(side: Side, agent: ConfigAgent, config: object, head?: RelayEvent): boolean;
export type AgentBinding = Partial<Record<Side, Readonly<{
    mode: Mode;
    subject: Subject;
}>>>;
/** The head id each synced side's editor opened; `null`: it opened none. */
export type ConfigBase = Partial<Record<Side, string | null>>;
export type CommunityConfigInput = Readonly<{
    session: RelaySession;
    owner: string;
    community: string;
    store: AgentConfigStore;
    /** The synced teams discovery found, kept on this device. */
    teams: SyncedTeams;
    /** The relay's NIP-11 document. */
    info(signal: AbortSignal): Promise<unknown>;
    /** Reports each binding change, so starts and the UI re-resolve. */
    changed(): void;
    /** Reports a history change, which may leave every head as it was. */
    historyChanged(): void;
}>;
/** Config sync's view of a relay session. */
export declare function sessionFeed(session: RelaySession, read: ConfigFeed["read"], relayAuthor: string): ConfigFeed;
/** Null when this session can't hold config sync or the relay lacks
 * support: then config stays local and no channel is created. */
export declare function communityConfig(input: CommunityConfigInput, signal: AbortSignal): Promise<{
    /** Binds each agent not yet bound; reconnects bind every agent again. */
    attach(list: readonly ConfigAgent[]): Promise<(void | undefined)[]>;
    binding: (pubkey: string) => Partial<Record<Side, Readonly<{
        mode: Mode;
        subject: Subject;
    }>>> | undefined;
    /** Runs `work` once the agent's attach in flight settles; an attach
     * started meanwhile begins after it. */
    exclusive<T>(pubkey: string, work: () => Promise<T>): Promise<T>;
    /** Discovery saw an agent config channel sync doesn't hold, or a bound
     * one archived: that agent's channel is selected and bound again. */
    discovered(metadata: RelayEvent): void;
    /** Each connection selects and binds every agent's channel again. */
    reconnected(): Promise<void>;
    /** A bound team channel's members changed. */
    rosterChanged(channel: string): void;
    /** Creates, edits or imports a team here, its home, online, then shows
     * what the relay has. */
    saveTeam(edit: TeamEdit): Promise<Readonly<{
        ok: boolean;
        added: readonly string[];
        removed: readonly string[];
        skipped: readonly string[];
        failed?: string;
        error?: string;
        uncertain?: boolean;
        created?: true;
        conflict?: true;
        refused?: true;
    }>>;
    /** Deletes a team by archiving its config channel, online. */
    removeTeam(id: string): Promise<void>;
    historyChanged(channel: string, d: string): void;
    /** Each synced side's artifact, for History. */
    history(pubkey: string): {
        side: Side;
        expected: Readonly<{
            channel: string;
            type: ArtifactType;
            d: string;
            team?: string;
        }>;
        head: import("nostr-tools").VerifiedEvent | undefined;
        version: number;
    }[];
    /** The team's synced instructions, for History; undefined while it
     * isn't a listed team here. */
    teamHistory(id: string): {
        side: "instructions";
        expected: Readonly<{
            channel: string;
            type: ArtifactType;
            d: string;
            team?: string;
        }>;
        head: import("nostr-tools").VerifiedEvent | undefined;
        version: number;
    } | undefined;
    /** Saves a team History revert, online, then shows what the relay has. */
    reviseTeam(id: string, template: ReturnType<typeof artifactTemplate>): Promise<Saved>;
    /** Reads history pages from the config channel. */
    read: SnapshotRead;
    /** Saves a History revert or restore of `side`, on the head its `prev`
     * names. */
    revise(pubkey: string, side: Side, template: ReturnType<typeof artifactTemplate>): Promise<Saved>;
    /** Saves each synced side the edit changed, as the next revision of the
     * head its editor opened. Sides are independent: one can save while the
     * other fails, and each reports its own result. */
    save(agent: ConfigAgent, config: object, base: ConfigBase): Promise<Partial<Record<Side, Saved>>>;
    /** Another device's agent's synced instructions, read without creating
     * or binding anything; undefined when there are none to read. */
    readInstructions(pubkey: string): Promise<{
        instructions: string;
        revision: string;
    } | undefined>;
    /** Archives the agent's config channel as its Delete's last relay step
     * (NIP-AP "Deleting an agent"). Online only: a failure throws, and the
     * Delete stays unfinished until run again. */
    remove(pubkey: string, signal: AbortSignal): Promise<void>;
    dispose(): void;
} | null>;
/** Per-agent config channels over one community's sync and writer. */
export declare function agentConfigs(input: Readonly<{
    channels: Pick<ConfigChannels, "ensure" | "addMember" | "removeMember" | "find" | "archive" | "archived" | "teams" | "owns">;
    sync: Pick<ConfigSync, "bind" | "unbind" | "dispose">;
    writer: ConfigWriter;
    read: SnapshotRead;
    store: AgentConfigStore;
    teams: SyncedTeams;
    online(): boolean;
    owner: string;
    community: string;
    signal: AbortSignal;
    changed(): void;
    historyChanged?(): void;
    dispose?(): void;
}>): {
    /** Binds each agent not yet bound; reconnects bind every agent again. */
    attach(list: readonly ConfigAgent[]): Promise<(void | undefined)[]>;
    binding: (pubkey: string) => Partial<Record<Side, Readonly<{
        mode: Mode;
        subject: Subject;
    }>>> | undefined;
    /** Runs `work` once the agent's attach in flight settles; an attach
     * started meanwhile begins after it. */
    exclusive<T>(pubkey: string, work: () => Promise<T>): Promise<T>;
    /** Discovery saw an agent config channel sync doesn't hold, or a bound
     * one archived: that agent's channel is selected and bound again. */
    discovered(metadata: RelayEvent): void;
    /** Each connection selects and binds every agent's channel again. */
    reconnected(): Promise<void>;
    /** A bound team channel's members changed. */
    rosterChanged(channel: string): void;
    /** Creates, edits or imports a team here, its home, online, then shows
     * what the relay has. */
    saveTeam(edit: TeamEdit): Promise<Readonly<{
        ok: boolean;
        added: readonly string[];
        removed: readonly string[];
        skipped: readonly string[];
        failed?: string;
        error?: string;
        uncertain?: boolean;
        created?: true;
        conflict?: true;
        refused?: true;
    }>>;
    /** Deletes a team by archiving its config channel, online. */
    removeTeam(id: string): Promise<void>;
    historyChanged(channel: string, d: string): void;
    /** Each synced side's artifact, for History. */
    history(pubkey: string): {
        side: Side;
        expected: Readonly<{
            channel: string;
            type: ArtifactType;
            d: string;
            team?: string;
        }>;
        head: import("nostr-tools").VerifiedEvent | undefined;
        version: number;
    }[];
    /** The team's synced instructions, for History; undefined while it
     * isn't a listed team here. */
    teamHistory(id: string): {
        side: "instructions";
        expected: Readonly<{
            channel: string;
            type: ArtifactType;
            d: string;
            team?: string;
        }>;
        head: import("nostr-tools").VerifiedEvent | undefined;
        version: number;
    } | undefined;
    /** Saves a team History revert, online, then shows what the relay has. */
    reviseTeam(id: string, template: ReturnType<typeof artifactTemplate>): Promise<Saved>;
    /** Reads history pages from the config channel. */
    read: SnapshotRead;
    /** Saves a History revert or restore of `side`, on the head its `prev`
     * names. */
    revise(pubkey: string, side: Side, template: ReturnType<typeof artifactTemplate>): Promise<Saved>;
    /** Saves each synced side the edit changed, as the next revision of the
     * head its editor opened. Sides are independent: one can save while the
     * other fails, and each reports its own result. */
    save(agent: ConfigAgent, config: object, base: ConfigBase): Promise<Partial<Record<Side, Saved>>>;
    /** Another device's agent's synced instructions, read without creating
     * or binding anything; undefined when there are none to read. */
    readInstructions(pubkey: string): Promise<{
        instructions: string;
        revision: string;
    } | undefined>;
    /** Archives the agent's config channel as its Delete's last relay step
     * (NIP-AP "Deleting an agent"). Online only: a failure throws, and the
     * Delete stays unfinished until run again. */
    remove(pubkey: string, signal: AbortSignal): Promise<void>;
    dispose(): void;
};
export type CommunityConfig = ReturnType<typeof agentConfigs>;
