import type { WorkStop } from "./work-stop";
/** Hosted stops remain pending until evidence ends or the retry window expires. */
export declare function useWorkStops(controls: readonly WorkStop[]): {
    pending: ReadonlySet<string>;
    stop: (control: WorkStop, name: string) => Promise<void>;
};
