import { type AttentionValue, type EventWatch, type Interest, type TimerWatch, type SourceWatch } from "./attention";
import { type AgentRecord } from "./store";
export declare const ABSENT = "object-v1:absent";
/** The most stored attention an agent can write for itself, so that one agent
 * cannot fill the device storage that every agent's settings share. */
export declare const AGENT_BYTES: number;
/** The shortest interval an agent can give a timer. Each run is a new Claude
 * turn, so a faster timer only queues turns it cannot run. */
export declare const MIN_INTERVAL_SECS = 60;
export type ClassifierAvailability = "available" | "unavailable";
/** enabled/disabled for event watches; armed/inactive/spent for timers. */
export type WatchStatus = "enabled" | "disabled" | "armed" | "inactive" | "spent" | "completed";
export type AttentionErrorCode = "conflict" | "wrong-scope" | "invalid-operation" | "not-found" | "invalid";
/** A refused attention write; its message starts with the code, as Janet's. */
export declare class AttentionError extends Error {
    readonly code: AttentionErrorCode;
    constructor(code: AttentionErrorCode, detail: string);
}
export type InterestObject = Interest & Readonly<{
    id: string;
}>;
export type EventWatchObject = EventWatch & Readonly<{
    id: string;
    status: "enabled" | "disabled";
}>;
/** A timer with its schedule: occurrences `used`, and when the next is due. */
export type TimerObject = TimerWatch & Readonly<{
    id: string;
    status: "armed" | "inactive" | "spent";
    used: number;
    next_due: number;
}>;
export type ShownObject = InterestObject | EventWatchObject | TimerObject | (SourceWatch & Readonly<{
    id: string;
    status: "enabled" | "disabled" | "completed";
}>);
export type Shown = Readonly<{
    delivery?: Readonly<{
        status: "held" | "blocked";
        reason: string;
    }>;
    result: "found" | "not-found";
    object: ShownObject | null;
    expected_state: string;
}>;
export type WatchSummary = Readonly<{
    id: string;
    interest_id: string;
    name?: string;
    type: "event" | "timer" | "source";
    status: WatchStatus;
    /** Whether the watch has a classifier. */
    classified?: true;
}>;
export type WatchFilter = Readonly<{
    interest?: string;
    type?: "event" | "timer" | "source";
    status?: WatchStatus;
    /** Case-sensitive, over ids and names. */
    search?: string;
}>;
/** The object at `slug` as a show presents it, or null. */
export declare function objectAt(record: AgentRecord, slug: string, now: number): ShownObject | null;
/** `object-v1:` and the SHA-256 of the canonical object, or ABSENT. */
export declare function token(object: ShownObject | null): Promise<string>;
export declare function show(record: AgentRecord, slug: string, now: number, interest?: string): Promise<Shown>;
/** Interest ids, in order; `search` is case-sensitive. */
export declare function interestIds(record: AgentRecord, search?: string): string[];
export declare function watchSummaries(record: AgentRecord, filter: WatchFilter, now: number): WatchSummary[];
export type WriteOptions = Readonly<{
    /** The token from the latest show of this object; ABSENT to create. */
    expected: string;
    /** The Interest the caller works for. A watch of another, or another
     * Interest, is `wrong-scope`. */
    interest?: string;
    /** A timer rearm: its deadline is set from `armed_at` even when that is
     * unchanged, keeping the occurrences used. */
    rearm?: boolean;
}>;
/** The record after one checked write: replaces (or with `null` removes) the
 * object at `slug`. Throws an AttentionError when the write is refused. */
export declare function checkedWrite(record: AgentRecord, slug: string, value: AttentionValue | null, { expected, interest, rearm }: WriteOptions, now: number): Promise<AgentRecord>;
