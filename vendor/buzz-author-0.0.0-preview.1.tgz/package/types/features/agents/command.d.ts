import type { HostMcpServer, HostProcess, HostProcessOptions } from "../host/service";
/** Composes existing connection and process owners; no separate command registry. */
export declare function spawnAgentCommand(host: {
    connect(signal: AbortSignal): Promise<HostMcpServer>;
    spawn(options: HostProcessOptions): Promise<HostProcess>;
    check(): void;
    subscribe(changed: () => void): () => void;
}, { signal, channel: _channel, root: _root, ...options }: Omit<HostProcessOptions, "mcp"> & {
    signal: AbortSignal;
    channel?: string | undefined;
    root?: string | undefined;
}): Promise<HostProcess>;
