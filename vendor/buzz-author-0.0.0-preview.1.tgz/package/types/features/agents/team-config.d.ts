import { readHead } from "./agent-config-artifacts";
import type { Subject } from "./agent-config";
import type { TeamSource } from "./agent-start";
import type { ConfigChannels } from "./config-channels";
import type { ConfigSync } from "./config-sync";
import type { AgentStore } from "./store";
export declare const SYNCED_TEAMS_KEY = "buzz.agents.teams.synced.v1";
/** A team config channel as discovery last found it. `id` is proven by its
 * head; a channel whose team was never proven is `unproven`, and its members
 * wait to start. `members`: the channel's agents this owner attests to. */
export type SyncedTeam = Readonly<{
    id: string;
    channel: string;
    archived: boolean;
    unproven?: true;
    members: readonly string[];
}>;
/** The synced teams discovery last found, by owner and home community. */
export declare class SyncedTeams {
    private readonly storage;
    private known;
    constructor(storage: AgentStore);
    /** Every owner's teams with the community each calls home. */
    all(): {
        owner: string;
        community: string;
        team: Readonly<{
            id: string;
            channel: string;
            archived: boolean;
            unproven?: true;
            members: readonly string[];
        }>;
    }[];
    get: (owner: string, community: string) => readonly Readonly<{
        id: string;
        channel: string;
        archived: boolean;
        unproven?: true;
        members: readonly string[];
    }>[] | undefined;
    set(owner: string, community: string, teams: readonly SyncedTeam[]): void;
}
export declare const teamArtifact: (owner: string, community: string, team: Pick<SyncedTeam, "id" | "channel">) => Subject;
/** A team head's name and instructions, or undefined when it isn't one. */
export declare function teamBody(content: string): {
    name: string;
    instructions: string;
} | undefined;
/** The teams listing `pubkey`, as starts admit them, wherever it runs. */
export declare function teamSources(teams: SyncedTeams, owner: string, pubkey: string): TeamSource[];
/** Every team config channel of the owner's in this community, each bound
 * for sync unless archived. A head that can't be read keeps the id `known`
 * found for that channel; an unreadable roster or ownership proof keeps the
 * members it proved before (NIP-AP: unreadable is not deleted). */
export declare function discoverTeams(deps: Readonly<{
    channels: Pick<ConfigChannels, "teams" | "owns">;
    sync: Pick<ConfigSync, "bind">;
    read: Parameters<typeof readHead>[0];
    owner: string;
    signal: AbortSignal;
}>, known?: readonly SyncedTeam[]): Promise<SyncedTeam[]>;
