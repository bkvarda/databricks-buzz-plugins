import { type ArtifactSyncFilter, type ArtifactSyncView } from "../relay/artifact-sync";
import type { RelayEvent } from "../relay/events";
import { type SnapshotRead } from "./agent-config-artifacts";
import type { AgentConfigStore } from "./agent-config";
import type { ConfigFamily } from "./config-channels";
/** The app reader caps pages at 500 (`relay/reader.ts`), below the relay clamp. */
export declare const DISCOVERY_PAGE = 500;
export type ConfigFeed = Readonly<{
    read: SnapshotRead;
    relayAuthor: string;
    /** The session's NIP-AR sync. Throws when the session has no capacity. */
    sync(filter: ArtifactSyncFilter): ArtifactSyncView;
    /** Live revisions in `channels`, with their relay-signed metadata and
     * roster, for a relay or session without sync. `revoked` hears the ones an
     * accepted access change took away. */
    follow?(channels: readonly string[], listener: (events: readonly RelayEvent[]) => void, revoked: (channels: readonly string[]) => void): () => void;
    /** Called each time the connection comes up. */
    connected(listener: () => void): () => void;
}>;
/** One selected config channel and whose config it holds. */
export type ConfigBinding = Readonly<{
    family: ConfigFamily;
    /** The agent pubkey, or the team id. */
    subject: string;
    channel: string;
}>;
/** Why a binding's sync is not current. `stale`: last confirmed state is
 * kept and a retry is due; `denied`: the binding is retired. */
export type SyncProblem = Readonly<{
    channel: string;
    kind: "stale" | "denied";
    error?: string;
}>;
export declare function createConfigSync(store: AgentConfigStore, feed: ConfigFeed, owner: string, community: string, listeners?: Readonly<{
    /** A revision or removal changed what history shows for `d`. */
    history?(channel: string, d: string): void;
    /** Discovery saw a config channel this sync does not hold, or a bound one
     * archived; the caller reselects and rebinds. */
    discovery?(metadata: RelayEvent): void;
    /** A bound channel's members changed, with the owner still in it. */
    roster?(channel: string): void;
    /** A read or the sync could not confirm the binding. */
    problem?(problem: SyncProblem): void;
}>): {
    bind: (bindings: readonly ConfigBinding[]) => Promise<void>;
    /** Channel reselection or loss decided by the caller. */
    unbind(channel: string): void;
    dispose(): void;
};
export type ConfigSync = ReturnType<typeof createConfigSync>;
