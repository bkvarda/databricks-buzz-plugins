import type { WorkStep } from "./local-activity";
import type { LocalWorkState } from "./local-activity";
import type { RelaySession } from "../relay/session";
import { requestActivity, requestActivityState } from "./request-activity";
type Snapshot = ReturnType<RelaySession["agentActivity"]["snapshot"]>;
export type RequestWork = {
    agent: string;
    state: LocalWorkState | ReturnType<typeof requestActivityState>;
    reason: string | undefined;
    /** Latest live local step, such as a tool name. */
    step?: WorkStep;
    lifecycle: boolean;
    /** A settled error the owner dismissed on this device. */
    dismissed?: boolean;
    /** Its harness can stop the turn this local request is in. */
    stoppable?: boolean;
    /** This local request can be asked again once it fails. */
    retryable?: boolean;
    selected: ReturnType<typeof requestActivity>;
    turns: Snapshot["turns"];
    working: boolean;
};
/** Only explicit triggering IDs associate work with a message. Typing is not
 * message evidence, and a sibling request must never inherit the same bubble. */
export declare function requestWork(snapshot: Snapshot, channelId: string, messageId: string | readonly string[]): RequestWork[];
export {};
