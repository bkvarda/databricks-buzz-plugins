import type { AgentConfigStore } from "./agent-config";
import type { ConfigChannels } from "./config-channels";
import type { ConfigWriter } from "./config-writes";
export type TeamEdit = Readonly<{
    id: string;
    name: string;
    instructions: string;
    /** The owner's agents the team should have. */
    members: readonly string[];
    /** What the editor opened: its head and its members. Absent for a new
     * team, whose id was made before this call. */
    base?: Readonly<{
        head: string | null;
        members: readonly string[];
    }>;
    /** Import: an existing team's name and instructions are kept. */
    adopt?: boolean;
}>;
/** What the change did. `ok` only when the readback shows all of it. */
export type TeamResult = Readonly<{
    ok: boolean;
    added: readonly string[];
    removed: readonly string[];
    /** Member changes never attempted. */
    skipped: readonly string[];
    /** The member whose change stopped it. */
    failed?: string;
    /** Why it stopped, or what the readback shows instead. */
    error?: string;
    /** The last step was sent with no answer: it may have happened. */
    uncertain?: boolean;
}>;
export type TeamDeps = Readonly<{
    channels: Pick<ConfigChannels, "find" | "ensure" | "archive" | "archived" | "owns" | "addMember" | "removeMember">;
    writer: ConfigWriter;
    store: AgentConfigStore;
    owner: string;
    community: string;
    online(): boolean;
    signal: AbortSignal;
}>;
export declare function teamOps(deps: TeamDeps): {
    change: (edit: TeamEdit) => Promise<Readonly<{
        ok: boolean;
        added: readonly string[];
        removed: readonly string[];
        /** Member changes never attempted. */
        skipped: readonly string[];
        /** The member whose change stopped it. */
        failed?: string;
        /** Why it stopped, or what the readback shows instead. */
        error?: string;
        /** The last step was sent with no answer: it may have happened. */
        uncertain?: boolean;
    }>>;
    /** Deletes the team by archiving its config channel, once, then reads
     * the archive back (NIP-AP "Deleting a team"). */
    archive: (id: string) => Promise<string>;
};
export type TeamOps = ReturnType<typeof teamOps>;
