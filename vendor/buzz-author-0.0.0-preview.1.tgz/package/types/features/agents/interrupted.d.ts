import { type AgentKey } from "./membership";
import type { AgentStore } from "./store";
export declare const INTERRUPTED_PREFIX = "buzz.agents.interrupted.v1:";
/** By agent membership, each mention it was working on: its event id, and its channel
 * or "" without one. */
export type Interrupted = Readonly<Record<string, Readonly<Record<string, string>>>>;
export declare function readInterrupted(storage: AgentStore): Interrupted;
/** Saves a membership's turns in its own key. Settles once the write is
 * saved; rejects when storage refuses it. */
export declare function writeInterrupted(storage: AgentStore, agent: AgentKey, turns: Readonly<Record<string, string>>): Promise<void>;
