/** Budgets of the development broker's single memory query. */
export declare const MEMORY_EVENT_LIMIT = 256;
export declare const MEMORY_WIRE_BYTES: number;
export declare const MEMORY_TEXT_BYTES: number;
export interface MemoryEntry {
    slug: string;
    body: string;
    eventId: string;
    createdAt: number;
}
export interface MemoryListing {
    entries: readonly MemoryEntry[];
    /** Deleted entries' tombstones, which a write recreating one must follow. */
    deleted?: readonly Readonly<{
        slug: string;
        createdAt: number;
    }>[];
    partial: boolean;
}
/** Reads every entry, or only entry `slug` when given. */
export type MemoryReader = (agent: string, signal: AbortSignal, slug?: string) => Promise<MemoryListing>;
export type MemorySnapshot = Readonly<{
    status: "idle" | "blocked" | "loading" | "ready" | "error" | "denied" | "unavailable";
    listing?: MemoryListing;
}>;
export declare function memoryAgent(agent: unknown, viewer: string): agent is string;
/** NIP-AE address grammar, shared by host evidence and renderer DTO validation. */
export declare function memorySlug(slug: unknown): slug is string;
/** Bound bytes before parsing ciphertext or plaintext responses. */
export declare function memoryResponseText(response: Response): Promise<string>;
/** Validate the host DTO before retaining plaintext, including aggregate size. */
export declare function memoryListing(input: unknown): MemoryListing;
/** Each mounted consumer owns a view; session retirement revokes every view. */
export declare function createAgentMemories(source: MemoryReader | undefined, viewer: string, available: () => boolean, notify?: (listener: () => void) => void): {
    capability: Readonly<{
        open: (agent: string) => {
            snapshot: () => Readonly<{
                status: "idle" | "blocked" | "loading" | "ready" | "error" | "denied" | "unavailable";
                listing?: MemoryListing;
            }>;
            subscribe(listener: () => void): () => void;
            refresh(): Promise<void>;
            clear: () => void;
            dispose(): void;
        };
        read: (agent: string, signal: AbortSignal, slug?: string) => Promise<Readonly<{
            /** Deleted entries' tombstones, which a write recreating one must follow. */
            deleted?: readonly Readonly<{
                slug: string;
                createdAt: number;
            }>[];
            partial: boolean;
            entries: readonly MemoryEntry[];
        }>>;
    }>;
    clear(): void;
    dispose(): void;
};
