import type { OwnerAccess } from "../../buzz-mcp/client";
import type { RelaySession } from "../relay/session";
/** Whether this build lets agents read with their owner's access in
 * `community`: its exact canonical origin is in the build's list. */
export declare function ownerMcpEnabled(community: string | null | undefined): any;
export type OwnerSession = Pick<RelaySession, "relayAuthor" | "channels" | "readRemote" | "names" | "profiles" | "channelLifecycle" | "snapshotRead">;
/** The owner's live session for the agent's community, as the host binds it
 * now. `signal` aborts when that binding is replaced. */
export type OwnerBinding = Readonly<{
    viewer: string;
    origin: string;
    session: OwnerSession;
    signal: AbortSignal;
}>;
/** `agent`'s owner reads. `bind` answers the owner's current binding for the
 * agent's community, or undefined when it may not be used now. */
export declare function createOwnerAccess(agent: Readonly<{
    pubkey: string;
    owner: string;
}>, bind: () => OwnerBinding | undefined): OwnerAccess;
