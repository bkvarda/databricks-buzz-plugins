import type { LocalEvents } from "../relay/outbox";
import type { RelaySession } from "../relay/session";
type RemovalSession = Pick<RelaySession, "outbox" | "channels" | "channelWrites" | "archives">;
/** Remove a relay-only agent from this community: archive its identity when a
 * consent path exists, delete the owner's kind 30177 record, then try to
 * remove it from its channels. Archive and record deletion must succeed; a
 * refusal stops the later steps and Remove stays retryable. Channel removal is
 * best effort: its failure does not fail the removal. */
export declare function removeRelayAgent(session: RemovalSession, viewer: string, pubkey: string, signal: AbortSignal): Promise<void>;
/** The content and tags of a kind 30177 record as read. */
export type AgentRecordBody = Readonly<{
    content: Readonly<Record<string, unknown>>;
    tags: readonly (readonly string[])[];
}>;
/** The viewer's own kind 30177 record of an agent, as Agents writes it. */
export type AgentRecordEntry = Readonly<{
    pubkey: string;
    name: string;
    /** An HTTPS image URL. */
    picture?: string;
    /** The agent type's key, `pluginId/typeId`, as the `runtime` tag. */
    runtime: string;
    /** The record this replaces, whose other settings and tags it keeps. */
    prior?: AgentRecordBody | undefined;
}>;
/** Publishes the viewer's kind 30177 record of an agent, replacing any
 * before it, and resolves with what it wrote once the relay accepts it.
 * Another desktop applies the record whole to an agent it has with that key,
 * and its parser requires `parallelism` and `respond_to`, so the record keeps
 * every setting of the one it replaces and defaults those two
 * (docs/relay-queries.md, "Managed-agent registration"). */
export declare function publishAgentRecord(session: Pick<RelaySession, "outbox">, { pubkey, name, picture, runtime, prior }: AgentRecordEntry, signal: AbortSignal): Promise<AgentRecordBody>;
/** NIP-09 coordinate deletion of the viewer's own kind 30177 agent record. */
export declare function deleteAgentRecord(session: Pick<RelaySession, "outbox">, viewer: string, pubkey: string, signal: AbortSignal, fence?: AbortSignal): Promise<void>;
/** Base Buzz `removeAgentFromAllChannels` over the relay's rosters for this
 * agent plus the viewer's loaded channels, skipping archived ones. Resolves
 * only once a fresh relay read lists the agent in none of them; any refusal or
 * unknown outcome throws after every channel operation has settled. */
export declare function removeAgentFromChannels(session: Pick<RelaySession, "outbox" | "channels" | "channelWrites">, pubkey: string, signal: AbortSignal): Promise<void>;
/** Settles once the outbox reports the relay accepted `id`, or rejects with
 * its refusal. */
export declare function delivered(outbox: LocalEvents, id: string, signal: AbortSignal, failure: string): Promise<void>;
export {};
