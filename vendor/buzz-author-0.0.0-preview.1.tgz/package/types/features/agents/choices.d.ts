import type { LocalAgent, LocalAgents } from "./local";
import type { AgentLibrarySnapshot, createAgentLibrary } from "./library";
import type { ChannelList } from "../relay/contracts";
import { type IdentityArchiveSnapshot, type IdentityArchives } from "../relay/identity-archives";
/** Community evidence, not process readiness or permission to grant access. */
export declare function sameCommunityAgents(agents: readonly LocalAgent[], scope: string): Readonly<{
    pubkey: string;
    name: string;
    relayUrl: string;
    owner: string;
    picture?: string;
}>[];
type Choice = AgentLibrarySnapshot["identities"][number] & {
    managed: boolean;
    managedName?: string;
    /** Additional DM eligibility from completed owned hosted-agent records. */
    messageable?: true;
};
export declare function canMessageAgent(agent: Pick<Choice, "managed" | "messageable">): boolean;
type SelectionSource = boolean | "templates";
type TemplateChoices = Pick<AgentLibrarySnapshot, "status" | "error"> & {
    identities: readonly Choice[];
    complete: boolean;
    pending: boolean;
};
export type AgentChoicesSnapshot = Omit<AgentLibrarySnapshot, "identities"> & {
    /** Every known agent, including archived ones: facts about existing content. */
    identities: readonly Choice[];
    /** Forward-looking choices: `identities` minus known-archived agents. */
    selectable: readonly Choice[];
    /** Archive evidence that produced `selectable`; templates require it ready. */
    archives: IdentityArchiveSnapshot;
    /** Templates mirror Agents, including source readiness and errors. */
    templates: TemplateChoices;
    /** Usable candidates do not imply complete evidence for automatic recipients. */
    complete: boolean;
    pending: boolean;
};
/** One read-only projection of existing sources. No directory scan, timer, runner
 * or write authority. The relay session owns its lifetime; native owns processes. */
export declare function createAgentChoices({ scope, library, native, archives, signal, }: {
    scope: string;
    library: ReturnType<typeof createAgentLibrary>["queries"];
    native?: LocalAgents | undefined;
    /** Absent only on hosts without archive evidence; nothing is then hidden. */
    archives?: Pick<IdentityArchives, "snapshot" | "subscribe" | "state" | "ensure" | "refresh"> | undefined;
    signal: AbortSignal;
}): Readonly<{
    snapshot: () => AgentChoicesSnapshot;
    subscribe(listener: () => void): () => void;
    /** Selectors pass `archive` to demand the lazy archive read for `selectable`. */
    ensure(includeLegacy?: boolean, archive?: boolean): void;
    /** `fresh` rereads inventory even over a read already in flight, as after
     * a change that read may predate. */
    refresh(source?: SelectionSource, { fresh }?: {
        fresh?: boolean | undefined;
    }): Promise<void>;
    retain(): () => void;
}>;
/** Match the Agents page's source, retaining community and archive policy at the
 * action boundary. Never substitute old-library identities during a native error.
 * Templates are stricter than `selectable`: they need verified non-archived state. */
export declare function templateAgentChoices(agents: AgentChoicesSnapshot, channels: ChannelList): Choice[];
export {};
