import type { Agent, RegisteredAgentType } from "./service";
export type AgentExecutionLocation = "remote" | "local";
/** Short location copy for message byline tooltips, using confirmed execution. */
export declare function remoteExecutionDetail(execution: AgentExecutionLocation | undefined, runtime?: string): "Runs on a remote machine" | "Runs remotely on Builderlab" | undefined;
/** Active fallback when current work has no step details. */
export declare function remoteWorkDetail(execution: AgentExecutionLocation | undefined, runtime?: string): "Running on a remote machine…" | "Running remotely on Builderlab…" | undefined;
/** Execution location is independent of presence, model and ownership. */
export declare const executionCopy: {
    readonly remote: {
        readonly description: "Keeps working while this computer is off, and you can chat from your phone. It can’t open files on this computer.";
    };
};
/** An unavailable type on another device does not establish its location. */
export declare function agentExecution(agent: Pick<Agent, "place" | "executionBinding">, type?: Pick<RegisteredAgentType, "remote">): AgentExecutionLocation | undefined;
